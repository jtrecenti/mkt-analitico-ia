# Exercício 6. Um monitor das avaliações que roda todo dia

**Onde:** aplicativo de desktop do ChatGPT, modo Work, numa pasta do seu
computador. **Fazemos juntos:** o professor monta o dele na tela, ao mesmo tempo.

## O que você vai construir

Uma **pasta de projeto** que, com um único pedido ("atualize o monitor"), faz
cinco coisas sempre do mesmo jeito, para os aplicativos que **você** escolher:

1. **coleta** as avaliações de hoje na App Store e guarda o arquivo como chegou;
2. **junta** com as coletas anteriores, sem contar a mesma avaliação duas vezes;
3. **confere** os dados com checagens de consistência antes de qualquer número;
4. **estrutura os textos** com IA: o tema de cada avaliação e se ela reclama de
   algo, com as respostas guardadas para não pagar duas vezes;
5. **gera um relatório HTML** em Quarto, reprodutível, com gráficos do ECharts,
   pronto para publicar no Netlify Drop.

## Por que uma pasta, e não uma conversa

Na quarta, o relatório nasceu numa conversa. Amanhã, numa conversa nova, o
agente não lembra das regras que você combinou. Na pasta, as regras ficam
escritas no `AGENTS.md`, os passos ficam em arquivos, e o mesmo pedido dá o
mesmo resultado, para você ou para um colega.

## Material

- A habilidade `avaliacoes-app` (da quarta), para baixar as avaliações;
- a habilidade `estruturar-textos`, para classificar os textos com o Jev;
- a chave `JEV_API_KEY` num arquivo `.env` na pasta (você cria o arquivo; a
  chave nunca vai para a conversa);
- para comparar, o projeto do professor em `exemplos/monitor-app/` e duas
  coletas reais das companhias aéreas em `dados/app/`.

## Passos

1. **Escolher os aplicativos.** Escolha um ou mais aplicativos de sua
   preferência, que você gostaria de monitorar: o da sua empresa, o de um
   concorrente, o de um serviço que você usa. Na App Store, o endereço do app
   tem um número (`id1497908631`): anote o de cada um.
2. **Criar a pasta.** Crie uma pasta `monitor-app`, coloque o `.env` dentro e
   abra a pasta no modo Work.
3. **Colar o pedido.** Troque os aplicativos e cole:

   > Esta pasta vai ser um monitor diário das avaliações dos aplicativos
   > [NOME (id NÚMERO), NOME (id NÚMERO)] na App Store do Brasil. Organize a
   > pasta como um projeto que refaz tudo com um pedido: um passo por arquivo,
   > com nome que diz o que faz (coletar, juntar, checar, estruturar,
   > relatório); um `rodar.py`; um `README.md`; e um `AGENTS.md` com as regras.
   >
   > Regras: cada coleta fica em `dados/coletas/avaliacoes_AAAA-MM-DD.csv` e
   > nunca é editada; a mesma avaliação em várias coletas conta uma vez; se ela
   > mudou, vale a mais recente; diga quantas linhas entraram e saíram em cada
   > passo; telefone, e-mail e CPF no texto são mascarados antes de qualquer
   > saída; nenhum apelido de quem avaliou.
   >
   > Antes de qualquer número, crie checagens de consistência: frases que
   > precisam ser verdade nos dados (por exemplo, "toda nota está entre 1 e 5").
   > Umas bloqueiam o relatório; outras só alertam.
   >
   > Para estruturar os textos, use a skill `estruturar-textos` com o Jev: o
   > tema principal de cada avaliação (opções fechadas, que vamos combinar) e se
   > ela reclama de algo. Guarde as respostas num cache, para rodar de novo sem
   > pagar de novo.
   >
   > O relatório é um arquivo `relatorio.qmd` do Quarto que vira
   > `saida/index.html`, um arquivo só, com gráficos do ECharts: a nota média
   > dos últimos 30 dias, a nota por semana, os temas das reclamações e as
   > avaliações novas desde a coleta anterior. Siga as boas práticas do curso:
   > título de cada gráfico com a conclusão, calculada pelo código; barras
   > ordenadas, começando no zero; uma cor de destaque e cinza no resto; nada de
   > pizza, 3D, dois eixos ou boxplot; fonte e data no rodapé. Nenhum número
   > escrito à mão. Se faltar o Quarto, instale com `pip install quarto-cli`.

4. **Combinar os temas.** O agente vai propor as opções de tema. Leia: elas
   cobrem o que aparece nas avaliações do seu app? Peça para testar em 10
   avaliações e confira à mão antes de rodar em todas.
5. **Ler as regras.** Abra o `AGENTS.md` que ele escreveu. Falta alguma regra
   que você sabe e ele não sabe? Peça para acrescentar.
6. **Abrir o relatório.** Abra `saida/index.html` no navegador. Os títulos
   dos gráficos dizem algo verdadeiro? Confira um número contra a planilha.
7. **Testar numa conversa nova.** Abra outra conversa na mesma pasta e peça só
   "atualize o monitor". Os números são os mesmos? Se forem, o processo está na
   pasta, e não na conversa.

## Como conferir

- Rodar duas vezes seguidas dá **o mesmo relatório**, e a segunda rodada não
  classifica nada de novo (tudo vem do cache).
- Cada passo diz quantas linhas entraram e quantas saíram.
- Na segunda coleta, as avaliações repetidas contam uma vez: se o relatório
  disser que chegaram 500 avaliações novas num dia, ele somou as repetidas.

Com as duas coletas das companhias aéreas em `dados/app/`, o projeto do
professor chega a **2.010 avaliações diferentes** (de 4.000 linhas), **10
novas**, uma avaliação que mudou de nota e três textos com o que parece um
telefone.

## E a skill?

Ela vem depois. Primeiro o problema se resolve na pasta, rodando de verdade
algumas vezes, até as regras pararem de mudar. Só então vale transformar o
processo numa skill para outras pessoas usarem. A skill do professor, para
comparar, está em `skills/monitor-avaliacoes-app/`.
