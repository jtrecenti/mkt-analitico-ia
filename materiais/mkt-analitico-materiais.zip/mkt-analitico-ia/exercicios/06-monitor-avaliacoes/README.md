# Exercício 6. Um monitor das avaliações que roda todo dia

**Onde:** aplicativo de desktop do ChatGPT, modo Work, numa pasta do seu
computador. **Em duplas.**

## O que vocês vão construir

Uma **pasta de projeto** que, com um único pedido ("atualize o monitor"), faz
três coisas sempre do mesmo jeito:

1. **junta** a coleta de avaliações de hoje com as dos dias anteriores, sem
   contar a mesma avaliação duas vezes;
2. **confere** os dados com checagens de consistência antes de calcular
   qualquer número;
3. **gera uma página**, `saida/index.html`, com a nota média dos últimos 30
   dias de cada companhia, as avaliações novas e os temas mais citados.

No fim, vocês terão a pasta funcionando e a página aberta no navegador.

## Por que uma pasta, e não uma conversa

Na quarta, o relatório nasceu numa conversa. Amanhã, numa conversa nova, o
agente não lembra das regras que vocês combinaram. Na pasta, as regras ficam
escritas no `AGENTS.md`, os passos ficam em arquivos, e o mesmo pedido dá o
mesmo resultado, para vocês ou para um colega.

## Material

Em `dados/app/`, duas coletas reais do feed da App Store, das quatro
companhias:

- `avaliacoes_2026-11-03.csv` (terça);
- `avaliacoes_2026-11-05.csv` (hoje de madrugada).

E a habilidade `avaliacoes-app` da quarta, para baixar a coleta de agora.

## Passos

1. **Montem a pasta.** Criem uma pasta `monitor-app` com uma subpasta
   `dados/coletas/`, coloquem as duas coletas lá dentro e abram `monitor-app`
   no modo Work.
2. **Peçam o projeto.** Colem este pedido:

   > Esta pasta é um monitor das avaliações dos apps da LATAM, GOL, Azul e TAP
   > na App Store. Cada arquivo de `dados/coletas/` é a coleta de um dia, como
   > chegou. Organize a pasta como um projeto que refaz tudo com um pedido: um
   > passo por arquivo, com nome que diz o que faz (coletar, juntar, checar,
   > página); um `rodar.py`; um `README.md`; e um `AGENTS.md` com as regras.
   > Regras: as coletas nunca são editadas; a mesma avaliação em várias coletas
   > conta uma vez; diga quantas linhas entraram e saíram em cada passo; nenhum
   > dado pessoal na saída. Antes de qualquer número, crie checagens de
   > consistência: frases que precisam ser verdade nos dados (por exemplo,
   > "toda nota está entre 1 e 5"). A saída é uma página `saida/index.html`,
   > um arquivo só, com a nota média dos últimos 30 dias de cada companhia, as
   > avaliações novas desde a coleta anterior e os temas mais citados.

3. **Leiam as regras.** Abram o `AGENTS.md` que ele escreveu. Falta alguma
   regra que vocês sabem e ele não sabe? Peçam para acrescentar.
4. **Testem com dados novos.** Peçam a coleta de agora (com a habilidade
   `avaliacoes-app`) e depois "atualize o monitor". O que chegou desde a
   madrugada?
5. **Testem numa conversa nova.** Abram outra conversa na mesma pasta e peçam
   só "atualize o monitor". Os números são os mesmos? Se forem, o processo
   está na pasta, e não na conversa.

## Como conferir

Com as duas coletas do pacote: **4.000 linhas** viram **2.010 avaliações
diferentes**, e só **10** são novas na coleta de hoje. Se o monitor disse que
chegaram 2.000 avaliações novas, ele somou as repetidas.

Há também uma avaliação que **mudou de nota** entre as coletas e três textos
com **o que parece um telefone**. As checagens de vocês pegaram?

## E a skill?

Ela vem depois. Primeiro o problema se resolve na pasta, rodando de verdade
algumas vezes, até as regras pararem de mudar. Só então vale transformar o
processo numa skill para outras pessoas usarem. A skill do professor, para
comparar, está em `skills/monitor-avaliacoes-app/`; o projeto completo, em
`exemplos/monitor-app/`.
