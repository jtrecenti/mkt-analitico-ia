# Exercício 6. Um monitor que roda todo dia

**Onde:** aplicativo de desktop do ChatGPT, modo Work, numa pasta do seu
computador. **Em duplas.**

Na quarta, cada grupo baixou as avaliações do aplicativo da sua companhia uma
vez e fez um relatório. Mas avaliação chega todo dia, e ninguém quer refazer o
relatório do zero toda manhã. Aqui, o relatório vira um **monitor**: uma pasta
que junta a coleta de hoje com as anteriores e refaz a página com um pedido.

## Material

Em `dados/app/`, duas coletas reais do feed da App Store, das quatro
companhias:

- `avaliacoes_2026-11-03.csv` (terça);
- `avaliacoes_2026-11-05.csv` (hoje de madrugada).

E a habilidade `avaliacoes-app` da quarta, para baixar a coleta de agora.

## Passos

1. Crie uma pasta `monitor-app` com `dados/coletas/` dentro, ponha as duas
   coletas lá e abra a pasta no modo Work.
2. Cole este pedido:

   > Esta pasta é um monitor das avaliações dos apps da LATAM, GOL, Azul e TAP
   > na App Store. Cada arquivo de `dados/coletas/` é uma coleta de um dia, como
   > chegou. Organize a pasta como um projeto que refaz tudo com um pedido: um
   > passo por arquivo, com nome que diz o que faz (coletar, juntar, checar,
   > página); um `rodar.py`; um `README.md`; e um `AGENTS.md` com as regras.
   > Regras: as coletas nunca são editadas; a mesma avaliação em várias coletas
   > conta uma vez; diga quantas linhas entraram e saíram em cada passo; nenhum
   > dado pessoal na saída. Antes de qualquer número, crie checagens de
   > consistência: frases que precisam ser verdade nos dados (por exemplo,
   > "toda nota está entre 1 e 5"). A saída é uma página `saida/index.html`,
   > um arquivo só, com a nota média dos últimos 30 dias de cada companhia, as
   > avaliações novas desde a coleta anterior e os temas mais citados.

3. Leiam o `AGENTS.md`. Falta alguma regra que vocês sabem e ele não sabe?
   Acrescentem.
4. Peçam a coleta de agora (com a habilidade `avaliacoes-app`) e rodem de novo.
   O que chegou desde a madrugada?

## Para conferir

Com as duas coletas do pacote: **4.000 linhas** viram **2.010 avaliações
diferentes**, e só **10** são novas na coleta de hoje. Se o seu monitor disse
que chegaram 2.000 avaliações novas, ele somou as repetidas.

Há também uma avaliação que **mudou de nota** entre as coletas e três textos
com **o que parece um telefone**. As checagens de vocês pegaram?

## Por que não começar criando uma skill?

Porque a pasta é onde se descobre o processo: as regras aparecem trabalhando
(as repetidas entre coletas, a avaliação editada, o telefone no texto). A skill
vem no exercício 7, quando o processo já funciona.

## Para comparar

O projeto do professor está em `exemplos/monitor-app/`. Comparem as checagens
de vocês com as de `passos/p3_checar.py`.
