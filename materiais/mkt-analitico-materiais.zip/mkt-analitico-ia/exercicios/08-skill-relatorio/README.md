# Exercício 8. O projeto vira uma skill

**Onde:** aplicativo de desktop do ChatGPT, modo Work. **Em duplas.**

O projeto funciona na pasta de vocês. Mas quem vai rodar em novembro pode ser
outra pessoa do time, em outra pasta. Uma **skill** leva a receita junto: os
passos, as regras e as checagens, num pacote que qualquer conversa usa.

## Material

A pasta do exercício 7, já rodando outubro. Para comparar:
`skills/relatorio-mensal-midia/` (a skill do professor).

## Passos

1. Peçam, na pasta do projeto:

   > Transforme este projeto numa skill chamada `relatorio-mensal-midia`: um
   > `SKILL.md` com uma descrição que diga quando usar, os passos na ordem, as
   > regras do `AGENTS.md` e o que fazer quando uma checagem bloquear (perguntar
   > ao usuário, nunca resolver sozinho); e uma pasta `scripts/` com o código
   > dos passos, que receba a pasta dos dados como parâmetro. Teste a skill
   > numa pasta nova antes de me entregar.

2. Instalem a skill no ChatGPT (como na terça).
3. **A prova da reprodutibilidade:** abram uma conversa nova, **sem** a pasta do
   projeto. Anexem só os arquivos de setembro e de outubro e peçam: "Faça o
   relatório de mídia de 2026-10". Os números batem com os do projeto?
4. Se não baterem, o que ficou de fora da skill? Corrijam e repitam.

## Para conferir

A skill precisa chegar a **R$ 66.809** de investimento e ROAS **4,17** em
outubro, numa conversa que nunca viu o projeto.

## Para levar

Esta é a receita para qualquer relatório que se repete no trabalho de vocês:
primeiro um projeto organizado, depois as checagens que o mundo real ensina, e
por fim a skill que leva tudo para o time.
