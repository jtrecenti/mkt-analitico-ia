# Exercício 3. Raspar sentenças do TJSP sobre voos atrasados

**Onde:** aplicativo de desktop, modo Work. Se não conseguir instalar o
aplicativo, use o Work no navegador. **Em duplas.** **Tempo:** 30 minutos.

## A situação

Quanto custa, na Justiça, um voo atrasado ou cancelado? Toda sentença de
primeiro grau do Tribunal de Justiça de São Paulo é publicada na **Consulta
de Julgados de 1º Grau**: qualquer pessoa pode pesquisar, sem login. São
centenas de ações de passageiros contra LATAM, Gol e Azul por trimestre, cada
uma com a história, a defesa da companhia, a decisão e o valor da indenização.

Ninguém entrega essa base pronta. Neste exercício, vocês a montam.

## Por que não o consumidor.gov.br

Em 2024, a página de relatos do consumidor.gov.br mostrava o texto das
reclamações. Hoje ela exige login, e mesmo com login gov.br a consulta devolve
**acesso negado (403)**. Informação que não é pública não se raspa. As
reclamações de 2024, coletadas quando eram públicas, voltam à tarde, já
estruturadas.

## Material

- A página: <https://esaj.tjsp.jus.br/cjpg/>
- A busca de referência: pesquisa livre `voo E atraso E (LATAM OU GOL OU AZUL)`,
  datas de **01/08/2026** a **31/10/2026**. Em 3/11/2026, eram **398**
  sentenças.

## Passos

1. **Navegar** (5 min). Abram a página, façam a busca à mão e olhem o
   resultado: quantas sentenças, quantas por página, onde está o texto
   inteiro (o ícone **+** ao fim de cada resumo).
2. **Pedir o raspador** (20 min). No Work, peçam:

   > Quero raspar sentenças da Consulta de Julgados de 1º Grau do TJSP
   > (https://esaj.tjsp.jus.br/cjpg/) com a pesquisa livre
   > "voo E atraso E (LATAM OU GOL OU AZUL)", de 01/08/2026 a 31/10/2026.
   > Siga o ciclo do web scraping. Primeiro descubra que requisição o botão
   > Consultar faz e reproduza essa requisição em Python, com todos os campos.
   > Salve cada página de resultado em HTML numa pasta brutos/ antes de ler
   > qualquer coisa. Depois leia os arquivos e monte uma tabela com processo,
   > classe, assunto, comarca, data e o texto inteiro da sentença. No fim,
   > confira se o número de sentenças lidas bate com o total que o site
   > anuncia. Uma página por vez, com 2 segundos de pausa. Comece com 3
   > páginas e me mostre o resultado antes de baixar o resto.

3. **Validar** (5 min). O total bateu? Alguma sentença veio sem texto? Alguma
   não é contra companhia aérea? Abram duas sentenças no site e comparem com a
   tabela.

## Entrega

Um CSV com as sentenças e **duas coisas que vocês validaram**: o que conferiram
e o que encontraram.

## O que aconteceu na preparação

- **Todos os campos do formulário, mesmo os vazios.** Mandando só a busca e as
  datas, o site respondeu normalmente (código 200), mas **sem nenhum
  resultado**. Replicar a requisição é replicar ela inteira.
- **O total vem com tags no meio** ("Resultados `<strong>`1 a 10`</strong>` de
  398"). O primeiro leitor não achou o número e achou que a busca estava vazia.
- **Os parênteses mudam tudo.** `voo E atraso E (LATAM OU GOL OU AZUL)` trouxe
  398 sentenças. Sem os parênteses, 134: só as da LATAM.
- **O texto inteiro já vem na lista**, num bloco escondido da página
  (`display: none`). Não é preciso abrir sentença por sentença.
- **A busca traz ruído**: 51 das 398 sentenças não são contra LATAM, Gol ou
  Azul (TAP, Copa, United, Decolar, CVC e até o Facebook), e duas são ações
  penais. Elas citam as palavras da busca de passagem. Validar é olhar para
  isso.

## Cuidados

- As sentenças são públicas, mas trazem **nomes de partes, advogados e
  juízes**. Usem para análise e não publiquem a base com nomes. A amostra do
  exercício 4 foi anonimizada.
- O servidor do tribunal é de todos: uma página por vez, com pausa, e só o
  período de que precisam.

## Gabarito

A habilidade do professor está em `skills/raspar-tjsp/`:

```bash
python skills/raspar-tjsp/scripts/raspar_tjsp.py baixar --pasta brutos --max-paginas 40
python skills/raspar-tjsp/scripts/raspar_tjsp.py ler --pasta brutos --saida sentencas.csv
```

## Para ir além

Transformem o raspador numa habilidade (`raspar-tjsp`) que recebe a busca e o
período, e rodem para outro setor que interessa ao seu trabalho: planos de
saúde, bancos, telefonia, comércio eletrônico.
