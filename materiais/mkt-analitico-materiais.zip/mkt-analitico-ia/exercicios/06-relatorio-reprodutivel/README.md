# Exercício 6. Um relatório que roda de novo

**Onde:** aplicativo de desktop do ChatGPT, modo Work, numa pasta do seu
computador. **Em duplas.**

Vocês são o time de marketing da Bora Bebidas, uma marca fictícia de bebidas.
Todo começo de mês chegam dois arquivos (mídia da agência e vendas do
e-commerce) e a diretoria quer um relatório de uma página. Hoje ele é feito
numa conversa nova a cada mês, e os números não batem de um mês para o outro.

O objetivo aqui não é só o relatório de setembro: é a **pasta** que refaz o
relatório de qualquer mês, do mesmo jeito.

## Material

Na pasta `dados/bora/` do pacote:

- `midia_2026-08.csv`, `vendas_2026-08.csv`, `midia_2026-09.csv`, `vendas_2026-09.csv`;
- `dicionario_bora.md` (as colunas e as contas: CPA, ROAS);
- `briefing_bora.md` (o que a diretoria quer).

Os arquivos de outubro ficam para o exercício 7. Não os coloque na pasta ainda.

## Passos

1. Crie uma pasta `relatorio-bora` no seu computador com esta estrutura e abra
   a pasta no modo Work:

   ```
   relatorio-bora/
     dados/brutos/   os quatro arquivos de agosto e setembro
     dados/          o dicionário e o briefing
   ```

2. Cole este pedido:

   > Esta pasta é o relatório mensal de mídia da Bora Bebidas. Leia
   > `dados/briefing_bora.md` e `dados/dicionario_bora.md`. Organize a pasta como
   > um projeto que refaz o relatório de qualquer mês com um comando:
   > um passo por arquivo, com nome que diz o que faz (ler, padronizar,
   > checar, relatório); um `rodar.py` que recebe o mês (por exemplo
   > `python rodar.py 2026-09`) e diz quantas linhas entraram e saíram em cada
   > passo; um `README.md` que explica como rodar; e um `AGENTS.md` com as regras
   > do projeto. Regras: os arquivos de `dados/brutos/` nunca são editados; o
   > canal Direto não tem investimento, então não tem CPA nem ROAS; todo número
   > do relatório sai dos passos, nunca escrito à mão. Antes de calcular, crie
   > checagens de consistência: frases que precisam ser verdade nos dados (por
   > exemplo, "cliques nunca passam das impressões"). Ao final, rode o mês
   > 2026-09 e me mostre o relatório, comparando com agosto.

3. Leia o `AGENTS.md` que ele escreveu. Falta alguma regra que vocês sabem e
   ele não sabe? Acrescentem.
4. Peça para rodar **de novo**, numa conversa nova na mesma pasta:
   "Rode o relatório de 2026-09". Os números são os mesmos? Se não forem, o
   projeto ainda depende da conversa.

## Para conferir

Setembro tem investimento de **R$ 58.298**, **2.557 pedidos** e ROAS de
**4,45**. Se o seu deu diferente, descubram por quê antes de seguir.

## Para comparar

O projeto do professor está em `exemplos/relatorio-bora/`. Comparem as
checagens de vocês com as de `passos/p3_checar.py`: quais vocês tinham e ele
não, e o contrário?
