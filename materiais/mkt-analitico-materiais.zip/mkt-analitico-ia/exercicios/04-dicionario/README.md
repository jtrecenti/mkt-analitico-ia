# Exercício 4. Escrever o dicionário de variáveis

**Onde:** papel, planilha e ChatGPT. **Em grupo, uma companhia por grupo**
(dentro do grupo, em duplas). **Tempo:** 20 minutos.

Uma avaliação diz muita coisa: do que a pessoa reclama, se fala do aplicativo
ou do voo, com que raiva. Para virar análise, o texto precisa virar coluna, e
a IA faz isso em escala. Mas **quem decide quais colunas** são vocês, antes. E
as colunas que vocês escolherem são as que vão sustentar a hipótese do grupo.

## Material

- As avaliações que vocês baixaram no exercício 3. Se o raspador não terminou,
  usem `exercicios/04-dicionario/avaliacoes_amostra.csv`: 160 avaliações da
  App Store, 40 de cada companhia (LATAM, Gol, Azul, TAP), de 2025 e 2026,
  sem o nome de quem avaliou.
- Quem fez a parte B do exercício 3 pode usar as próprias sentenças, ou
  `exercicios/04-dicionario/sentencas_amostra.csv`: 40 sentenças do TJSP
  (agosto a outubro de 2026) contra Azul, LATAM e Gol, com nomes trocados por
  `[nome]`.
- `exercicios/04-dicionario/modelo_dicionario.csv`: o formato, com dois
  exemplos.

## Passos

1. **Leiam 15 avaliações da sua companhia** (7 min), de notas diferentes.
   Anotem o que se repete e o que diferencia uma da outra.
2. **Escrevam de 4 a 6 variáveis** (8 min). Para cada uma:
   - nome curto (`tema`, `fala_do_voo`, `tom`);
   - tipo da resposta: **uma opção de uma lista**, **sim/não** ou **número**;
   - a pergunta, escrita para alguém que nunca viu o caso;
   - as opções, cada uma com uma frase que a define, e sempre um "outro" ou um
     "não diz".

   Pelo menos uma variável tem que servir para a hipótese do grupo: se vocês
   desconfiam que o problema é o atraso, uma pergunta precisa medir isso.
3. **Codifiquem 10 avaliações à mão** (5 min). Onde hesitaram, a pergunta está
   mal escrita: reescrevam.

Peçam ajuda ao ChatGPT para revisar as definições, mas a escolha das
variáveis é de vocês.

## Entrega

O dicionário (`dicionario.csv`) e as 10 avaliações codificadas à mão
(`codificacao_manual.csv`). Eles são o gabarito do exercício 5.

## Duas armadilhas que apareceram na preparação

- **A opção que mistura duas coisas.** Numa avaliação, "o site parou de
  funcionar e, quando recomecei, o preço tinha subido R$ 200" é falha do
  aplicativo ou reclamação de preço? A OpenAI disse uma coisa, o Jev disse
  outra. Nenhum dos dois errou: o dicionário pedia **um** tema e o texto tinha
  dois. Ou se escolhe um critério ("o problema que a pessoa cita primeiro"),
  ou se criam duas variáveis sim/não.
- **A fonte decide o que dá para medir.** Nas avaliações da App Store, só 7% a
  18% falam do voo; o resto fala do aplicativo. Uma variável "o voo atrasou?"
  vai sair quase sempre "não", e isso não quer dizer que os voos não atrasam.

Nas sentenças, a armadilha foi parecida: a opção "procedente" foi definida
como "o passageiro ganhou tudo o que pediu", mas o juiz pode escrever "julgo
procedente" fixando um valor menor que o pedido. Em 8 das 40 sentenças, a
OpenAI seguiu as palavras do juiz e o Jev seguiu a definição.
