# Exercício 4. Escrever o dicionário de variáveis

**Onde:** papel, planilha e ChatGPT. **Em duplas.** **Tempo:** 25 minutos.

Uma sentença diz muita coisa: o que aconteceu com o voo, o que a companhia
alegou, se o passageiro ganhou e quanto. Para virar análise, o texto precisa
virar coluna, e a IA faz isso em escala. Mas **quem decide quais colunas** é
você, antes.

## Material

- `exercicios/04-dicionario/sentencas_amostra.csv`: 40 sentenças do TJSP
  (agosto a outubro de 2026) contra Azul, LATAM e Gol, sorteadas da busca do
  exercício 3. Nomes de partes, advogados e juízes foram trocados por `[nome]`,
  e números de processo por `[processo]`.
- `exercicios/04-dicionario/modelo_dicionario.csv`: o formato, com dois
  exemplos.

## Passos

1. **Leiam 5 sentenças** (10 min). Comecem pelo fim: o "Ante o exposto, julgo"
   resume a decisão. Anotem o que se repete e o que diferencia um caso do
   outro.
2. **Escrevam de 5 a 8 variáveis** (10 min). Para cada uma:
   - nome curto (`problema`, `resultado`, `valor_dano_moral`);
   - tipo da resposta: **uma opção de uma lista**, **sim/não** ou **número**;
   - a pergunta, escrita para alguém que nunca viu o caso;
   - as opções, cada uma com uma frase que a define, e sempre um "outro" ou um
     "não diz".
3. **Codifiquem 5 sentenças à mão** (5 min). Onde hesitaram, a pergunta está
   mal escrita: reescrevam.

Peçam ajuda ao ChatGPT para revisar as definições, mas a escolha das
variáveis é de vocês.

## Entrega

O dicionário (`dicionario.csv`) e as 5 sentenças codificadas à mão
(`codificacao_manual.csv`). Eles são o gabarito do exercício 5.

## Uma armadilha que apareceu na preparação

No dicionário do professor, a opção "procedente" foi definida como "o
passageiro ganhou tudo o que pediu". Mas o juiz pode escrever "julgo
procedente" mesmo fixando um valor menor que o pedido. Em 8 das 40 sentenças, a OpenAI
seguiu as palavras do juiz e o Jev seguiu a definição. Nenhum dos dois errou:
**a opção misturava duas coisas**. Escolham uma, e escrevam qual.
