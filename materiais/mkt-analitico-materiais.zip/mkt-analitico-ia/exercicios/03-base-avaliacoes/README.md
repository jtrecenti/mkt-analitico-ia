# Exercício 3. Uma base com as avaliações da sua companhia, e o primeiro retrato dela

**Onde:** aplicativo de desktop, modo Work, numa pasta do seu computador. Se
não conseguir instalar o aplicativo, use o Work no navegador (a parte das
chaves de API fica mais difícil). **Em grupo, uma companhia por grupo**
(dentro do grupo, em duplas).

## A situação

Cada grupo é a equipe de experiência do cliente de uma companhia: **LATAM,
Gol, Azul ou TAP**. A diretoria quer saber **o que mais irrita os
passageiros**. Ninguém entrega os textos prontos: neste exercício, vocês

1. **baixam** as avaliações do aplicativo da companhia na App Store;
2. **decidem o que medir** nelas, num dicionário de variáveis;
3. **criam as colunas** com dois modelos de IA, a OpenAI e o Jev;
4. escrevem um **relatório exploratório** da base, que termina com a
   hipótese do grupo.

À tarde, a hipótese vai ser testada numa base de 8.000 voos.

## Material (nesta pasta)

| arquivo | o que é |
|---|---|
| `README.md` | este roteiro, com os pedidos |
| `modelo_dicionario.csv` | o formato do dicionário, com dois exemplos |
| `avaliacoes_amostra.csv` | o plano B: 160 avaliações da App Store, 40 por companhia, de 2025 e 2026, sem o nome de quem avaliou |
| `dicionario_avaliacoes.json` e `extrair.py` | o dicionário e o script de extração do professor, para comparar |
| `sentencas_amostra.csv` e `dicionario_sentencas.json` | para quem chegar no TJSP: 40 sentenças com nomes trocados por `[nome]`, e o dicionário do professor |

As chaves da OpenAI e do Jev são entregues na sala e valem só durante o curso.

## Para começar: dê o contexto ao Work

Criem uma pasta de trabalho, copiem para ela os arquivos desta pasta e criem
um arquivo `.env` com as chaves:

```
OPENAI_API_KEY=...
JEV_API_KEY=...
```

Abram a pasta no aplicativo de desktop e comecem com um pedido que diz o
trabalho inteiro (troquem TAP pela sua companhia):

> Somos a equipe de experiência do cliente da TAP. Vamos montar, nesta pasta,
> uma base com as avaliações do aplicativo da TAP na App Store e escrever um
> relatório exploratório dela. O trabalho tem quatro etapas: baixar, escrever
> o dicionário de variáveis, extrair as variáveis com as APIs da OpenAI e do
> Jev, e o relatório. Faça uma etapa de cada vez e pare no fim de cada uma
> para eu conferir. As chaves estão no arquivo .env: leia de lá e nunca as
> mostre. Não guarde nome, apelido nem e-mail de quem avaliou. Para cada
> tabela, diga quantas linhas entraram, quantas saíram e por quê.

## Etapa 1. Baixar as avaliações da App Store

Toda avaliação de aplicativo na App Store é pública. A página mostra a nota e
algumas avaliações; a Apple também oferece um **feed** (um endereço feito para
programas) com as 500 mais recentes, em JSON.

| companhia | página na App Store | número do aplicativo |
|---|---|---|
| LATAM | <https://apps.apple.com/br/app/id1497908631> | 1497908631 |
| Gol | <https://apps.apple.com/br/app/id337961662> | 337961662 |
| Azul | <https://apps.apple.com/br/app/id690105616> | 690105616 |
| TAP | <https://apps.apple.com/br/app/id440497198> | 440497198 |

1. **Navegar.** Abram a página do aplicativo da sua companhia. Qual a nota?
   Quantas avaliações? O que dá para ver ali, e o que não dá?
2. **Pedir o raspador** (troquem o número pelo da sua companhia):

   > Etapa 1. Quero baixar as avaliações mais recentes do aplicativo de número
   > 440497198 na App Store do Brasil. A Apple tem um feed público em JSON:
   > https://itunes.apple.com/br/rss/customerreviews/page=1/id=440497198/sortby=mostrecent/json
   > (troque page=1 por 2, 3... até 10). Siga o ciclo do web scraping: salve
   > cada página em disco numa pasta brutos_app/ antes de ler qualquer coisa,
   > uma página por vez, com 1 segundo de pausa. Depois leia os arquivos e
   > monte avaliacoes.csv com id, data, nota, versão do aplicativo, título e
   > texto de cada avaliação. Comece com 2 páginas e me mostre o resultado
   > antes de baixar o resto.

3. **Validar.** Respondam com números:
   - Quantas avaliações vieram? Alguma repetida? Alguma sem texto?
   - De que data a que data? (Cada companhia tem um período diferente. Por
     quê?)
   - A nota média das 500 bate com a nota que a página mostra? Se não bate,
     por quê?
   - Abram três avaliações no arquivo bruto e comparem com a tabela.

Se o raspador não funcionar, sigam com as 40 avaliações da sua companhia em
`avaliacoes_amostra.csv`.

## Etapa 2. Escrever o dicionário de variáveis

Uma avaliação diz muita coisa: do que a pessoa reclama, se fala do aplicativo
ou do voo, com que raiva. Para virar análise, o texto precisa virar coluna, e
a IA faz isso em escala. Mas **quem decide quais colunas** são vocês, antes.

1. **Leiam 15 avaliações da sua companhia**, de notas diferentes. Anotem o que
   se repete e o que diferencia uma da outra.
2. **Escrevam de 4 a 6 variáveis** em `dicionario.csv`, no formato de
   `modelo_dicionario.csv`. Para cada uma:
   - nome curto (`tema`, `fala_do_voo`, `tom`);
   - tipo da resposta: **uma opção de uma lista**, **sim/não** ou **número**;
   - a pergunta, escrita para alguém que nunca viu o caso;
   - as opções, cada uma com uma frase que a define, e sempre um "outro" ou um
     "não diz".

   Pelo menos uma variável tem que servir para a hipótese do grupo: se vocês
   desconfiam que o problema é o atraso, uma pergunta precisa medir isso.
3. **Codifiquem 10 avaliações à mão**, em `codificacao_manual.csv`. Onde
   hesitaram, a pergunta está mal escrita: reescrevam.

Peçam ao ChatGPT para revisar as definições, mas a escolha das variáveis é de
vocês.

## Etapa 3. Criar as colunas com a OpenAI e o Jev

Com o dicionário pronto, um modelo de linguagem lê cada avaliação e preenche
as colunas. Vamos usar dois, pela API:

- **OpenAI** (`gpt-5.6-luna`), com **saída estruturada**: o modelo é obrigado a
  responder num formato fixo, com as opções do seu dicionário. Também responde
  números.
- **Jev**, da TypeSafe: um modelo que **não escreve texto**. Ele só responde
  perguntas tipadas (uma opção de uma lista, sim/não) e diz a probabilidade de
  cada resposta. É bem mais rápido e mais barato, e não gera números.

> Etapa 3. Escreva um script Python que extraia as variáveis de dicionario.csv
> de cada avaliação de avaliacoes.csv usando a API da OpenAI com saída
> estruturada e, separadamente, a API do Jev (pacote typesafe-sdk). Teste com
> 5 avaliações antes de rodar todas. Grave uma tabela com uma linha por
> avaliação e as colunas dos dois modelos. No fim, compare os dois modelos e a
> nossa codificação manual (codificacao_manual.csv): em quantos por cento
> concordam, variável por variável?

Depois, **leiam os casos em que discordam.** Quem errou: a OpenAI, o Jev,
vocês ou a pergunta?

## Etapa 4. O relatório exploratório

> Etapa 4. Com a base pronta, escreva um relatório exploratório em
> relatorio.md, para a diretoria de experiência do cliente, com um gráfico por
> variável. Inclua: quantas avaliações entraram e quantas saíram, e por quê;
> o período coberto e quantas por mês; a nota média e a distribuição das
> estrelas, comparadas com a nota da página; a distribuição de cada variável
> do dicionário; a nota média em cada categoria; a concordância entre OpenAI,
> Jev e a nossa codificação, com três exemplos de discordância; e o que esta
> fonte não enxerga. Mostre o código que gerou cada número.

O relatório termina com o **cartão da hipótese**, que vocês escrevem:

> Na [companhia], a nota cai quando \_\_\_\_. Evidência: \_\_\_\_ (número e
> fonte). O que esta fonte não enxerga: \_\_\_\_.

## Se der tempo: sentenças do TJSP contra a sua companhia

A App Store mostra o que o cliente acha **do aplicativo**. Para saber o que
acontece **no voo**, outra fonte pública: a Consulta de Julgados de 1º Grau do
Tribunal de Justiça de São Paulo (<https://esaj.tjsp.jus.br/cjpg/>), sem login
e sem captcha. Se não der tempo, o professor demonstra.

| grupo | pesquisa livre | período | sentenças em 3/11/2026 |
|---|---|---|---|
| LATAM | `voo E (atraso OU cancelamento OU bagagem) E LATAM` | 01/08/2026 a 31/10/2026 | 152 |
| Gol | `voo E (atraso OU cancelamento OU bagagem) E GOL` | 01/08/2026 a 31/10/2026 | 134 |
| Azul | `voo E (atraso OU cancelamento OU bagagem) E AZUL` | 01/08/2026 a 31/10/2026 | 212 |
| TAP | `voo E (atraso OU cancelamento OU bagagem) E TAP` | 01/05/2026 a 31/10/2026 | 50 |

A TAP tem menos processos por mês, por isso o período é maior.

1. Façam a busca à mão: quantas sentenças, quantas por página, onde está o
   texto inteiro (o ícone **+** ao fim de cada resumo).
2. Peçam no Work:

   > Quero raspar sentenças da Consulta de Julgados de 1º Grau do TJSP
   > (https://esaj.tjsp.jus.br/cjpg/) com a pesquisa livre
   > "voo E (atraso OU cancelamento OU bagagem) E TAP", de 01/05/2026 a
   > 31/10/2026. Siga o ciclo do web scraping. Primeiro descubra que
   > requisição o botão Consultar faz e reproduza essa requisição em Python,
   > com todos os campos. Salve cada página de resultado em HTML numa pasta
   > brutos_tjsp/ antes de ler qualquer coisa. Depois leia os arquivos e monte
   > uma tabela com processo, classe, assunto, comarca, data e o texto inteiro
   > da sentença. No fim, confira se o número de sentenças lidas bate com o
   > total que o site anuncia. Uma página por vez, com 2 segundos de pausa.
   > Comece com 3 páginas e me mostre o resultado antes de baixar o resto.

3. Validem: o total bateu? Quantas sentenças são mesmo contra a sua companhia?
   (A palavra solta "GOL" ou "TAP" aparece em outros contextos.)
4. Extraiam as variáveis com `dicionario_sentencas.json` (ou um dicionário de
   vocês) e comparem com o que a App Store mostrou.

## Habilidade ou plugin?

Comecem pela conversa: o trabalho é novo e cada etapa precisa ser conferida.
Se a coleta virar rotina (toda semana, para a sua empresa ou um concorrente),
transformem o raspador numa **habilidade** que recebe o número de qualquer
aplicativo; a do professor é `skills/avaliacoes-app/`. Um **plugin** só
compensa para distribuir o pacote a outras equipes ou para gravar o resultado
num sistema da empresa.

## O que aconteceu na preparação

**App Store**

- O feed entregou 500 avaliações para cada uma das quatro companhias.
- As 500 mais recentes cobrem **períodos muito diferentes**: na Gol, de maio a
  outubro de 2026; na Azul, de julho a outubro; na LATAM, desde outubro de
  2025; na TAP, desde **2021**, porque o aplicativo recebe poucas avaliações
  no Brasil. Não é uma amostra aleatória: são as últimas.
- A nota média das 500 é bem menor que a nota da página (TAP: 1,8 nas 500,
  3,3 na página). A página soma todas as notas, inclusive as que vieram sem
  texto; quem escreve, em geral, escreve para reclamar.
- O feed traz o apelido de quem avaliou, e às vezes um e-mail. A tabela não
  deve guardar isso.

**Dicionário: duas armadilhas**

- **A opção que mistura duas coisas.** Numa avaliação, "o site parou de
  funcionar e, quando recomecei, o preço tinha subido R$ 200" é falha do
  aplicativo ou reclamação de preço? A OpenAI disse uma coisa, o Jev disse
  outra. Nenhum dos dois errou: o dicionário pedia **um** tema e o texto tinha
  dois. Ou se escolhe um critério ("o problema que a pessoa cita primeiro"),
  ou se criam duas variáveis sim/não.
- **A fonte decide o que dá para medir.** Nas avaliações da App Store, só 7% a
  18% falam do voo; o resto fala do aplicativo. Uma variável "o voo atrasou?"
  vai sair quase sempre "não", e isso não quer dizer que os voos não atrasam.

**Extração**, com `dicionario_avaliacoes.json`, nas 160 avaliações da amostra:

| variável | OpenAI e Jev concordam |
|---|---|
| reclama de atraso ou cancelamento | 100% |
| fala da experiência de voo | 98% |
| reclama de preço ou taxas | 98% |
| tom | 97% |
| tema principal | 82% |

- **Tema**: das 29 discordâncias, 15 são o Jev mandando para "outro" o que a
  OpenAI chamou de elogio ou de falha do aplicativo. Quando o Jev tem 95% de
  certeza ou mais, os dois concordam em 89% dos casos; abaixo de 80%, em 63%.
  Quando o Jev diz que está em dúvida, vale ler.
- **Tempo**: OpenAI, 1,4 s por avaliação (mediana); Jev, 0,2 s.

E nas 500 avaliações de cada companhia (OpenAI):

| | LATAM | Gol | Azul | TAP |
|---|---|---|---|---|
| nota média do aplicativo | 3,1 | 2,3 | 3,5 | 1,8 |
| tema: o aplicativo falha | 34% | 36% | 14% | 76% |
| tema: atraso ou cancelamento | 2% | 12% | 1% | 0% |
| tema: check-in e embarque | 7% | 12% | 19% | 2% |
| tema: elogio | 37% | 20% | 46% | 8% |
| fala da experiência de voo | 13% | 18% | 8% | 7% |

Na Gol, o atraso aparece até numa avaliação de aplicativo; na LATAM e na TAP,
o aplicativo é o assunto. Mas só de 7% a 18% das avaliações falam do voo. **A
App Store enxerga o aplicativo.**

**TJSP**

- **Todos os campos do formulário, mesmo os vazios.** Mandando só a busca e as
  datas, o site respondeu normalmente (código 200), mas **sem nenhum
  resultado**.
- **O total vem com tags no meio** ("Resultados `<strong>`1 a 10`</strong>` de
  152"). O primeiro leitor não achou o número e achou que a busca estava vazia.
- **Os parênteses mudam tudo.** `voo E atraso E (LATAM OU GOL OU AZUL)` trouxe
  398 sentenças; sem os parênteses, 134: só as da LATAM.
- **A busca traz ruído.** Na busca da TAP em 12 meses, 32 das 151 sentenças
  eram contra outras empresas (Ibéria, Air Europa, Azul, agências) que só
  citavam a TAP.
- Nas sentenças (85 a 160 por companhia), o retrato é outro: na Azul, 51% das
  ações são por cancelamento e a companhia alega manutenção em 54%; na Gol,
  37% são por atraso e só 15% das sentenças reconhecem assistência material;
  na TAP, 21% são por **bagagem** (2% a 6% nas outras), metade fala de
  **conexão** e o atraso mediano é de 18 horas. **O TJSP enxerga o voo.**

## Cuidados

- As sentenças são públicas, mas trazem **nomes de partes, advogados e
  juízes**. Usem para análise e não publiquem a base com nomes.
- O servidor é de todos: uma página por vez, com pausa, e só o período de que
  precisam.
- A chave de API é uma senha que gasta dinheiro: fica no `.env` e nunca é
  colada no chat.

## Gabarito

As habilidades e o script do professor:

```bash
python skills/avaliacoes-app/scripts/baixar_avaliacoes.py TAP --saida avaliacoes_tap.csv
python exercicios/03-base-avaliacoes/extrair.py avaliacoes_tap.csv --dicionario exercicios/03-base-avaliacoes/dicionario_avaliacoes.json --id id_avaliacao --modelo openai --saida extraido_openai.csv
python exercicios/03-base-avaliacoes/extrair.py avaliacoes_tap.csv --dicionario exercicios/03-base-avaliacoes/dicionario_avaliacoes.json --id id_avaliacao --modelo jev --saida extraido_jev.csv
python skills/raspar-tjsp/scripts/raspar_tjsp.py baixar --busca "voo E (atraso OU cancelamento OU bagagem) E TAP" --inicio 01/05/2026 --fim 31/10/2026 --pasta brutos_tjsp
python skills/raspar-tjsp/scripts/raspar_tjsp.py ler --pasta brutos_tjsp --saida sentencas_tap.csv
```

## O que vem depois

À tarde, cada grupo recebe `dados/voos_2026.csv`: 8.000 voos **simulados** de
2026, 2.000 por companhia, com a nota média da pesquisa pós-voo e o que
aconteceu em cada voo. É ali que a hipótese do cartão vai ser testada.
