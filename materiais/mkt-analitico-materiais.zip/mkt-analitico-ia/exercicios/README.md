# Exercícios de quarta e quinta

Os dois dias seguem uma linha só: **montar uma base de dados com o ChatGPT e
depois analisá-la**, sempre no mesmo setor, o de companhias aéreas. Na quarta
de manhã, vocês montam as ferramentas (uma habilidade e um plugin) e uma base
com o que os clientes escrevem na internet. A partir do exercício 3, a turma
trabalha em **quatro grupos, um por companhia** (LATAM, Gol, Azul e TAP): cada
grupo baixa as avaliações do aplicativo da sua companhia, cria as colunas com
IA, descreve a base e sai com uma hipótese. À tarde, a hipótese é testada numa
base de 8.000 voos simulados.

Na quinta de manhã, o caso muda para um mais simples de enxergar: o relatório
mensal de mídia da **Bora Bebidas**, uma marca fictícia. O objetivo é fazer o
mesmo relatório todo mês, com o mesmo resultado, e levar a receita para o time
como uma skill. Depois, um estúdio livre: cada um sai com uma peça de portfólio
do próprio trabalho.

Os exercícios são **em duplas** (no 3, duplas dentro do grupo da companhia),
no **aplicativo de desktop** do ChatGPT, no modo Work. Quem não conseguir
instalar o aplicativo usa o Work no navegador.

| exercício | parte | o que se aprende | pasta |
|---|---|---|---|
| 1. Uma habilidade que conta com Python | manhã | o script conta sempre igual; o modelo interpreta | `01-habilidade-python/` |
| 2. Um plugin que enriquece a planilha de agências | manhã | plugin; APIs públicas, testar antes de usar, grupos | `02-brasilapi/` |
| 3. Uma base com as avaliações da sua companhia | manhã | raspar e validar, dicionário de variáveis, extração com dois modelos, relatório exploratório | `03-base-avaliacoes/` |
| 4. Relatório descritivo | tarde | o gráfico certo para cada tipo de variável | `04-relatorio-descritivo/` e `dados/voos_2026.csv` |
| 5. Relatório analítico com regressão | tarde | regressão, leitura de coeficientes | `05-relatorio-analitico/` e `dados/voos_2026.csv` |
| 6. Um relatório que roda de novo | quinta, manhã | pasta organizada, `AGENTS.md`, passos, reprodutibilidade | `06-relatorio-reprodutivel/` e `dados/bora/` |
| 7. Outubro chegou | quinta, manhã | checagens de consistência, regras escritas | `07-checagens/` e `dados/bora/` |
| 8. O projeto vira uma skill | quinta, manhã | skill a partir de um projeto, a prova da reprodutibilidade | `08-skill-relatorio/` |
| 9. O seu portfólio de IA | quinta, estúdio | um problema do seu trabalho, em cinco trilhas | `09-estudio-portfolio/` |

## Antes de começar

- **Aplicativo de desktop**: o ChatGPT instalado no seu computador. No modo
  Work, ele trabalha **na sua máquina**, numa pasta que você escolhe, com a sua
  internet e os seus arquivos. É onde rodam todos os exercícios: alguns sites
  recusam o computador da nuvem (a BrasilAPI, no exercício 2), e as chaves de
  API (exercício 3) ficam num arquivo seu, sem passar pelo chat.
- **Work no navegador**: chatgpt.com, botão **Work** no alto da tela. O plano B.
- **Habilidades e plugins**: menu Personalizar (ícone de @ na barra da
  esquerda), abas Plugins e Habilidades. Para chamar um deles na conversa,
  digite `@` e o nome.
- **Versões do professor**: `skills/contar-termos/` (exercício 1),
  `02-brasilapi/gabarito/` (exercício 2), `skills/avaliacoes-app/`,
  `skills/raspar-tjsp/` e `03-base-avaliacoes/extrair.py` (exercício 3),
  `exemplos/relatorio-bora/` (exercícios 6 e 7) e `skills/relatorio-mensal-midia/`
  (exercício 8).
