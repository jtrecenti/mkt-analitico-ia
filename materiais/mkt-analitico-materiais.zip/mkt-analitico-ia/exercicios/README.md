# Exercícios de quarta e quinta

Os dois dias seguem uma linha só: **construir uma base de dados com o ChatGPT e
depois analisá-la**, sempre no mesmo setor, o de companhias aéreas. De manhã,
na quarta, vocês montam as ferramentas que transformam textos, APIs e páginas
em tabela. A partir das 11h, a turma trabalha em **quatro grupos, um por
companhia** (LATAM, Gol, Azul e TAP): cada grupo lê o que os clientes da sua
companhia escrevem e sai com uma hipótese. À tarde, a hipótese é testada numa
base de 8.000 voos simulados, em dois relatórios. Na quinta, transformam o trabalho num
projeto organizado e num painel publicado.

Os exercícios são **em duplas** (do 3 em diante, duplas dentro do grupo da companhia), no **aplicativo de desktop** do ChatGPT,
no modo Work. Quem não conseguir instalar o aplicativo usa o Work no navegador.
O pedido sai primeiro; a explicação vem enquanto o ChatGPT trabalha.

| exercício | quando | o que se aprende | material |
|---|---|---|---|
| 1. Uma habilidade que conta com Python | qua 9h | o script conta sempre igual; o modelo interpreta | `01-habilidade-python/grupo_focal_aerea_sol.txt` |
| 2. Um plugin que confere agências de viagem | qua 9h | plugin; APIs públicas, testar antes de usar, grupos | `02-brasilapi/agencias_parceiras.csv` |
| 3. Raspar o que os clientes escrevem | qua 11h | o ciclo do web scraping; validar com o site | as avaliações do aplicativo na App Store; se der tempo, sentenças do TJSP |
| 4. Escrever o dicionário de variáveis | qua 11h | decidir o que medir antes de pedir à IA | as avaliações baixadas, ou `04-dicionario/avaliacoes_amostra.csv` |
| 5. Extrair as variáveis e escrever a hipótese | qua 11h | API com chave, saída estruturada, conferência | `05-extracao/` |
| 6. Relatório descritivo | qua 14h | o gráfico certo para cada tipo de variável | `dados/voos_2026.csv` |
| 7. Relatório analítico com regressão | qua 16h | regressão, leitura de coeficientes, vazamento | `dados/voos_2026.csv` |
| 8. Do chat ao projeto | qui 9h | pastas, `AGENTS.md`, scripts que rodam de novo | o seu trabalho de quarta |
| 9. Um teste que pega o erro | qui 9h | testes automáticos para os erros que já aconteceram | o seu projeto |
| 10. Painel publicado | qui 11h | HTML estático, animação e GitHub Pages | o seu relatório descritivo |

## Antes de começar

- **Aplicativo de desktop**: o ChatGPT instalado no seu computador. No modo
  Work, ele trabalha **na sua máquina**, numa pasta que você escolhe, com a sua
  internet e os seus arquivos. É onde rodam todos os exercícios: alguns sites
  recusam o computador da nuvem (a BrasilAPI, no exercício 2), e as chaves de
  API (exercício 5) ficam num arquivo seu, sem passar pelo chat.
- **Work no navegador**: chatgpt.com, botão **Work** no alto da tela. O plano B.
- **Habilidades e plugins**: menu Personalizar (ícone de @ na barra da
  esquerda), abas Plugins e Habilidades. Para chamar um deles na conversa,
  digite `@` e o nome.
- **Versões do professor**: `skills/contar-termos/` (exercício 1),
  `02-brasilapi/gabarito/` (exercício 2), `skills/avaliacoes-app/` e `skills/raspar-tjsp/` (exercício 3) e
  `05-extracao/` (exercício 5).
