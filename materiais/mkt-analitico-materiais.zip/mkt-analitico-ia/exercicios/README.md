# Exercícios de quarta e quinta

Os dois dias seguem uma linha só: **montar uma base de dados com o ChatGPT e
depois analisá-la**, sempre no mesmo setor, o de companhias aéreas. Na quarta
de manhã, vocês montam as ferramentas (uma habilidade e um plugin) e uma base
com o que os clientes escrevem na internet. A partir do exercício 3, a turma
trabalha em **quatro grupos, um por companhia** (LATAM, Gol, Azul e TAP): cada
grupo baixa as avaliações do aplicativo da sua companhia, cria as colunas com
IA, descreve a base e sai com uma hipótese. À tarde, a hipótese é testada numa
base de 8.000 voos simulados.

Na quinta de manhã, as avaliações dos apps voltam, agora coletadas todo dia: o
relatório da quarta vira um **monitor** que junta as coletas sem contar repetidas,
roda checagens e publica uma página. Depois, um estúdio livre: cada um sai com
uma peça de portfólio do próprio trabalho, com a ajuda de um catálogo de
ferramentas de marketing.

Os exercícios são **em duplas** (no 3, duplas dentro do grupo da companhia),
no **aplicativo de desktop** do ChatGPT, no modo Work. Quem não conseguir
instalar o aplicativo usa o Work no navegador.

| exercício | parte | o que se aprende | pasta |
|---|---|---|---|
| 1. Uma habilidade que conta com Python | manhã | o script conta sempre igual; o modelo interpreta | `01-habilidade-python/` |
| 2. Um plugin que enriquece a planilha de agências | manhã | plugin; APIs públicas, testar antes de usar, grupos | `02-brasilapi/` |
| 3. Uma base com as avaliações da sua companhia | manhã | raspar e validar, dicionário de variáveis, extração com dois modelos, relatório exploratório | `03-base-avaliacoes/` |
| 4. Relatório descritivo | tarde | o gráfico certo para cada tipo de variável | `04-relatorio-descritivo/` e `dados/voos_2026.csv` |
| 5. Relatório analítico com regressão | tarde | regressão, leitura de coeficientes | `05-relatorio-analitico/` e `dados/voos_2026.csv` |
| 6. Um monitor que roda todo dia | quinta, manhã | pasta organizada, `AGENTS.md`, checagens de consistência | `06-monitor-avaliacoes/` e `dados/app/` |
| 7. A skill e a página no ar | quinta, manhã | skill a partir do projeto, página estática no Netlify Drop | `07-skill-e-pagina/` |
| 8. O seu portfólio de IA | quinta, estúdio | um problema do seu trabalho, em cinco trilhas | `08-estudio-portfolio/` |

## Antes de começar

- **Aplicativo de desktop**: o ChatGPT instalado no seu computador. No modo
  Work, ele trabalha **na sua máquina**, numa pasta que você escolhe, com a sua
  internet e os seus arquivos. É onde rodam todos os exercícios: alguns sites
  recusam o computador da nuvem (a BrasilAPI, no exercício 2), e as chaves de
  API (exercício 3) ficam num arquivo seu, sem passar pelo chat.
- **Work no navegador**: chatgpt.com, botão **Work** no alto da tela. O plano B.
- **Habilidades e plugins**: menu Personalizar (ícone de @ na barra da
  esquerda), abas Plugins e Habilidades. Para chamar um deles na conversa,
  digite `@` e o nome.
- **Versões do professor**: `skills/contar-termos/` (exercício 1),
  `02-brasilapi/gabarito/` (exercício 2), `skills/avaliacoes-app/`,
  `skills/raspar-tjsp/` e `03-base-avaliacoes/extrair.py` (exercício 3),
  `exemplos/monitor-app/` (exercício 6) e `skills/monitor-avaliacoes-app/`
  (exercício 7).
