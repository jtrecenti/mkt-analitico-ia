# Exercício 5. Extrair as variáveis com OpenAI e Jev, e escrever a hipótese

**Onde:** aplicativo de desktop, modo Work, numa pasta do seu computador.
**Em grupo, uma companhia por grupo** (dentro do grupo, em duplas).
**Tempo:** 40 minutos.

Com o dicionário pronto, um modelo de linguagem lê cada avaliação e preenche
as colunas. Vamos usar dois, pela API:

- **OpenAI** (`gpt-5.6-luna`), com **saída estruturada**: o modelo é obrigado a
  responder num formato fixo, com as opções do seu dicionário. Também responde
  números.
- **Jev**, da TypeSafe: um modelo que **não escreve texto**. Ele só responde
  perguntas tipadas (uma opção de uma lista, sim/não) e diz a probabilidade de
  cada resposta. É bem mais rápido e mais barato, e não gera números.

## Por que no aplicativo de desktop

Uma chave de API é uma senha que gasta dinheiro. Ela fica num arquivo `.env` na
sua pasta de trabalho e **nunca** é colada no chat. No aplicativo de desktop, o
script lê a chave do arquivo sem que ela passe pela conversa.

## Material

- As avaliações da sua companhia (do exercício 3, ou as 40 dela em
  `avaliacoes_amostra.csv`), o seu `dicionario.csv` e a sua
  `codificacao_manual.csv`;
- `dicionario_avaliacoes.json` e `extrair.py`: a versão do professor, para
  comparar (há também `dicionario_sentencas.json`, para quem raspou o TJSP);
- as chaves, que o professor entrega na sala.

## Passos

1. Crie uma pasta de trabalho com os arquivos e um arquivo `.env`:

   ```
   OPENAI_API_KEY=...
   JEV_API_KEY=...
   ```

2. No aplicativo de desktop, abra a pasta e peça:

   > Nesta pasta há avaliações do aplicativo da nossa companhia
   > (avaliacoes_tap.csv) e o nosso dicionário de variáveis (dicionario.csv).
   > Escreva um script Python que extraia essas variáveis de cada avaliação
   > usando a API da OpenAI com saída estruturada e, separadamente, a API do
   > Jev (pacote typesafe-sdk). As chaves estão no .env: leia de lá e nunca as
   > mostre. Teste com 5 avaliações antes de rodar todas. No fim, compare os
   > dois modelos e a nossa codificação manual (codificacao_manual.csv): em
   > quantos por cento concordam, variável por variável?

3. **Leiam os casos em que discordam.** Quem errou: a OpenAI, o Jev, vocês ou a
   pergunta?
4. **Escrevam a hipótese do grupo** (10 min). Com a tabela extraída, peçam a
   distribuição de cada variável e a nota média em cada categoria. Depois
   completem, num cartão:

   > Na [companhia], a nota cai quando \_\_\_\_. Evidência: \_\_\_\_ (número e fonte).
   > O que esta fonte não enxerga: \_\_\_\_.

## Entrega

A tabela de concordância por variável (OpenAI × Jev × vocês), **uma pergunta
do dicionário que vocês reescreveriam** e **o cartão com a hipótese**. O
cartão volta às 14h.

## O que aconteceu na preparação

Com `dicionario_avaliacoes.json`, nas 160 avaliações da amostra:

| variável | OpenAI e Jev concordam |
|---|---|
| reclama de atraso ou cancelamento | 100% |
| fala da experiência de voo | 98% |
| reclama de preço ou taxas | 98% |
| tom | 97% |
| tema principal | 82% |

- **Tema**: das 29 discordâncias, 15 são o Jev mandando para "outro" o que a
  OpenAI chamou de elogio ou de falha do aplicativo. Quando o Jev tem 95% de
  certeza ou mais, os dois concordam em 89% dos casos; abaixo de 80%, em 63%.
  Quando o Jev diz que está em dúvida, vale ler.
- **Tempo**: OpenAI, 1,4 s por avaliação (mediana); Jev, 0,2 s.

E nas 500 avaliações de cada companhia (OpenAI):

| | LATAM | Gol | Azul | TAP |
|---|---|---|---|---|
| nota média do aplicativo | 3,1 | 2,3 | 3,5 | 1,8 |
| tema: o aplicativo falha | 34% | 36% | 14% | 76% |
| tema: atraso ou cancelamento | 2% | 12% | 1% | 0% |
| tema: check-in e embarque | 7% | 12% | 19% | 2% |
| tema: elogio | 37% | 20% | 46% | 8% |
| fala da experiência de voo | 12% | 18% | 8% | 7% |

O que se vê: na Gol, o atraso aparece até numa avaliação de aplicativo; na
LATAM e na TAP, o aplicativo é o assunto. Mas só de 7% a 18% das avaliações
falam do voo. **A App Store enxerga o aplicativo.**

Nas sentenças do TJSP (85 a 160 por companhia), o retrato é outro: na Azul,
51% das ações são por cancelamento e a companhia alega manutenção em 54%; na
Gol, 37% são por atraso e só 15% das sentenças reconhecem assistência
material; na TAP, 21% são por **bagagem** (2% a 6% nas outras), metade fala de
**conexão** e o atraso mediano é de 18 horas. **O TJSP enxerga o voo.**

```bash
python extrair.py avaliacoes_amostra.csv --dicionario dicionario_avaliacoes.json --id id_avaliacao --modelo openai --saida extraido_openai.csv
python extrair.py avaliacoes_amostra.csv --dicionario dicionario_avaliacoes.json --id id_avaliacao --modelo jev --saida extraido_jev.csv
```

## O que vem depois

À tarde, cada grupo recebe `dados/voos_2026.csv`: 8.000 voos **simulados** de
2026, 2.000 por companhia, com a nota média da pesquisa pós-voo e o que
aconteceu em cada voo (atraso, cancelamento, conexões perdidas, bagagem, falha
no check-in pelo aplicativo). É ali que a hipótese do cartão vai ser testada.
