# Exercício 5. Extrair as variáveis com OpenAI e Jev

**Onde:** aplicativo de desktop, modo Work, numa pasta do seu computador.
**Em duplas.** **Tempo:** 35 minutos.

Com o dicionário pronto, um modelo de linguagem lê cada sentença e preenche as
colunas. Vamos usar dois, pela API:

- **OpenAI** (`gpt-5.6-luna`), com **saída estruturada**: o modelo é obrigado a
  responder num formato fixo, com as opções do seu dicionário. Também responde
  números (o valor da indenização).
- **Jev**, da TypeSafe: um modelo que **não escreve texto**. Ele só responde
  perguntas tipadas (uma opção de uma lista, sim/não) e diz a probabilidade de
  cada resposta. É bem mais rápido e mais barato, e não gera números.

## Por que no aplicativo de desktop

Uma chave de API é uma senha que gasta dinheiro. Ela fica num arquivo `.env` na
sua pasta de trabalho e **nunca** é colada no chat. No aplicativo de desktop, o
script lê a chave do arquivo sem que ela passe pela conversa.

## Material

- `sentencas_amostra.csv` (do exercício 4), o seu `dicionario.csv` e a sua
  `codificacao_manual.csv`;
- `dicionario_sentencas.json` e `extrair.py`: a versão do professor, para
  comparar;
- as chaves, que o professor entrega na sala.

## Passos

1. Crie uma pasta de trabalho com os arquivos e um arquivo `.env`:

   ```
   OPENAI_API_KEY=...
   JEV_API_KEY=...
   ```

2. No aplicativo de desktop, abra a pasta e peça:

   > Nesta pasta há sentenças (sentencas_amostra.csv) e o meu dicionário de
   > variáveis (dicionario.csv). Escreva um script Python que extraia essas
   > variáveis de cada sentença usando a API da OpenAI com saída estruturada
   > e, separadamente, a API do Jev (pacote typesafe-sdk). As chaves estão no
   > .env: leia de lá e nunca as mostre. Teste com 5 sentenças antes de rodar
   > todas. No fim, compare os dois modelos e a minha codificação manual
   > (codificacao_manual.csv): em quantos por cento concordam, variável por
   > variável?

3. **Leiam os casos em que discordam.** Quem errou: a OpenAI, o Jev, vocês ou a
   pergunta?

## Entrega

Uma tabela de concordância por variável (OpenAI × Jev × vocês), o tempo de cada
modelo e **uma pergunta do dicionário que vocês reescreveriam**.

## O que aconteceu na preparação

Com `dicionario_sentencas.json`, nas 40 sentenças:

| variável | OpenAI e Jev concordam |
|---|---|
| dano moral concedido | 100% |
| criança ou idoso entre os autores | 100% |
| dano material concedido | 97,5% |
| problema principal | 95% |
| faixa do dano moral | 95% |
| motivo alegado pela companhia | 90% |
| assistência material | 82,5% |
| resultado | 80% |

- **Resultado**: as 8 discordâncias são todas "procedente" (OpenAI) contra
  "parcialmente procedente" (Jev). O juiz escreveu "julgo procedente"; a
  definição da opção dizia "ganhou tudo o que pediu". A OpenAI seguiu as
  palavras do juiz, o Jev seguiu a definição. A pergunta estava mal escrita.
- **Assistência material**: o Jev ficou abaixo de 80% de confiança em 13
  sentenças, e é nelas que estão 6 das 7 discordâncias. Quando o Jev diz que está
  em dúvida, vale ler.
- **Tempo**: OpenAI, 3,7 s por sentença (mediana); Jev, 0,2 s.
- **O que as sentenças dizem** (OpenAI): dano moral em 31 das 40, mediana de
  R$ 6.000; o motivo mais alegado pelas companhias foi manutenção (22 de 40).
  São 40 casos: servem para conferir a extração, não para comparar
  companhias.

```bash
python extrair.py sentencas_amostra.csv --dicionario dicionario_sentencas.json --id id_sentenca --modelo openai --saida extraido_openai.csv
python extrair.py sentencas_amostra.csv --dicionario dicionario_sentencas.json --id id_sentenca --modelo jev --saida extraido_jev.csv
```

## O que vem depois

À tarde vocês recebem `dados/relatos_estruturados.csv`: 3.442 reclamações de
2024 no consumidor.gov.br, coletadas quando os relatos eram públicos, com
variáveis extraídas por este mesmo script (com outro dicionário,
`dicionario_relatos.json`). É a base dos relatórios das 14h e das 16h.
