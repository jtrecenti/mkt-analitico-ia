# Exercício 8. O seu portfólio de IA

**Onde:** aplicativo de desktop do ChatGPT, modo Work. **Individual ou em dupla.**

Um estúdio livre. Cada pessoa escolhe um problema do próprio trabalho e sai com
**uma coisa que funciona**: uma skill, um plugin, um relatório reprodutível ou
um painel. O professor passa pelas mesas em três paradas: o problema, o
primeiro resultado e a ficha pronta.

## 1. Escolha o problema

Procure no seu trabalho:

- **tarefas repetidas**: o relatório de toda segunda, a planilha consolidada
  todo mês;
- **textos em volume**: avaliações, NPS, chamados do SAC, comentários;
- **cadastros a enriquecer**: CNPJ, CEP, setor, região;
- **relatórios refeitos à mão**: o mesmo gráfico, com dados novos, montado do
  zero a cada vez.

Prefira a tarefa **frequente**, que **toma tempo** e cujo erro tem **risco
baixo**. Escreva em uma frase o que vai existir no fim: "uma skill que
transforma a exportação do SAC num resumo semanal por tema", por exemplo.

## 2. Escolha a trilha

### A. Uma skill para uma tarefa sua

> Quero criar uma skill para [tarefa], que eu faço [frequência]. Hoje eu
> [como faço, passo a passo]. A entrada é [arquivo ou texto] e a saída é
> [tabela, texto, relatório]. Me faça perguntas até entender o processo, depois
> escreva o SKILL.md com os passos, as regras e um exemplo, e teste a skill
> com [um caso de exemplo, sem dado pessoal].

Teste numa conversa nova: a skill dá o mesmo resultado sem você explicar de
novo?

### B. Um plugin com dado público

APIs abertas e sem chave: BrasilAPI (CNPJ, CEP, feriados), IBGE (população,
renda, municípios), Banco Central (câmbio, Selic, IPCA).

> Quero um plugin que, a partir de [uma coluna da minha planilha: CNPJ, CEP,
> data], busque [o dado] na [API] e acrescente as colunas [quais]. Mostre a
> chamada para uma linha antes de rodar em todas, diga quantas linhas
> entraram, quantas voltaram com dado e quantas falharam, e por quê.

### C. O relatório reprodutível da manhã, com dados da sua área

Use uma base da sua área **sem nenhum dado pessoal** (agregada, anonimizada ou
sintética).

> Organize esta pasta como um monitor reprodutível, como no exercício 6:
> um AGENTS.md com as regras, os passos numerados, as checagens de consistência
> que precisam passar antes de qualquer número e o relatório do período [X].
> Depois, transforme o processo numa skill que eu rodo quando chegar o
> próximo período.

### D. Explorar a fundo o que já existe

Escolha duas ou três skills ou plugins que já vêm no ChatGPT Work e teste com
uma tarefa real.

Antes, passe pelo **catálogo de ferramentas** do site (jtrecenti.github.io/mkt-analitico-ia/catalogo):
mais de cem skills, plugins e ferramentas de marketing, por tarefa, com preço.

> Quais skills e plugins estão disponíveis aqui? Para cada um, diga em uma
> frase o que faz e um uso em [minha área]. Depois vamos testar [o escolhido]
> com [a minha tarefa].

Anote o que funcionou, onde falhou e quando você usaria cada um.

### E. Um painel numa página, publicado

Publicado no Netlify Drop, como no exercício 7. O roteiro completo está em
[`trilha-painel.md`](trilha-painel.md).

## 3. Teste com um caso real e preencha a ficha

Rode o que você fez com um caso que não usou para construir. Confira um número
à mão. Depois, copie a ficha abaixo, preencha e cole no mural (quiz do site).

```
FICHA DE PORTFÓLIO
Problema: [o que era feito à mão, por quem, com que frequência]
O que a IA faz: [skill, plugin, relatório ou painel, em uma frase]
Antes e depois: [tempo, erros ou alcance, com um número]
Como rodar de novo: [onde está o arquivo e qual é o pedido]
Próximo passo: [o que falta para o time usar]
```

## Cuidados com os dados

- **A LGPD vale para planilha também.** Nada de nome, CPF, e-mail, telefone
  ou identificador de cliente. Use agregados, uma amostra sem identificação ou
  dados sintéticos (peça ao agente para gerar uma base parecida com a sua).
- **Dado de cliente, só em ferramenta aprovada.** O ChatGPT do Insper não é a
  ferramenta da sua empresa. Lá, pergunte antes o que pode entrar.
- **Chaves de API no `.env`**, nunca no texto da conversa nem dentro do script.
- **Confira o que sai.** Antes de publicar ou enviar, abra o arquivo e procure
  dado pessoal.
