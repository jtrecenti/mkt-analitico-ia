# Trilha base. O painel das avaliações de um app

**Onde:** aplicativo de desktop do ChatGPT, modo Work, e o navegador.

Um painel estático, publicado, sobre as avaliações de **um aplicativo que você
escolher** na App Store: o da sua empresa, o de um concorrente ou o de um
serviço que você usa. No fim, um endereço que alguém abre no celular entre duas
reuniões e entende em cinco segundos.

O exemplo pronto, para usar de ideia, é o painel das quatro companhias aéreas:
[jtrecenti.github.io/mkt-analitico-ia/painel-app](https://jtrecenti.github.io/mkt-analitico-ia/painel-app/)
(no navegador, Ctrl+U mostra o código).

## Quem faz o quê

| etapa | onde acontece | o que sai |
|---|---|---|
| 1. coletar | modo Work, com a habilidade `avaliacoes-app` | as 500 avaliações mais recentes do app, num CSV |
| 2. estruturar | modo Work, com a habilidade `estruturar-textos` e o Jev | o tema de cada avaliação e se ela reclama de algo |
| 3. calcular | modo Work, num script Python | só agregados: nota por semana, distribuição, temas |
| 4. mostrar | um `index.html` | os agregados embutidos na página, com os gráficos |
| 5. publicar | Netlify Drop | o link |

## Quem coleta e quem mostra

**Coletar e calcular é trabalho do Python; mostrar é trabalho da página.** A
página recebe os números prontos e não baixa nada sozinha. Para
atualizar o painel, rode a coleta de novo (ou peça uma tarefa agendada) e
arraste a pasta nova no mesmo site do Netlify.

## Como achar o app

Na App Store (no navegador: apps.apple.com/br), o endereço do app termina com
um número: `apps.apple.com/br/app/latam-airlines/id1497908631`. A habilidade
aceita esse número (`--id 1497908631`).

## As cinco partes de um painel

1. **Título e conclusão**: o título diz o assunto; logo abaixo, a conclusão em
   uma frase, com o número ("a nota do último mês caiu para 1,4").
2. **Filtro**: um clique troca o recorte (o app, o período). Pouca opção.
3. **Números-chave**: de 3 a 5, cada um com uma frase que diz o que ele é.
4. **Gráficos**: um por pergunta, ordenados, com rótulo direto e uma cor de
   destaque; o resto em cinza.
5. **Rodapé**: fonte, data da coleta e o aviso de que só há agregados.

## O pedido

> Use a habilidade avaliacoes-app para baixar as avaliações do app
> [nome ou id do app] na App Store do Brasil. Depois, num script Python,
> anote cada avaliação com o Jev, pela habilidade estruturar-textos (a chave
> JEV_API_KEY está no .env): o tema principal, com opções que vamos combinar,
> e se ela reclama de algo. Teste em 10 avaliações antes de rodar em todas.
> Depois, num script Python, calcule só agregados: a nota média por semana, a
> distribuição das notas e os temas das reclamações. Me mostre os números
> antes de seguir.
>
> Faça um painel estático: um único index.html, numa pasta só para ele, com os
> agregados embutidos (a página não baixa nada). No topo, a conclusão em uma
> frase, com o número; de 3 a 5 números-chave; gráficos em ECharts, ordenados,
> com rótulos diretos e uma cor de destaque; um filtro por [app ou período] com
> transições suaves; rodapé com fonte e data. Que funcione no celular e
> respeite quem configurou o sistema para reduzir movimento. Nenhum texto de
> avaliação nem apelido na página.

Quer comparar com um concorrente? Peça dois apps e um filtro entre eles.

## Como publicar

- **Netlify Drop** (o caminho principal): crie uma conta grátis no Netlify,
  abra app.netlify.com/drop e arraste a pasta que tem o `index.html`. Sem
  conta, o site fica com senha temporária e some em uma hora. Para atualizar,
  arraste a pasta nova no mesmo site.
- **Sites do ChatGPT** (@Sites): o Work publica a página e devolve um link. Em
  contas de empresa, a publicação pública pode estar desligada.
- **Enviar o arquivo**: um HTML único abre no navegador de quem recebe.

O que está na página é visível para quem tem o link: **só agregados**.

## Sete conferências antes de mandar o link

1. A frase do topo responde à pergunta, com o número.
2. Os números batem com o CSV: uma média conferida à mão.
3. Cada gráfico: ordem, sem ruído, destaque, título que diz o que mostra.
4. Fonte e data da coleta no rodapé.
5. Só agregados: nenhum texto de avaliação, nenhum apelido.
6. No celular: abre, cabe e dá para ler.
7. Movimento só onde algo muda.

## Para ir além

- **Pyodide ou DuckDB-WASM**: contas dentro da página (o gestor escolhe a
  planilha, e o Python ou o SQL rodam no navegador dele). A página continua
  estática.
- **Microsoft Clarity**: mapas de calor e gravações, grátis, para saber se
  alguém usa o filtro. Avise no rodapé (LGPD).
