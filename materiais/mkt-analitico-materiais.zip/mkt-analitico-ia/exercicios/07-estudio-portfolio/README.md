# Exercício 7. O seu portfólio de IA

**Onde:** aplicativo de desktop do ChatGPT, modo Work. **Individual ou em dupla.**

Primeiro, uma conversa com o ChatGPT monta a **matriz de oportunidades** do seu
trabalho. Depois, um estúdio com uma **trilha base**, que todos podem seguir (o painel estático
das avaliações de um app que você escolher, publicado no Netlify Drop), e
quatro **alternativas** para quem já tem um problema próprio: uma skill, um
plugin, um monitor com dados da sua área ou o teste de ferramentas do catálogo.
Todo mundo sai com **uma coisa que funciona**. O professor passa pelas mesas em
três paradas: o problema, o primeiro resultado e a ficha pronta.

## Parte 1. A sua matriz de oportunidades

Antes de construir, descubra o que vale construir. Numa conversa nova do
ChatGPT, cole o pedido abaixo e responda às perguntas, uma de cada vez. Se
preferir, responda falando: no app, toque no ícone de voz. Não use nome de
cliente nem dado pessoal nas respostas.

> Quero descobrir onde a IA pode me ajudar no trabalho. Me entreviste, uma
> pergunta de cada vez, e espere a minha resposta antes da próxima:
>
> 1. O que eu faço no trabalho: área, cargo e as principais entregas.
> 2. Qual tarefa tomou mais tempo na última semana? E na penúltima? Quanto
>    tempo, mais ou menos?
> 3. O que se repete toda semana ou todo mês, sempre do mesmo jeito?
> 4. Quais tarefas eu menos gosto de fazer, e por quê?
> 5. Onde eu copio e colo dados de um sistema para outro?
> 6. Que textos eu leio em volume (avaliações, NPS, chamados, e-mails,
>    entrevistas)?
> 7. Que relatório ou apresentação eu refaço do zero com dados novos?
>
> Para cada tarefa que aparecer, pergunte com que frequência acontece, quanto
> tempo leva, onde está o dado e o que acontece se sair um erro. Procure
> oportunidades em quatro famílias: tarefas e relatórios que se repetem, textos
> em volume, cadastros e integração de sistemas, pesquisa e conteúdo.
>
> No fim, monte a matriz de oportunidades: no eixo horizontal, quanto tempo a
> tarefa toma por mês; no vertical, quão fácil é passar para a IA (o dado está
> à mão, a regra é clara, o erro tem risco baixo). Desenhe a matriz como um
> gráfico, com uma tabela embaixo (tarefa, horas por mês, facilidade de 1 a 5,
> quadrante e a ferramenta do curso que resolveria: skill, plugin, monitor ou
> ferramenta do catálogo). Recomende uma tarefa do quadrante "comece por aqui"
> para eu fazer hoje, e diga em uma frase o que vai existir no fim.

Os quadrantes: **comece por aqui** (muito tempo, fácil para a IA), **ganho
rápido** (pouco tempo, fácil), **projeto maior** (muito tempo, difícil: vale com
a TI junto) e **deixe como está** (pouco tempo, difícil). A matriz é uma
adaptação da matriz de Eisenhower e da matriz de impacto e esforço.

Guarde a matriz: ela entra na ficha de portfólio.

## Parte 2. Um item para o seu portfólio

Com a tarefa escolhida, siga uma das trilhas abaixo. Escreva em uma frase o que
vai existir no fim: "uma skill que transforma a exportação do SAC num resumo
semanal por tema", por exemplo. Quem não achou uma tarefa própria segue a
trilha base.

### Trilha base: o painel das avaliações de um app

Para quem quer um caminho do começo ao fim. Escolha um app na App Store (o da
sua empresa, o de um concorrente ou o de um serviço que você usa). No modo
Work, a habilidade `avaliacoes-app` baixa as 500 avaliações mais recentes e um
script calcula só os agregados (nota por semana, distribuição, temas). A página
recebe esses números prontos, embutidos no HTML, e vai para o Netlify Drop.

A página não baixa os dados sozinha: o feed da Apple não entrega avaliações
para páginas abertas no navegador, e a maioria dos sites bloqueia esse tipo de
pedido (CORS). Coletar é trabalho do Python; mostrar é trabalho da página.

Exemplo pronto: [jtrecenti.github.io/mkt-analitico-ia/painel-app](https://jtrecenti.github.io/mkt-analitico-ia/painel-app/).
O roteiro completo está em [`trilha-painel.md`](trilha-painel.md).

### As alternativas, para quem já tem um problema próprio

#### A. Uma skill para uma tarefa sua

> Quero criar uma skill para [tarefa], que eu faço [frequência]. Hoje eu
> [como faço, passo a passo]. A entrada é [arquivo ou texto] e a saída é
> [tabela, texto, relatório]. Me faça perguntas até entender o processo, depois
> escreva o SKILL.md com os passos, as regras e um exemplo, e teste a skill
> com [um caso de exemplo, sem dado pessoal].

Teste numa conversa nova: a skill dá o mesmo resultado sem você explicar de
novo?

#### B. Um plugin com dado público

APIs abertas e sem chave: BrasilAPI (CNPJ, CEP, feriados), IBGE (população,
renda, municípios), Banco Central (câmbio, Selic, IPCA).

> Quero um plugin que, a partir de [uma coluna da minha planilha: CNPJ, CEP,
> data], busque [o dado] na [API] e acrescente as colunas [quais]. Mostre a
> chamada para uma linha antes de rodar em todas, diga quantas linhas
> entraram, quantas voltaram com dado e quantas falharam, e por quê.

#### C. Um monitor reprodutível com dados da sua área

Use uma base da sua área **sem nenhum dado pessoal** (agregada, anonimizada ou
sintética).

> Organize esta pasta como um monitor reprodutível, como no exercício 6:
> um AGENTS.md com as regras, os passos numerados, as checagens de consistência
> que precisam passar antes de qualquer número e o relatório do período [X].
> Depois, transforme o processo numa skill que eu rodo quando chegar o
> próximo período.

#### D. Explorar a fundo o que já existe

Escolha duas ou três skills ou plugins que já vêm no ChatGPT Work e teste com
uma tarefa real.

Antes, passe pelo **catálogo de ferramentas** do site (jtrecenti.github.io/mkt-analitico-ia/catalogo):
117 ferramentas de marketing que se controlam pelo ChatGPT ou pelo Claude (conector,
MCP ou chave de API), filtráveis por tarefa, com preço.

> Quais skills e plugins estão disponíveis aqui? Para cada um, diga em uma
> frase o que faz e um uso em [minha área]. Depois vamos testar [o escolhido]
> com [a minha tarefa].

Anote o que funcionou, onde falhou e quando você usaria cada um.

## Parte 3. Teste com um caso real e preencha a ficha

Rode o que você fez com um caso que não usou para construir. Confira um número
à mão. Depois, copie a ficha abaixo e preencha.

```
FICHA DE PORTFÓLIO
Matriz: [as tarefas que apareceram e o quadrante da escolhida]
Problema: [o que era feito à mão, por quem, com que frequência]
O que a IA faz: [skill, plugin, relatório ou painel, em uma frase]
Antes e depois: [tempo, erros ou alcance, com um número]
Como rodar de novo: [onde está o arquivo e qual é o pedido]
Próximo passo: [o que falta para o time usar]
```

## Cuidados com os dados

- **A LGPD vale para planilha também.** Nada de nome, CPF, e-mail, telefone
  ou identificador de cliente. Use agregados, uma amostra sem identificação ou
  dados sintéticos (peça ao agente para gerar uma base parecida com a sua).
- **Dado de cliente, só em ferramenta aprovada.** O ChatGPT do Insper não é a
  ferramenta da sua empresa. Lá, pergunte antes o que pode entrar.
- **Chaves de API no `.env`**, nunca no texto da conversa nem dentro do script.
- **Confira o que sai.** Antes de publicar ou enviar, abra o arquivo e procure
  dado pessoal.
