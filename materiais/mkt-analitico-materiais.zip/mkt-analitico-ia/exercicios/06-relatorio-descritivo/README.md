# Exercício 6. Relatório descritivo

**Onde:** aplicativo de desktop, modo Work (plano B: Work no navegador).
**Em duplas.** **Tempo:** 50 minutos, em duas rodadas: o pedido sai às 14h e
é conferido às 15h05, depois da explicação.

Um relatório de duas páginas para a diretoria de **uma** das três companhias:
o que 3.442 reclamações dizem, em três perguntas e três gráficos.

## Material

- `dados/relatos_estruturados.csv` e `dados/dicionario.md` (anexe os dois);
- a habilidade `raio-x-planilha`, que está no pacote em `skills/raio-x-planilha/`
  (Personalizar → Habilidades → Adicionar → Carregar do seu computador);
- a habilidade `insper relatorio word`, já instalada pelo Insper.

## Passos

1. **Escolha a companhia** e escreva **três perguntas** de negócio. Exemplos:
   - Do que os nossos clientes mais reclamam, e isso é diferente das concorrentes?
   - Que tipo de problema acaba com nota baixa?
   - Respondemos mais rápido ou mais devagar que as outras?
2. **Para cada pergunta**, anote as colunas e o **tipo** de cada uma, e escolha
   o gráfico pela tabela do par de tipos:

   | as duas variáveis | o gráfico |
   |---|---|
   | numérica × categórica | boxplot, um por grupo |
   | categórica × categórica | barras de proporção, ou barras 100% |
   | numérica × numérica | pontos |
   | tempo × qualquer uma | linha |

3. **Peça cada gráfico com um pedido completo.** Um exemplo:

   > Pergunta: a proporção de notas baixas (1 ou 2) muda conforme o problema
   > relatado? `problema` é categórica nominal; nota baixa é sim/não. Faça
   > barras horizontais de proporção, ordenadas, com o n de cada problema ao
   > lado e o eixo começando no zero. Título com a conclusão. Antes, confira a
   > base com a habilidade raio-x-planilha e me mostre o código do gráfico.

4. **Confira as seis coisas**: título com conclusão; tipo combinando com o
   gráfico; barras no zero; n visível; cor só para destacar; fonte, período e
   base.
5. **Peça o relatório** em Word, com a habilidade `insper relatorio word`: uma
   página de resumo com as três conclusões e uma página com os gráficos.

## Entrega

O relatório em Word e **o gráfico que você teve que corrigir**, com o que estava
errado na primeira versão.
