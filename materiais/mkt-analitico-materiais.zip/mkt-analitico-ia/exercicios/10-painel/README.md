# Exercício 10. Um painel publicado

**Onde:** Codex (aplicativo de desktop) ou ChatGPT Work. **Tempo:** 80 minutos.

Uma página que responde a **uma** pergunta do seu relatório descritivo, num
endereço que a diretoria abre no celular.

## Material

- o relatório do exercício 6;
- `dados/relatos_estruturados_v2.csv` (a base corrigida depois da auditoria) ou
  o seu recorte do consumidor.gov.br (exercício 3);
- o painel de exemplo, no site do curso (Ctrl+U mostra o código).

## O pedido

> Quero um painel em uma página (HTML estático) sobre [minha base], para
> [quem vai ler], que responda: [a pergunta principal].
>
> 1. Escreva um script que gere `dados.json` só com agregados (nenhuma linha
>    individual, nenhum dado pessoal). Mostre os números antes de seguir.
> 2. Faça `index.html` com: uma manchete que dá a resposta em uma frase; de 3 a
>    5 números-chave; 2 ou 3 gráficos (ordenados, rótulos diretos, uma cor de
>    destaque); um filtro por [empresa/período].
> 3. Use GSAP para as transições do filtro: as mesmas barras mudam de tamanho e
>    de lugar. Respeite `prefers-reduced-motion`.
> 4. Paleta da Educação Executiva Insper: azul #0E171D, cinzas, vermelho
>    #E50505 só no destaque. Fonte Inter. Rodapé com fonte e data dos dados.
> 5. Teste no celular. Depois, publique e me dê o link.

## Sete conferências antes de mandar o link

1. A manchete responde à pergunta em uma frase.
2. Os números batem com a base (total de linhas, uma média conferida à mão).
3. Cada gráfico: ordem, sem ruído, destaque, título que conclui.
4. Fonte e data no rodapé.
5. Só agregados no `dados.json`.
6. No celular: abre, cabe e dá para ler.
7. Movimento só onde algo muda, e a versão parada funciona.

## Entrega

O link do painel publicado, no quiz.
