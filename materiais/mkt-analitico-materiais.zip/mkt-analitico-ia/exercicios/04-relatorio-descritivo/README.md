# Exercício 4. Relatório descritivo

**Onde:** aplicativo de desktop, modo Work (plano B: Work no navegador).
**Em duplas**, dentro do grupo da manhã. Duas rodadas: o pedido sai no
começo da aula e é conferido depois da explicação.

Cada grupo continua com a companhia da manhã (LATAM, Gol, Azul ou TAP) e faz um
relatório de duas páginas para a diretoria dela: como foram os voos de 2026, em
três perguntas e três gráficos. A primeira pergunta é a **hipótese que o grupo
tirou dos textos de manhã**.

## Material

- `dados/voos_2026.csv`: 8.000 voos **simulados**, de janeiro a outubro de
  2026, 2.000 de cada companhia, uma linha por voo. O desfecho é a `nota_media`
  da pesquisa pós-voo (0 a 10).
- `dados/dicionario_voos.md`: o que é cada coluna. Anexe sempre junto com a
  base.
- A habilidade `raio-x-planilha`, que está no pacote em
  `skills/raio-x-planilha/` (Personalizar → Habilidades → Adicionar → Carregar
  do seu computador).
- A habilidade `insper relatorio word`, já instalada pelo Insper.

A TAP só voa entre o Brasil e Portugal: preço, distância e número de
passageiros estão noutra escala. Quem é da TAP compara a TAP com ela mesma
(mês a mês, voo a voo), e não com as companhias domésticas.

## Rodada 1: o pedido de sempre

Conversa nova no Work. Anexe a base e o dicionário e peça com as suas palavras,
ou cole este pedido trocando o nome da companhia:

> Somos da área de experiência do cliente da [companhia]. Anexei uma base com
> os voos de 2026 de quatro companhias e o dicionário das colunas. Faça um
> relatório descritivo de duas páginas para a diretoria sobre como foram os
> nossos voos e o que os passageiros acharam.

Deixe rodando. Não confira ainda.

## Rodada 2: conferir e corrigir

1. **Confira cada gráfico da rodada 1 com o checklist**: título com a
   conclusão; tipo da variável combinando com o gráfico; barras começando no
   zero; n visível; cor só para destacar; fonte, período e base. Anote o que
   estava errado.
2. **Transforme a hipótese da manhã numa pergunta sobre colunas.** Diga que
   colunas medem o que a hipótese afirma e o tipo de cada uma. Exemplos (use a
   do seu grupo):

   | companhia | a hipótese, em texto | as colunas |
   |---|---|---|
   | LATAM | o app falha no check-in, e o passageiro sai irritado | `falha_checkin_app_pct` e `nota_media` |
   | Gol | atrasa muito, e quase não dá assistência | faixa de atraso, `assistencia_oferecida` e `nota_media` |
   | Azul | cancela por manutenção, e reacomodar irrita | `reacomodado`, `motivo_atraso` e `nota_media` |
   | TAP | o aplicativo não funciona | `falha_checkin_app_pct` e `nota_media` |

   Se nenhuma coluna mede o que a hipótese diz, isso também é resultado:
   anote.
3. **Escreva mais duas perguntas** de negócio. Exemplos: em que meses a nota
   cai? Que motivo de atraso mais derruba a nota? Quantos voos chegam com mais
   de uma hora de atraso?
4. **Escolha o gráfico de cada pergunta** pelo par de tipos:

   | as duas variáveis | o gráfico |
   |---|---|
   | numérica × categórica | boxplot, um por grupo |
   | categórica × categórica | barras de proporção, ou barras 100% |
   | numérica × numérica | pontos |
   | tempo × qualquer uma | linha |

5. **Peça cada gráfico com um pedido completo.** Modelos para colar (troque a
   companhia e as colunas):

   > Só os voos da [companhia]. Pergunta: a nota média muda conforme a faixa
   > de atraso? Corte `atraso_chegada_min` em quatro faixas (até 15 min, 15 min
   > a 1 h, 1 a 3 h, mais de 3 h): é categórica ordinal. `nota_media` é
   > numérica contínua. Faça um boxplot por faixa, na ordem natural, com o n de
   > cada faixa. Título com a conclusão. Antes, confira a base com a habilidade
   > raio-x-planilha e me mostre o código do gráfico.

   > Só os voos da [companhia]. Pergunta: quando `falha_checkin_app_pct` sobe,
   > o que acontece com `nota_media`? As duas são numéricas contínuas. Faça um
   > gráfico de pontos, um ponto por voo, com a correlação no título e o n no
   > rodapé. Não force uma reta se não houver relação. Mostre o código.

   > Só os voos da [companhia]. Pergunta: como a nota média mudou mês a mês em
   > 2026? Faça uma linha, um ponto por mês, com o número de voos de cada mês.
   > Diga no eixo onde ele começa. Título com a conclusão. Mostre o código.

6. **Escolha o formato.** Word (`.docx`, com a habilidade `insper relatorio
   word`) quando a diretoria vai editar ou comentar; HTML (uma página no
   navegador, com gráficos interativos) quando ela vai explorar. No Work, os
   **sites do ChatGPT** (@Sites) transformam o relatório numa página com link:
   só com números agregados, e conferindo os números da página com os do
   relatório.
7. **Peça o relatório no formato de entrega** abaixo.

## Entrega: o formato do relatório

Um arquivo por dupla, `relatorio_descritivo_<companhia>.docx` ou `.html`, com
**duas páginas**, nesta ordem:

1. **Título que diz a conclusão** e um resumo de três frases.
2. **Três perguntas**, a primeira sendo a hipótese da manhã. Cada uma com o
   gráfico (escolhido pelo tipo das variáveis), uma frase de conclusão, o n e
   a fonte: "voos_2026.csv (simulada), jan. a out. de 2026, 2.000 voos da
   [companhia]".
3. **O gráfico que vocês corrigiram**: a versão da rodada 1 e a corrigida, com
   o que estava errado.
4. **A hipótese da manhã** em uma frase: ela parece se sustentar na base?

O relatório fica na pasta do grupo: amanhã, ele vira o painel do exercício 8.
