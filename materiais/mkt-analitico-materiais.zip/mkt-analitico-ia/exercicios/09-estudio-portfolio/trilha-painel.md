# Trilha E. Um painel numa página, publicado

**Onde:** aplicativo de desktop do ChatGPT, modo Work.

Uma página que responde a **uma** pergunta, num endereço que alguém abre no
celular entre duas reuniões. Pode partir do relatório descritivo de quarta
(exercício 4) ou de uma base da sua área, só com agregados.

## Material

- a sua base (ou `dados/voos_2026.csv` e o dicionário, se for partir de
  quarta);
- o seu relatório descritivo, se quiser reaproveitar a pergunta e os gráficos;
- o painel de exemplo, no site do curso (Ctrl+U mostra o código; pode partir
  dele).

## As cinco peças de um painel

1. **Título e manchete**: o título diz o assunto; a manchete dá a resposta em
   uma frase, com o número.
2. **Filtro**: um clique troca o recorte. Pouca opção: a pergunta é uma só.
3. **Números-chave**: de 3 a 5, cada um com uma frase que diz o que ele é.
4. **Gráfico**: um por pergunta, com o destaque na cor da marca.
5. **Rodapé**: fonte, período e o aviso de que só há agregados.

## O pedido

> Quero um painel em uma página (um único arquivo HTML) sobre [minha base],
> para [quem vai ler], que responda: [a pergunta principal].
>
> 1. Calcule só agregados (nenhuma linha individual, nenhum dado pessoal) e me
>    mostre os números antes de seguir.
> 2. Faça a página com uma manchete que dá a resposta em uma frase, de 3 a 5
>    números-chave, 2 ou 3 gráficos (ordenados, rótulos diretos, uma cor de
>    destaque) e um filtro por [mês, região, canal].
> 3. Transições suaves no filtro: as mesmas barras mudam de tamanho e de lugar.
>    Respeite quem configurou o sistema para reduzir movimento.
> 4. Rodapé com fonte e data dos dados.
> 5. Depois, publique no Sites e me dê o link (ou me entregue o arquivo HTML).

## Como publicar

- **Sites, no ChatGPT Work**: o Work publica a página e devolve um link. Na
  conta Edu, depende do administrador.
- **Enviar o arquivo**: um HTML único abre no navegador de quem recebe, por
  e-mail ou pela pasta compartilhada da empresa.

Em qualquer caso, o que está na página é visível para quem tem o link ou o
arquivo: **só agregados**, nunca linhas com dados de clientes.

## Sete conferências antes de mandar o link

1. A manchete responde à pergunta em uma frase.
2. Os números batem com a base: uma média conferida à mão.
3. Cada gráfico: ordem, sem ruído, destaque, título que conclui.
4. Fonte e data no rodapé (se a base for simulada, diga isso).
5. Só agregados nos números da página.
6. No celular: abre, cabe e dá para ler.
7. Movimento só onde algo muda.
