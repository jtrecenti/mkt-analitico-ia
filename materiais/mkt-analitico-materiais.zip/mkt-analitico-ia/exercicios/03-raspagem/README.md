# Exercício 3. Raspar o que os clientes da sua companhia escrevem

**Onde:** aplicativo de desktop, modo Work. Se não conseguir instalar o
aplicativo, use o Work no navegador. **Em grupo, uma companhia por grupo**
(dentro do grupo, em duplas). **Tempo:** 30 minutos.

## A situação

Cada grupo é a equipe de experiência do cliente de uma companhia: **LATAM,
Gol, Azul ou TAP**. A diretoria quer saber o que mais irrita os passageiros.
Até as 13h, o grupo precisa sair com **uma hipótese**: "na nossa companhia, a
nota cai quando \_\_\_\_". À tarde, ela vai ser testada numa base de 8.000 voos.

Ninguém entrega os textos prontos. Neste exercício, vocês os baixam.

## Parte A: as avaliações do aplicativo na App Store (todos os grupos)

Toda avaliação de aplicativo na App Store é pública. A página mostra a nota e
algumas avaliações; a Apple também oferece um **feed** (um endereço feito para
programas) com as 500 mais recentes, em JSON.

| companhia | página na App Store | número do aplicativo |
|---|---|---|
| LATAM | <https://apps.apple.com/br/app/id1497908631> | 1497908631 |
| Gol | <https://apps.apple.com/br/app/id337961662> | 337961662 |
| Azul | <https://apps.apple.com/br/app/id690105616> | 690105616 |
| TAP | <https://apps.apple.com/br/app/id440497198> | 440497198 |

1. **Navegar** (5 min). Abram a página do aplicativo da sua companhia. Qual a
   nota? Quantas avaliações? O que dá para ver ali, e o que não dá?
2. **Pedir o raspador** (15 min). No Work, numa pasta de trabalho, peçam
   (troquem o número pelo da sua companhia):

   > Quero baixar as avaliações mais recentes do aplicativo de número
   > 440497198 na App Store do Brasil. A Apple tem um feed público em JSON:
   > https://itunes.apple.com/br/rss/customerreviews/page=1/id=440497198/sortby=mostrecent/json
   > (troque page=1 por 2, 3... até 10). Siga o ciclo do web scraping: salve
   > cada página em disco numa pasta brutos_app/ antes de ler qualquer coisa,
   > uma página por vez, com 1 segundo de pausa. Depois leia os arquivos e
   > monte uma tabela com id, data, nota, versão do aplicativo, título e texto
   > de cada avaliação. Não guarde o nome nem o apelido de quem avaliou. Comece
   > com 2 páginas e me mostre o resultado antes de baixar o resto.

3. **Validar** (10 min). Respondam com números:
   - Quantas avaliações vieram? Alguma repetida? Alguma sem texto?
   - De que data a que data? (Cada companhia tem um período diferente. Por
     quê?)
   - A nota média das 500 bate com a nota que a página mostra? Se não bate,
     por quê?
   - Abram três avaliações no arquivo bruto e comparem com a tabela.

### Entrega da parte A

O CSV (`avaliacoes_<companhia>.csv`) e **duas coisas que vocês validaram**: o
que conferiram e o que encontraram.

## Parte B, se der tempo: sentenças do TJSP contra a sua companhia

A App Store mostra o que o cliente acha **do aplicativo**. Para saber o que
acontece **no voo**, outra fonte pública: a Consulta de Julgados de 1º Grau do
Tribunal de Justiça de São Paulo (<https://esaj.tjsp.jus.br/cjpg/>), sem login
e sem captcha. Se não der tempo, o professor demonstra.

| grupo | pesquisa livre | período | sentenças em 3/11/2026 |
|---|---|---|---|
| LATAM | `voo E (atraso OU cancelamento OU bagagem) E LATAM` | 01/08/2026 a 31/10/2026 | 152 |
| Gol | `voo E (atraso OU cancelamento OU bagagem) E GOL` | 01/08/2026 a 31/10/2026 | 134 |
| Azul | `voo E (atraso OU cancelamento OU bagagem) E AZUL` | 01/08/2026 a 31/10/2026 | 212 |
| TAP | `voo E (atraso OU cancelamento OU bagagem) E TAP` | 01/05/2026 a 31/10/2026 | 50 |

A TAP tem menos processos por mês, por isso o período é maior.

1. Façam a busca à mão: quantas sentenças, quantas por página, onde está o
   texto inteiro (o ícone **+** ao fim de cada resumo).
2. Peçam no Work:

   > Quero raspar sentenças da Consulta de Julgados de 1º Grau do TJSP
   > (https://esaj.tjsp.jus.br/cjpg/) com a pesquisa livre
   > "voo E (atraso OU cancelamento OU bagagem) E TAP", de 01/05/2026 a
   > 31/10/2026. Siga o ciclo do web scraping. Primeiro descubra que
   > requisição o botão Consultar faz e reproduza essa requisição em Python,
   > com todos os campos. Salve cada página de resultado em HTML numa pasta
   > brutos/ antes de ler qualquer coisa. Depois leia os arquivos e monte uma
   > tabela com processo, classe, assunto, comarca, data e o texto inteiro da
   > sentença. No fim, confira se o número de sentenças lidas bate com o total
   > que o site anuncia. Uma página por vez, com 2 segundos de pausa. Comece
   > com 3 páginas e me mostre o resultado antes de baixar o resto.

3. Validem: o total bateu? Quantas sentenças são mesmo contra a sua companhia?
   (A palavra solta "GOL" ou "TAP" aparece em outros contextos.)

## O que aconteceu na preparação

**App Store**

- O feed entregou 500 avaliações para Gol, Azul e TAP, e 470 para a LATAM.
- As 500 mais recentes cobrem **períodos muito diferentes**: na Gol, de maio a
  outubro de 2026; na Azul, de julho a outubro; na LATAM, desde outubro de
  2025; na TAP, desde **2021**, porque o aplicativo recebe poucas avaliações
  no Brasil. Não é uma amostra aleatória: são as últimas.
- A nota média das 500 é bem menor que a nota da página (TAP: 1,8 nas 500,
  3,3 na página). A página soma todas as notas, inclusive as que vieram sem
  texto; quem escreve, em geral, escreve para reclamar.
- O feed traz o apelido de quem avaliou, e às vezes um e-mail. A tabela não
  deve guardar isso.

**TJSP**

- **Todos os campos do formulário, mesmo os vazios.** Mandando só a busca e as
  datas, o site respondeu normalmente (código 200), mas **sem nenhum
  resultado**.
- **O total vem com tags no meio** ("Resultados `<strong>`1 a 10`</strong>` de
  152"). O primeiro leitor não achou o número e achou que a busca estava vazia.
- **Os parênteses mudam tudo.** `voo E atraso E (LATAM OU GOL OU AZUL)` trouxe
  398 sentenças; sem os parênteses, 134: só as da LATAM.
- **O texto inteiro já vem na lista**, num bloco escondido da página
  (`display: none`).
- **A busca traz ruído.** Na busca da TAP em 12 meses, 32 das 151 sentenças
  eram contra outras empresas (Ibéria, Air Europa, Azul, agências) que só
  citavam a TAP.

## Cuidados

- As sentenças são públicas, mas trazem **nomes de partes, advogados e
  juízes**. Usem para análise e não publiquem a base com nomes.
- O servidor é de todos: uma página por vez, com pausa, e só o período de que
  precisam.

## Gabarito

As habilidades do professor:

```bash
python skills/avaliacoes-app/scripts/baixar_avaliacoes.py TAP --saida avaliacoes_tap.csv
python skills/raspar-tjsp/scripts/raspar_tjsp.py baixar --busca "voo E (atraso OU cancelamento OU bagagem) E TAP" --inicio 01/05/2026 --fim 31/10/2026 --pasta brutos
python skills/raspar-tjsp/scripts/raspar_tjsp.py ler --pasta brutos --saida sentencas_tap.csv
```

## Para ir além

Transformem o raspador numa habilidade que recebe o número de qualquer
aplicativo, e rodem para a sua empresa ou um concorrente.
