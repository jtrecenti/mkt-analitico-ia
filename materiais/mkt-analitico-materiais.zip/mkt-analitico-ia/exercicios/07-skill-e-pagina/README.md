# Exercício 7. A receita vira skill, e a página vai para a internet

**Onde:** aplicativo de desktop do ChatGPT, modo Work, e o navegador. **Em
duplas.**

O monitor funciona na pasta de vocês. Duas coisas faltam para ele servir ao
time: rodar na mão de outra pessoa (a skill) e ter um endereço que qualquer um
abre no celular (a página publicada).

## Material

A pasta do exercício 6. Para comparar: `skills/monitor-avaliacoes-app/`.

## Parte 1: a skill

1. Na pasta do projeto, peçam:

   > Transforme este projeto numa skill chamada `monitor-avaliacoes-app`: um
   > `SKILL.md` com uma descrição que diga quando usar, os passos na ordem, as
   > regras do `AGENTS.md` e o que fazer quando uma checagem bloquear (perguntar
   > ao usuário, nunca resolver sozinho); e uma pasta `scripts/` com o código,
   > que receba a pasta dos dados como parâmetro. Teste a skill numa pasta nova
   > antes de me entregar.

2. Instalem a skill no ChatGPT, como na terça.
3. **A prova:** numa conversa nova, sem a pasta do projeto, anexem as duas
   coletas e peçam "atualize o monitor de avaliações". Deu 2.010 avaliações e
   10 novas? Se não, o que ficou de fora da skill?

## Parte 2: a página no ar

1. Criem uma conta grátis no Netlify (dá para entrar com o Google). Sem conta,
   o site fica atrás de uma senha temporária e é apagado em uma hora.
2. Abram **app.netlify.com/drop** e arrastem a pasta `saida/` (a que tem o
   `index.html`) para a área indicada.
3. Em segundos sai um endereço. Abram no celular.
4. Amanhã, para atualizar: rodem o monitor de novo e arrastem a pasta nova no
   mesmo site (aba de deploys do site).

A outra opção é publicar pelo próprio ChatGPT, como na quarta: chamem
**@Sites** e peçam para publicar o `index.html`. Em contas de empresa, a
publicação pública pode estar desligada pelo administrador.

## Antes de mandar o link

- A página tem só números agregados e títulos? Nenhum texto inteiro, nenhum
  apelido, nenhum telefone?
- O rodapé diz a fonte e a data da coleta?
- Abre e cabe no celular?
