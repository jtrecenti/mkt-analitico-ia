# Exercício 7. Outubro chegou

**Onde:** aplicativo de desktop do ChatGPT, modo Work, na pasta do exercício 6.
**Em duplas.**

Os arquivos de outubro chegaram da agência e do e-commerce. Rodar o relatório
deveria levar um minuto. Mas os arquivos do mundo real nunca chegam iguais aos
do mês anterior.

## Material

`dados/bora/midia_2026-10.csv` e `dados/bora/vendas_2026-10.csv`, além da pasta
do exercício 6.

## Passos

1. Copiem os dois arquivos para `dados/brutos/`, sem abrir nem mexer.
2. Peçam: "Rode o relatório de 2026-10". Anotem o que aconteceu: o relatório
   saiu? Alguma checagem falhou?
3. Para cada problema que aparecer, decidam **com a dupla** (e não deixem o
   agente decidir sozinho):
   - é uma regra que vale todo mês (vira linha no `AGENTS.md` e no passo de
     padronizar)?
   - ou é um caso que precisa de confirmação de alguém (a agência, o
     e-commerce) antes de entrar?
4. Escrevam em português **uma checagem nova** para um problema que as
   checagens de vocês não pegaram, no formato "toda X precisa Y" ou "nenhum X
   pode Y". Peçam ao agente para incluí-la e, antes de confiar nela, **quebrem
   o dado de propósito** numa cópia do arquivo para ver a checagem falhar.
5. Rodem de novo até o relatório sair.

## Para conferir

Outubro tem seis problemas plantados. Quantos as checagens de vocês pegaram?
Somando o arquivo como chegou, o investimento de outubro parece ser
R$ 115.632 e o ROAS 2,43, uma queda de 45% sobre setembro. Com os problemas
tratados, o investimento é **R$ 66.809** e o ROAS **4,17**.

A lista dos seis problemas está no slide "O que as checagens pegaram em
outubro". Olhem só depois de tentar.
