# Exercício 7. Relatório analítico com regressão

**Onde:** aplicativo de desktop, modo Work (plano B: Work no navegador).
**Em duplas**, dentro do grupo da manhã. **Tempo:** 60 minutos, em duas
rodadas.

O relatório descritivo mostrou **o que** acontece com os voos da sua
companhia. Este pergunta **o que pesa** na nota, separando um fator do outro,
e testa a hipótese que o grupo tirou dos textos de manhã.

## Material

- `dados/voos_2026.csv` e `dados/dicionario_voos.md`, os mesmos das 14h.
- A hipótese da manhã (a frase que o grupo mandou no quiz às 15h05).
- Na rodada 2, um arquivo que o professor libera na hora.

## Rodada 1 (16h, 10 minutos): o pedido que um gestor faria

Abra uma **conversa nova**, anexe a base e o dicionário e cole este pedido,
trocando só o nome da companhia:

> Sou da diretoria de experiência do cliente da [companhia]. Anexei uma base
> com os voos de 2026 de quatro companhias aéreas e o dicionário das colunas;
> `nota_media` é a nota da pesquisa que o passageiro responde depois do voo.
> Quero saber o que mais pesa na nota dos nossos voos. Rode uma regressão, me
> diga quais fatores mais explicam a nota e me dê uma recomendação prática para
> a equipe.

Deixe rodando. Quando terminar, anote no quiz: o R² que ele destacou, o fator
número 1 e a recomendação.

## Rodada 2 (16h45, 30 minutos): a auditoria

Para cada coluna que entrou no modelo, a pergunta é uma só: **ela já existia
quando o passageiro deu a nota?**

1. **Classifique vocês mesmos** cada coluna do modelo: ela passa a existir
   antes do voo, durante o voo, junto com a pesquisa ou depois dela? Usem a
   descrição do dicionário e as datas da base.

   O ChatGPT pode ajudar:

   > Antes de levar isso à diretoria, quero auditar o modelo. Para cada coluna
   > que você usou, diga em que momento ela passa a existir em relação à nota
   > (antes do voo, durante o voo, junto com a pesquisa ou depois dela) e como
   > você sabe disso. Não mude o modelo ainda.

2. **Compare com o arquivo que o professor liberar** e anote onde vocês (ou o
   ChatGPT) erraram.
3. **Peça o modelo de novo** só com o que sobreviveu:

   > Refaça a regressão só com as colunas que existem antes do voo ou durante
   > ele, só com os voos da [companhia]. Para cada fator, me dê o efeito em
   > linguagem de gestão ("cada hora a mais de atraso está associada a uma nota
   > X menor, entre voos parecidos"), com o intervalo de confiança. Diga quais
   > colunas andam juntas (correlação alta) e o que isso muda na leitura. Mostre
   > o R² e o código.

4. **Compare com a hipótese da manhã.** O fator da hipótese é o que mais pesa,
   pesa mas não é o principal, ou quase não pesa? Anote no quiz.
5. **Se der tempo, teste no tempo:**

   > Treine o mesmo modelo com os voos de janeiro a agosto e teste com setembro
   > e outubro. Qual o R² nos meses de teste?

## O relatório (16h45 a 17h45, junto com a rodada 2)

Uma página para a diretoria, com:

- a pergunta e o modelo que você defende, e por que o da rodada 1 não serve;
- os três fatores mais importantes, em linguagem de gestão;
- o que o modelo **não** permite concluir (quanto da nota ele não explica;
  associação não é causa; a base é simulada);
- uma recomendação que caiba num piloto.

## Entrega

O relatório e duas frases: **o que mudou entre a rodada 1 e a rodada 2**, e o
que aconteceu com a hipótese da manhã.
