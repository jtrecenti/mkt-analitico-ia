# Exercício 7. Relatório analítico com regressão

**Onde:** aplicativo de desktop, modo Work (plano B: Work no navegador).
**Em duplas.** **Tempo:** 80 minutos, em duas rodadas.

O relatório descritivo mostrou **o que** acontece. Este pergunta **o que pesa**
na nota, separando um fator do outro: a LATAM responde mais rápido e tem nota
menor; responder rápido faz mal, ou é outra coisa?

## Material

`dados/relatos_estruturados.csv` e `dados/dicionario.md`. Na segunda rodada,
também `exercicios/05-extracao/extrair.py` e `dicionario_relatos.json`.

## Rodada 1: o pedido que um gestor faria (25 min)

Anexe a base e o dicionário e peça, com estas palavras:

> Sou da diretoria de atendimento de uma companhia aérea. Esta base tem 3.442
> reclamações do consumidor.gov.br contra Azul, LATAM e Gol, e o dicionário
> explica as colunas. Quero saber o que mais pesa na nota que o consumidor dá
> ao atendimento. Rode uma regressão, me diga quais fatores mais explicam a
> nota e me dê uma recomendação prática para a equipe.

Anote no quiz: o R² que ele relatou, o fator número 1 e a recomendação.

## Rodada 2: a auditoria (35 min)

Para cada variável que entrou no modelo, responda: **ela já existia antes de o
consumidor dar a nota?** Confira com as datas da base, com o dicionário e com o
processo que gerou cada coluna. Se precisar, anexe o script de extração e
pergunte:

> Antes de levar isso à diretoria, quero auditar o processo. Alguma variável
> explicativa do seu modelo pode carregar informação do desfecho (a nota), por
> causa de como foi construída?

Depois, peça o modelo de novo só com o que sobreviveu à auditoria.

## O relatório (20 min)

Uma página para a diretoria, com: a pergunta; o modelo que você defende e por
quê; os três fatores mais importantes, em linguagem de gestão ("cada dia a mais
para responder está associado a uma nota X menor"); o que o modelo **não**
permite concluir; uma recomendação que caiba num piloto.

## Entrega

O relatório, e uma frase: **o que mudou entre a rodada 1 e a rodada 2**.
