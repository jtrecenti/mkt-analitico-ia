# Exercício 2. Um plugin que confere agências de viagem com a BrasilAPI

**Onde:** criar no ChatGPT (Personalizar → Plugins) e rodar no aplicativo de
desktop, modo Work, com acesso à pasta do exercício. **Em duplas.**
**Tempo:** 35 minutos.

## A situação

A Aérea Sol (a mesma companhia do grupo focal do exercício 1) vai lançar em
2027 um **programa de incentivo para agências de viagem**: metas, comissão
extra e campanhas antes dos feriados. O time comercial exportou do CRM as 20
agências que mais venderam em 2026. Antes de assinar contratos, a diretoria
quer saber:

1. **Quem pode entrar?** A empresa está ativa? É mesmo uma agência de viagens?
   O cadastro do CRM bate com a Receita?
2. **Quem é quem?** Algumas "agências" são do mesmo grupo. A meta e a comissão
   deveriam ser por grupo.
3. **Quando fazer as campanhas?** Quais feriados de 2027 emendam com o fim de
   semana.

Tudo isso está em bases públicas, e a [BrasilAPI](https://brasilapi.com.br)
junta essas bases num endereço só, gratuito e sem chave:

| pergunta | base pública | endereço na BrasilAPI |
|---|---|---|
| A empresa está ativa? Que atividade, porte, cidade, telefone? | CNPJ (Receita Federal) | `/api/cnpj/v1/{cnpj}` |
| Em que cidade fica o CEP do cadastro? | CEP (Correios) | `/api/cep/v2/{cep}` |
| De que estado é o DDD do telefone do cadastro? | DDD (Anatel) | `/api/ddd/v1/{ddd}` |
| Quais são os feriados nacionais de 2027? | feriados | `/api/feriados/v1/2027` |

Um **plugin** empacota uma habilidade com o script que faz as consultas, para
você instalar e usar de novo no próximo cadastro.

## Material

`exercicios/02-brasilapi/agencias_parceiras.csv`: 20 linhas, como saem de um
CRM. Agências reais (dados públicos da Receita); **as vendas são fictícias**.

- CNPJ com e sem pontuação, e dois que o Excel "comeu" (os que começam com 0).
- CEP de Santo André sem o zero da frente.
- Uma linha repetida, um CNPJ com dígito errado.
- Cadastros desatualizados e alguns CNPJs que não são o que o nome diz.

## Passos

1. **Personalizar → Plugins → Adicionar → Criar plugin.** O Plugin Creator
   abre uma conversa. Um ponto de partida:

   > Me ajude a criar um plugin chamado brasilapi, com uma habilidade e um
   > script Python, sem servidor MCP. Ele consulta a BrasilAPI (gratuita e sem
   > chave): CNPJ, CEP, DDD e feriados. O script recebe uma planilha de
   > agências com as colunas cnpj, cep_cadastro e telefone_cadastro. Ele limpa
   > a pontuação, completa os zeros que o Excel come, valida o dígito do CNPJ e
   > marca o que der errado em vez de travar. Para cada agência, traz da
   > Receita a situação, a atividade principal, o porte, a cidade e o telefone,
   > e avisa quando: a empresa não está ativa, a atividade não é agência de
   > viagens, o CEP ou o DDD do cadastro são de outro lugar, ou a linha está
   > repetida. Junta num grupo as agências com o mesmo telefone ou o mesmo
   > endereço na Receita. Também lista os feriados nacionais de 2027 que
   > emendam com o fim de semana. Uma consulta por vez, com pausa, sem repetir
   > consulta. Não guarde o quadro de sócios do CNPJ.

2. **Instale o plugin.** Criar não é instalar. Na preparação, o ChatGPT parou
   e mostrou um cartão "O ChatGPT precisa usar um plugin", com o botão
   **Instalar**. Dá para instalar antes, em Personalizar → Plugins → Pessoal.
3. No **aplicativo de desktop**, modo Work, abra a pasta do exercício e peça:

   > Use o plugin brasilapi na planilha agencias_parceiras.csv. Quais agências
   > podem entrar no programa de incentivo de 2027, quais ficam de fora e por
   > quê? Quais são do mesmo grupo? Em que meses vale fazer campanha, pelos
   > feriados que emendam?

## Entrega

Para a diretoria: **as agências que entram**, **as que ficam de fora (e por
quê)**, **os grupos** e **três janelas de campanha** em 2027.

## O que aconteceu na preparação

- **Antes de escolher a API, testamos todos os endereços** (três chamadas
  cada, em 3/11/2026). CNPJ, CEP, DDD e feriados responderam sempre. A tabela
  FIPE respondia "fonte de dados FIPE temporariamente indisponível" (erro 500),
  e o clima nos aeroportos voltava com todos os campos "undefined". O
  exercício usa só o que estava de pé.
- **O Excel come zeros, e não só o Excel.** Ao passar a lista de CNPJs pelo
  terminal do Windows, os que começavam com 0 perderam o zero e viraram
  "inválidos". O plugin precisa completar os zeros antes de validar.
- **Do computador do Work na nuvem**, a BrasilAPI respondeu uma vez em quatro
  tentativas (403, 200 e dois tempos esgotados). Do aplicativo de desktop, com
  a internet daqui, respondeu sempre. Por isso o exercício roda no desktop.
- Se der 403, não peça ao ChatGPT para se disfarçar de navegador: isso é
  contornar uma proteção que o dono do site colocou.

## O que o gabarito encontrou

- **8 das 20 linhas têm problema**: uma empresa baixada (ViajaNet, desde
  janeiro de 2023), uma em recuperação judicial cuja atividade não é agência
  (123milhas), duas que na Receita são empresas de ônibus ou a própria
  companhia aérea (Belatur, "Aérea Turismo" com o CNPJ da LATAM), um telefone
  com DDD de São Paulo para uma agência de Porto Alegre, um CEP de Belo
  Horizonte para uma agência de Sete Lagoas, uma linha repetida e um CNPJ
  inválido.
- **Os grupos mudam o ranking.** Por agência, a maior é a CVC (R$ 4,3 mi). Por
  grupo: CVC + Rextur (R$ 6,1 mi) e quatro CNPJs da Flytour (R$ 5,8 mi),
  à frente da Decolar (R$ 4,0 mi). A ViajaNet, baixada, tem o endereço da
  Flytour. "Flytour American Express" tem Flytour no nome, mas na Receita é
  outra empresa, com outro endereço e outro telefone.
- **A linha repetida dobraria a Decolar** para R$ 8,0 mi, e ela viraria a
  maior.
- **Feriados de 2027 que emendam**: Carnaval (8 e 9 de fevereiro), Sexta-feira
  Santa (26 de março), Corpus Christi (quinta, 27 de maio), 7 de setembro,
  12 de outubro e 2 de novembro (terças) e 15 de novembro (segunda).

## Gabarito

`gabarito/agencias_enriquecidas.csv`, `gabarito/feriados_2027.csv` e o script
em `gabarito/skills/brasilapi/scripts/brasilapi.py`:

```bash
python gabarito/skills/brasilapi/scripts/brasilapi.py agencias agencias_parceiras.csv --saida agencias_enriquecidas.csv
```

## Para ir além

- A BrasilAPI também traz a previsão do tempo por cidade (CPTEC): peça a
  previsão dos próximos dias para as cidades das agências de Minas Gerais.
- O CNPJ passou a aceitar letras em julho de 2026. O seu script trata isso?
