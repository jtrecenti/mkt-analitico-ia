# Exercício 5. Relatório analítico com regressão

**Onde:** aplicativo de desktop, modo Work (plano B: Work no navegador).
**Em duplas**, dentro do grupo da companhia. Duas rodadas; a segunda é a
entrega do estúdio 3.

O relatório descritivo mostrou **o que** acontece com os voos da sua
companhia. Este pergunta **o que pesa** na nota, separando um fator do outro,
e testa a hipótese que o grupo tirou dos textos de manhã.

## Material

- `dados/voos_2026.csv` e `dados/dicionario_voos.md`, os mesmos do relatório
  descritivo.
- A hipótese da manhã, do cartão do exercício 3.

## Rodada 1: o pedido que um gestor faria

1. Abram uma **conversa nova** no Work (não a do relatório descritivo) e
   anexem a base e o dicionário.
2. Colem este pedido, trocando só o nome da companhia:

   > Sou da diretoria de experiência do cliente da [companhia]. Anexei uma base
   > com os voos de 2026 de quatro companhias aéreas e o dicionário das colunas;
   > `nota_media` é a nota da pesquisa que o passageiro responde depois do voo.
   > Quero saber o que mais pesa na nota dos nossos voos. Rode uma regressão, me
   > diga quais fatores mais explicam a nota e me dê uma recomendação prática para
   > a equipe.

3. Leiam a resposta com o que vimos na aula: o que cada coeficiente diz, o que
   ficou de fora do modelo e quais colunas andam juntas.
4. Quando terminar, anotem três coisas: **o R²** que ele destacou, **o fator
   número 1** e **a recomendação**. Guardem a conversa: a rodada 2 continua
   nela.

## Rodada 2

O roteiro da rodada 2 é apresentado na aula, depois da rodada 1. É ela que vira
o relatório entregue no Blackboard.
