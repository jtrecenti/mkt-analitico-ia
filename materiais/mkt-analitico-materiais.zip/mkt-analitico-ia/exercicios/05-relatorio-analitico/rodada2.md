# Exercício 5, rodada 2: a auditoria e o relatório analítico (estúdio 3)

**Onde:** a mesma conversa da rodada 1, no aplicativo de desktop, modo Work.
**Em duplas**, dentro do grupo da companhia. **É a entrega do estúdio 3.**

Para cada coluna que entrou no modelo, a pergunta é uma só: **ela já existia
quando o passageiro deu a nota?**

## Passos

1. **Classifiquem vocês mesmos** cada coluna do modelo: ela passa a existir
   antes do voo, durante o voo, junto com a pesquisa ou depois dela? Usem a
   descrição do dicionário e as datas da base.

   O ChatGPT pode ajudar:

   > Antes de levar isso à diretoria, quero auditar o modelo. Para cada coluna
   > que você usou, diga em que momento ela passa a existir em relação à nota
   > (antes do voo, durante o voo, junto com a pesquisa ou depois dela) e como
   > você sabe disso. Não mude o modelo ainda.

2. **Comparem com `dados/dicionario_voos_momentos.md`**, que o professor libera
   depois do passo 1, e anotem onde vocês (ou o ChatGPT) erraram.
3. **Peçam o modelo de novo** só com o que sobreviveu:

   > Refaça a regressão só com as colunas que existem antes do voo ou durante
   > ele, só com os voos da [companhia]. Para cada fator, me dê o efeito em
   > linguagem de gestão ("cada hora a mais de atraso está associada a uma nota
   > X menor, entre voos parecidos"), com o intervalo de confiança. Diga quais
   > colunas andam juntas (correlação alta) e o que isso muda na leitura. Mostre
   > o R² e o código.

4. **Comparem com a hipótese da manhã.** O fator da hipótese é o que mais pesa,
   pesa mas não é o principal, ou quase não pesa?
5. **Se der tempo, testem no tempo:**

   > Treine o mesmo modelo com os voos de janeiro a agosto e teste com setembro
   > e outubro. Qual o R² nos meses de teste?

## Entrega: o relatório analítico

Um arquivo por dupla, `relatorio_analitico_<companhia>.docx` (Word, com a
habilidade `insper relatorio word`) ou `.html`, enviado no Blackboard, na
tarefa do estúdio 3. **Uma página** para a diretoria, nesta ordem:

1. **A pergunta e o modelo**: o que pesa na nota da sua companhia, o modelo
   que vocês defendem, e por que o da rodada 1 não serve (que colunas saíram,
   e por quê).
2. **Três fatores, em linguagem de gestão**: "entre voos parecidos, cada 10
   p.p. de conexões perdidas estão associados a uma nota 0,41 menor".
3. **O que mudou entre as rodadas**: o R² e o fator número 1 da rodada 1 e da
   rodada 2.
4. **A hipótese da manhã**: confirmou, confirmou em parte ou foi refutada, e
   por quê.
5. **Limites e recomendação**: quanto da nota o modelo não explica;
   associação não é causa; a base é simulada. Uma recomendação que caiba num
   piloto.
