# Exercício 1. Uma habilidade que conta com Python

**Onde:** aplicativo de desktop, modo Work. Se não conseguir instalar o
aplicativo, use o Work no navegador. **Em duplas.** **Tempo:** 20 minutos.

## A situação

Uma agência fez um grupo focal com oito viajantes frequentes para a Aérea Sol,
uma companhia aérea. A transcrição tem quase duas horas de conversa e 18 mil
palavras. A diretoria de marketing quer saber, antes de ler tudo: **de que eles
mais falam, e quem fala de quê?** Para começar, quantas vezes cada pessoa falou
de **preço**.

Parece uma pergunta fácil para o ChatGPT. O problema aparece quando a mesma
pergunta é feita duas vezes.

## Material

`exercicios/01-habilidade-python/grupo_focal_aerea_sol.txt`: a transcrição, uma
fala por linha (`NOME: texto`). Tudo é fictício: a companhia, as pessoas e a
conversa foram criadas para o curso.

## Passos

1. **Sem habilidade.** Numa conversa nova, anexe a transcrição e pergunte:

   > Neste grupo focal, quantas vezes cada participante falou de preço? Não
   > conte a moderadora. Quero um número por pessoa e o total.

   Anote o total. Abra **outra** conversa nova, anexe de novo, pergunte igual e
   anote. (Uma pessoa da dupla em cada computador, ao mesmo tempo.)

2. **Crie a habilidade.** Personalizar → Habilidades → Adicionar → **Criar com
   chat**. Depois do texto que já vem pronto, descreva o que quer:

   > Já sei o que quero: uma habilidade chamada contar-termos. Quando eu mandar
   > uma transcrição de entrevista ou grupo focal (uma fala por linha, no formato
   > NOME: texto), ela roda um script Python que conta quantas vezes cada tema
   > aparece, por pessoa. Regras fixas: conta palavra inteira, sem diferenciar
   > acento e maiúscula, e deixa a moderadora de fora. Cada tema é uma lista de
   > termos (por exemplo, preço = preço, preços, caro, cara, barato, barata,
   > tarifa); um termo terminado em * pega o começo da palavra (atras* pega
   > atraso, atrasou, atrasado). O script também salva um CSV com cada
   > ocorrência e o trecho, para conferir. Você nunca conta de cabeça: mostra a
   > tabela do script sem mudar números, diz a regra usada e só depois
   > interpreta, apontando falsos positivos nos trechos. Teste com a
   > transcrição anexada e salve a habilidade.

   Anexe a transcrição para ele testar. Leva alguns minutos.

3. **Com a habilidade.** Em duas conversas novas, faça a mesma pergunta do passo
   1, agora começando com "Use a habilidade contar-termos". Anote os dois
   totais.

## Entrega

Os **quatro totais** (dois sem habilidade, dois com) e **um falso positivo**
que você achou nos trechos: uma palavra contada como preço que não era sobre
preço. Compare com a dupla do lado: os números com habilidade bateram? Se não,
qual termo uma dupla incluiu e a outra não?

## O que aconteceu na preparação

No Chat, a mesma pergunta, com o mesmo arquivo, em três conversas novas, deu
**157, 161 e 210** falas sobre preço. O Diego apareceu com 13, 12 e 25. Em cada
vez, o ChatGPT escolheu um critério um pouco diferente (incluiu reembolso, tirou
reembolso, incluiu bagagem) e contou "de olho".

A habilidade de referência, em `skills/contar-termos/`, dá sempre a mesma
tabela. Com os termos padrão: **162 menções a preço**, 41 a atraso, 89 a
bagagem e 39 a atendimento. E erra sempre do mesmo jeito: "filmando na **cara**"
entra como preço. O erro fica visível nos trechos, e corrigir é mudar a lista
de termos.

```bash
python skills/contar-termos/scripts/contar_termos.py exercicios/01-habilidade-python/grupo_focal_aerea_sol.txt --trechos trechos.csv
```

## Para ir além

- Peça uma contagem por bloco do roteiro (aquecimento, compra, dia do voo,
  problema). O tema muda de dono ao longo da conversa?
- Peça para a habilidade comparar a Aérea Sol com LATAM, Gol e Azul: quantas
  vezes cada concorrente é citado, e por quem.
