# Exercício 1. Uma habilidade que conta com Python

**Onde:** aplicativo de desktop, modo Work. Se não conseguir instalar o
aplicativo, use o Work no navegador. **Em duplas**, cada pessoa com um papel.

## A situação

Uma agência fez um grupo focal com oito viajantes frequentes para a Aérea Sol,
uma companhia aérea. A transcrição tem quase duas horas de conversa e 18 mil
palavras. A diretoria de marketing quer saber, antes de ler tudo: **de que eles
mais falam, e quem fala de quê?** Para começar, quantas vezes cada pessoa falou
de **preço**.

Parece uma pergunta fácil para o ChatGPT. O problema aparece quando a mesma
pergunta é feita duas vezes.

## Material

`exercicios/01-habilidade-python/grupo_focal_aerea_sol.txt`: a transcrição, uma
fala por linha (`NOME: texto`). Tudo é fictício: a companhia, as pessoas e a
conversa foram criadas para o curso.

## Passos

A dupla se divide: a **pessoa 1** só pergunta, sem habilidade; a **pessoa 2**
cria a habilidade e depois usa. Trabalhem ao mesmo tempo, cada uma no seu
computador.

1. **Pessoa 1: sem habilidade.** Numa conversa nova, anexe a transcrição e
   pergunte:

   > Neste grupo focal, quantas vezes cada participante falou de preço? Não
   > conte a moderadora. Quero um número por pessoa e o total.

   Anote o total. Abra **outra** conversa nova, anexe de novo, pergunte igual e
   anote.

2. **Pessoa 2: crie a habilidade.** Personalizar → Habilidades → Adicionar →
   **Criar com chat**. Depois do texto que já vem pronto, mande o pedido,
   escrito em partes com nome (objetivo, entrada, regras, saída e quando está
   pronto):

   > **Objetivo.** Criar uma habilidade chamada contar-termos, que conta
   > quantas vezes cada tema aparece numa transcrição, por pessoa, sempre do
   > mesmo jeito.
   >
   > **Entrada.** Uma transcrição de entrevista ou grupo focal, uma fala por
   > linha, no formato NOME: texto. A moderadora fica de fora.
   >
   > **Regras do script.** A contagem é feita por um script Python, nunca de
   > cabeça. Conta palavra inteira, sem diferenciar acento e maiúscula. Cada
   > tema é uma lista de termos (preço = preço, preços, caro, cara, barato,
   > barata, tarifa); um termo terminado em * pega o começo da palavra (atras*
   > pega atraso, atrasou, atrasado).
   >
   > **Antes de contar.** Se eu não disser os termos, mostre a lista que vai
   > usar e pergunte se está boa.
   >
   > **Saída.** A tabela do script, sem mudar números; a regra usada; um CSV
   > com cada ocorrência, a linha e o trecho, para conferir; e só então a
   > interpretação, apontando os falsos positivos nos trechos.
   >
   > **Pronto quando.** Testou com a transcrição anexada, mostrou o resultado e
   > salvou a habilidade.

   Anexe a transcrição para ele testar. Leva alguns minutos.

3. **Pessoa 2: use a habilidade.** Em duas conversas novas, faça a mesma
   pergunta do passo 1, agora começando com "Use a habilidade contar-termos".
   Anote os dois totais.

4. **Juntos.** Comparem os quatro totais. Nos trechos que a habilidade salvou,
   procurem uma palavra contada como preço que não era sobre preço. Os números
   com habilidade bateram com os da dupla do lado? Se não, qual termo uma dupla
   incluiu e a outra não?

## O que aconteceu na preparação

No Chat, a mesma pergunta, com o mesmo arquivo, em três conversas novas, deu
**157, 161 e 210** falas sobre preço. O Diego apareceu com 13, 12 e 25. Em cada
vez, o ChatGPT escolheu um critério um pouco diferente (incluiu reembolso, tirou
reembolso, incluiu bagagem) e contou "de olho".

A habilidade de referência, em `skills/contar-termos/`, dá sempre a mesma
tabela. Com os termos padrão: **162 menções a preço**, 41 a atraso, 89 a
bagagem e 39 a atendimento. E erra sempre do mesmo jeito: "filmando na **cara**"
entra como preço. O erro fica visível nos trechos, e corrigir é mudar a lista
de termos.

```bash
python skills/contar-termos/scripts/contar_termos.py exercicios/01-habilidade-python/grupo_focal_aerea_sol.txt --trechos trechos.csv
```

## Para ir além

- Peça uma contagem por bloco do roteiro (aquecimento, compra, dia do voo,
  problema). O tema muda de dono ao longo da conversa?
- Peça para a habilidade comparar a Aérea Sol com LATAM, Gol e Azul: quantas
  vezes cada concorrente é citado, e por quem.
