# Exercício 8. Do chat ao projeto

**Onde:** aplicativo de desktop do ChatGPT, aba Codex. **Em duplas.**
**Tempo:** 35 minutos.

Na quarta, o trabalho morou em conversas: a hipótese da manhã e os dois
relatórios da tarde sobre a sua companhia. Aqui ele vira uma pasta que qualquer
pessoa (ou agente) roda de novo com um comando.

## Material

- os arquivos das suas conversas de quarta (scripts, tabelas, relatórios):
  baixe de cada conversa;
- `dados/voos_2026.csv` e o dicionário da base;
- se faltar algo, use os do pacote do curso;
- para comparar: `exemplos/projeto-voos/` (liberado depois do estúdio 3).

## Passos

1. Crie uma pasta, ponha os arquivos dentro e abra-a no Codex.
2. Peça:

   > Organize esta pasta como projeto: uma etapa por arquivo em `etapas/`, um
   > `rodar.py` que refaz tudo e diz quantas linhas entraram e saíram em cada
   > etapa, um `README.md` e um `AGENTS.md` com estas regras: [as regras que a
   > auditoria do estúdio 3 deixou]; uma regressão por companhia; valide no
   > tempo, treinando com janeiro a julho e testando com agosto a outubro;
   > chaves só no `.env`; nenhum dado pessoal nos arquivos. Não altere nada em
   > `dados/`. Ao final, rode `python rodar.py` e mostre que os números batem
   > com os do meu relatório de quarta.

3. Leia a diferença de cada mudança antes de aceitar.
4. Rode `python rodar.py` você mesmo e compare com o relatório de quarta: o R²
   e o fator que mais pesa são os mesmos?

## Entrega

A pasta do projeto e as **três regras** do seu `AGENTS.md` que você considera
mais importantes.
