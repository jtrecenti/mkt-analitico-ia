# Exercício 8. Do chat ao projeto

**Onde:** aplicativo de desktop do ChatGPT, aba Codex. **Tempo:** 35 minutos.

Na quarta, o trabalho morou em conversas. Aqui ele vira uma pasta que qualquer
pessoa (ou agente) roda de novo com um comando.

## Material

- os arquivos das suas conversas de quarta (scripts, dicionário, CSVs,
  relatórios): baixe de cada conversa;
- se faltar algo, use os do pacote do curso;
- para comparar: `exemplos/projeto-relatos/` (liberado depois do estúdio 3).

## Passos

1. Crie uma pasta, ponha os arquivos dentro e abra-a no Codex.
2. Peça:

   > Organize esta pasta como projeto: uma etapa por arquivo em `etapas/`, um
   > `rodar.py` que refaz tudo e diz quantas linhas entraram e saíram em cada
   > etapa, um `README.md` e um `AGENTS.md` com estas regras: cada variável é
   > extraída só do texto de onde ela sai; só entram no modelo colunas que
   > existem antes da nota; chaves só no `.env`; nenhum dado pessoal nos
   > arquivos. Não altere nada em `dados/`. Ao final, rode `python rodar.py` e
   > mostre que os números batem com os do meu relatório de quarta.

3. Leia a diferença de cada mudança antes de aceitar.

## Entrega

A pasta do projeto e as **três regras** do seu `AGENTS.md` que você considera
mais importantes.
