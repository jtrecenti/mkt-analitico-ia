# Exercício 9. Um teste que pega o erro

**Onde:** aplicativo de desktop do ChatGPT, aba Codex. **Em duplas.**
**Tempo:** 35 minutos.

Um teste é uma frase do tipo "isto precisa ser verdade", escrita de um jeito
que o computador confere sozinho, toda vez que o projeto roda.

## Passos

1. Escolha um erro que aconteceu com você nesta semana, ou um destes:
   - o modelo usou uma coluna que o estúdio 3 mandou tirar;
   - a validação separou treino e teste ao acaso, e não pelo tempo;
   - a TAP entrou no mesmo modelo que as companhias domésticas;
   - a regressão descartou linhas sem avisar;
   - a IA respondeu uma categoria que não está no dicionário.
2. Escreva a regra em português: "toda X precisa Y".
3. Peça ao Codex:

   > Escreva um teste em `testes/` para esta regra: [...]. Rode o teste **antes**
   > de corrigir qualquer coisa e me mostre que ele falha. Depois corrija o
   > código e rode de novo.

4. Se o teste passar de primeira, desconfie: ele está testando o que você
   pensa? Peça para o Codex "quebrar" o código de propósito e ver se o teste
   pega.

## Entrega

A regra em português e o print do teste falhando e depois passando.
