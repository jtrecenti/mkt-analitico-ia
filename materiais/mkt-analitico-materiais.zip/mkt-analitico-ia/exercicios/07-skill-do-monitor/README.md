# Exercício 7. A skill do monitor

**Onde:** aplicativo de desktop do ChatGPT, modo Work. **Em duplas.**

## O objetivo, em uma frase

Fazer o monitor rodar **fora da sua pasta**: amanhã, uma colega que nunca viu o
seu projeto pede "atualize o monitor de avaliações" e recebe a mesma página,
com os mesmos números.

## Por que agora, e não no exercício 6

A pasta do exercício 6 é onde vocês **descobriram** o processo: as regras
apareceram trabalhando (as avaliações repetidas entre coletas, a avaliação
editada, o telefone no texto). A skill é o que se tira de um processo que já
funcionou: os passos, os scripts e as checagens, sem os dados. Começar pela
skill seria escrever a receita antes de cozinhar o prato.

| fica na pasta | vai na skill |
|---|---|
| as coletas de cada dia | os passos, na ordem |
| as saídas (a página de hoje) | os scripts que fazem as contas |
| o histórico do que foi decidido | as checagens |
| | a descrição de quando usar |

## Material

A pasta do exercício 6, já rodando. Para comparar depois:
`skills/monitor-avaliacoes-app/`.

## Passos

1. Na pasta do projeto, peçam:

   > Transforme este projeto numa skill chamada `monitor-avaliacoes-app`. O
   > `SKILL.md` precisa ter: uma descrição que diga quando usar ("quando pedirem
   > para atualizar o monitor de avaliações"); os passos na ordem; as regras do
   > `AGENTS.md`; e o que fazer quando uma checagem bloquear (perguntar ao
   > usuário, nunca resolver sozinho). Coloque o código numa pasta `scripts/`,
   > recebendo a pasta dos dados como parâmetro, e não inclua nenhuma coleta.
   > Teste a skill numa pasta nova antes de me entregar.

2. Instalem a skill: Personalizar → Habilidades → Adicionar, como na terça.
3. **O teste da colega:** abram uma conversa nova, **sem** a pasta do projeto.
   Anexem só as duas coletas do pacote e peçam "atualize o monitor de
   avaliações".

## Como saber que deu certo

A conversa nova chega a **2.010 avaliações diferentes** e **10 novas**, avisa a
avaliação que mudou de nota e mascara os três telefones. Se algum número não
bater, o que ficou de fora da skill? Corrijam e repitam o teste.

## Se sobrar tempo

Comparem a skill de vocês com `skills/monitor-avaliacoes-app/`: o que a de
vocês tem que a do professor não tem, e o contrário?
