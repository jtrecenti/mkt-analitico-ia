---
name: monitor-avaliacoes-app
description: Acompanha todo dia as avaliações de aplicativos na App Store do Brasil (por padrão LATAM, GOL, Azul e TAP), junta a coleta de hoje com as anteriores sem contar repetidas, roda checagens de consistência e gera uma página estática (index.html) com nota dos últimos 30 dias, temas e avaliações novas. Use quando pedirem para atualizar o monitor de avaliações, ver o que mudou nas avaliações de um app desde a última coleta ou gerar a página do monitor.
---

# Monitor de avaliações de aplicativos

Todo dia, a mesma receita: os mesmos passos, as mesmas regras e as mesmas
checagens. **O script conta; você lê e escreve o resumo.** Nunca refaça as
contas de cabeça nem escreva um número que não saiu do script.

## Passo 1: a pasta

A pasta de trabalho precisa ter `dados/coletas/` (as coletas anteriores, uma por
dia, com o nome `avaliacoes_AAAA-MM-DD.csv`) e `regras/termos.csv`. Se não
existir, crie as pastas e copie `regras/termos.csv` desta skill. Nunca edite um
arquivo de `dados/coletas/`.

## Passo 2: rodar

```bash
python scripts/rodar.py --baixar --pasta CAMINHO_DA_PASTA
```

Precisa de `pandas` e `requests`. O script baixa a coleta de hoje do feed
público da Apple, junta com as anteriores, roda as checagens e, se nenhuma
bloquear, grava `saida/index.html`. Se a internet do ambiente não alcançar a
Apple, peça ao usuário o arquivo da coleta de hoje e rode sem `--baixar`.

## Passo 3: se alguma checagem bloquear

Mostre a checagem que falhou e o detalhe, e **pergunte** o que fazer. Não
resolva sozinho, e nunca edite uma coleta para a checagem passar.

## Passo 4: entregar

1. A página `saida/index.html`.
2. Um resumo de três frases: o que mudou desde a coleta anterior, a companhia
   que merece atenção e por quê, e um tema que cresceu. Só números da página.
3. Os alertas (avaliações editadas, dado pessoal mascarado, coleta incompleta),
   em linguagem simples.
4. Lembre que a página pode ser publicada arrastando a pasta `saida/` no
   Netlify Drop (app.netlify.com/drop).

## Regras

- A mesma avaliação em várias coletas conta uma vez; se mudou, vale a mais recente.
- Telefone, e-mail e CPF no texto são mascarados. A página mostra só números
  agregados e títulos, nunca o apelido de quem avaliou.
- Para outro aplicativo, acrescente o nome e o id da App Store em `APPS`, em
  `scripts/passos/p1_coletar.py`, e o nome em `EMPRESAS`, em `p3_checar.py`.
