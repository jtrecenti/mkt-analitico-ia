---
name: relatorio-mensal-midia
description: Faz o relatório mensal de mídia da Bora Bebidas (investimento, pedidos, receita, CPA e ROAS por canal, com comparação com o mês anterior) a partir dos arquivos midia_AAAA-MM.csv e vendas_AAAA-MM.csv, sempre com os mesmos passos e as mesmas checagens de consistência. Use quando chegarem os arquivos de um mês novo ou quando pedirem o relatório de mídia de um mês.
---

# Relatório mensal de mídia

Todo mês, a mesma receita: os mesmos passos, as mesmas regras e as mesmas
checagens. **O script calcula; você lê e escreve as três frases de leitura.**
Nunca refaça as contas de cabeça nem escreva um número que não saiu do script.

## Passo 1: montar a pasta

A pasta de trabalho precisa ter:

```
dados/brutos/midia_AAAA-MM.csv    o mês do relatório e o mês anterior
dados/brutos/vendas_AAAA-MM.csv
regras/canais.csv                 colunas: como_chega,nome_padrao
regras/correcoes.csv              colunas: data,campanha,coluna,valor_correto,quem_confirmou
```

Se `regras/` não existir, crie os dois arquivos só com o cabeçalho. Nunca edite
os arquivos de `dados/brutos/`: eles ficam como chegaram.

## Passo 2: rodar

```bash
python scripts/rodar.py AAAA-MM --pasta CAMINHO_DA_PASTA
```

Precisa só de `pandas`. O script lê, aplica as regras, roda as checagens e, se
nenhuma checagem bloquear, grava `saida/relatorio_AAAA-MM.html`.

## Passo 3: se alguma checagem bloquear

Mostre ao usuário a checagem que falhou e o detalhe, e **pergunte** o que fazer.
Não resolva sozinho:

- canal desconhecido: confirme com o usuário e acrescente a linha em
  `regras/canais.csv`;
- investimento fora do padrão: só entra depois de confirmado com a agência, numa
  linha de `regras/correcoes.csv` com quem confirmou;
- qualquer outra: descreva o problema, quantas linhas ele afeta e o que muda no
  relatório se ninguém corrigir.

Depois, rode de novo o Passo 2.

## Passo 4: entregar

1. O relatório HTML gerado.
2. Três frases de leitura: o que foi bem, o que foi mal e o que sugerir para o
   mês seguinte, usando só números do relatório.
3. Os alertas e o que as regras mexeram nos dados (o relatório já lista), em
   linguagem simples.

## Regras

- O canal Direto não tem investimento: não tem CPA nem ROAS.
- Diga quantas linhas entraram e quantas saíram em cada passo (o script mostra).
- Nenhum dado pessoal entra nos arquivos. Chaves de API só no `.env`.
