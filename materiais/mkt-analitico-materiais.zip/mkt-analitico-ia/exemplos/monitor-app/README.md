# Monitor das avaliações dos apps das companhias aéreas

O projeto do professor para o exercício 6. Dados reais: o feed público
de avaliações da App Store do Brasil, coletado em 3/11/2026 e em 5/11/2026.

## Como rodar

```
python rodar.py            refaz o relatório com as coletas que já existem
python rodar.py --baixar   baixa a coleta de hoje e refaz o relatório
```

Precisa de `pandas`, `requests`, `typesafe-sdk` (o Jev), `python-dotenv`, do
Quarto (`pip install quarto-cli`) e do Jupyter (`pip install jupyter`). A chave
`JEV_API_KEY` fica no `.env` desta pasta. O relatório sai em `saida/index.html`.

## O que tem aqui

```
AGENTS.md                as regras, que o agente lê antes de qualquer tarefa
rodar.py                 refaz tudo, da coleta ao relatório
relatorio.qmd            o relatório (Quarto, com gráficos do ECharts)
dados/coletas/           uma coleta por dia, como chegou (nunca editada)
dados/estruturado/       o cache das classificações feitas pela IA
dados/processados/       a base pronta que o relatório lê
regras/apps.csv          os aplicativos monitorados
regras/dicionario.json   as perguntas e as opções para a IA
regras/estilo.css        o visual do relatório
passos/p1_coletar.py     baixa a coleta de hoje e lê todas as coletas
passos/p2_juntar.py      uma linha por avaliação; editadas; novas; dados pessoais
passos/p3_checar.py      as checagens: bloqueiam ou alertam
passos/p4_estruturar.py  o tema e a reclamação de cada avaliação, com o Jev
passos/p5_relatorio.py   grava a base pronta e renderiza o relatório
saida/index.html         o relatório gerado
```

## O que as duas primeiras coletas mostraram

- As duas coletas somam 4.000 linhas, mas só 2.010 avaliações diferentes: 1.990
  aparecem nas duas. Juntando sem cuidado, o relatório diria que chegaram 2.000
  avaliações novas em dois dias. Chegaram 10.
- Uma avaliação da LATAM, de 25/9, mudou de nota 1 para nota 5 entre as coletas.
- Três avaliações traziam o que parece um número de telefone no texto.
- O Jev classificou as 758 avaliações dos últimos 90 dias; 46 ficaram com
  confiança abaixo de 60% no tema. "App com falha" é o assunto mais comum nas
  reclamações (72 de 344).
