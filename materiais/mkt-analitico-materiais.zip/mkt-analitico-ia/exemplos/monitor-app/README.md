# Monitor das avaliações dos apps das companhias aéreas

O projeto do professor para os exercícios 6 e 7. Dados reais: o feed público
de avaliações da App Store do Brasil, coletado em 3/11/2026 e em 5/11/2026.

## Como rodar

```
python rodar.py            refaz a página com as coletas que já existem
python rodar.py --baixar   baixa a coleta de hoje e refaz a página
```

Precisa de `pandas` e `requests`. A página sai em `saida/index.html`.

## O que tem aqui

```
AGENTS.md              as regras, que o agente lê antes de qualquer tarefa
rodar.py               refaz tudo, da coleta à página
dados/coletas/         uma coleta por dia, como chegou (nunca editada)
regras/termos.csv      os temas e as palavras-chave de cada um
passos/p1_coletar.py   baixa a coleta de hoje e lê todas as coletas
passos/p2_juntar.py    uma linha por avaliação; editadas; novas; dados pessoais
passos/p3_checar.py    as checagens: bloqueiam ou alertam
passos/p4_pagina.py    a página estática (index.html)
saida/                 a página gerada
```

## O que as duas primeiras coletas mostraram

- As duas coletas somam 4.000 linhas, mas só 2.010 avaliações diferentes: 1.990
  aparecem nas duas. Juntando sem cuidado, o relatório diria que chegaram 2.000
  avaliações novas em dois dias. Chegaram 10.
- Uma avaliação da LATAM, de 25/9, mudou de nota 1 para nota 5 entre as coletas.
- Três avaliações traziam o que parece um número de telefone no texto.
