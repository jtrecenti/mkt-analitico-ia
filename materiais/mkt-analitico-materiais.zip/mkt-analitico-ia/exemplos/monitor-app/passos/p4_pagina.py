"""Passo 4: a página estática do monitor (um único index.html, pronto para o Netlify Drop)."""
import html
from pathlib import Path

import pandas as pd

ORDEM = ["LATAM", "GOL", "Azul", "TAP"]


def numeros(base: pd.DataFrame, termos: pd.DataFrame, hoje: str) -> pd.DataFrame:
    fim = pd.Timestamp(hoje)
    d = base.assign(dt=pd.to_datetime(base["data"]))
    txt = (d["titulo"].fillna("") + " " + d["texto"].fillna("")).str.lower()
    linhas = []
    for e in ORDEM:
        x = d[d["empresa"] == e]
        u30 = x[x["dt"] > fim - pd.Timedelta(days=30)]
        a30 = x[(x["dt"] <= fim - pd.Timedelta(days=30)) & (x["dt"] > fim - pd.Timedelta(days=60))]
        u90 = txt[(d["empresa"] == e) & (d["dt"] > fim - pd.Timedelta(days=90))]
        lin = {"empresa": e, "avaliacoes": len(x), "nota_media": x["nota"].mean(),
               "ultimos_30": len(u30), "nota_30": u30["nota"].mean(), "nota_30_anteriores": a30["nota"].mean(),
               "uma_estrela_30": (u30["nota"] == 1).mean(), "novas": int(x["nova"].sum()),
               "ultimos_90": len(u90)}
        for t in termos.itertuples():
            lin[t.tema] = u90.str.contains(t.palavras, regex=True).mean() if len(u90) else float("nan")
        linhas.append(lin)
    return pd.DataFrame(linhas).set_index("empresa")


def pct(x):
    return "" if pd.isna(x) else f"{x:.0%}"


def num(x, casas=1):
    return "" if pd.isna(x) else f"{x:.{casas}f}".replace(".", ",")


def escrever(pasta: Path, hoje: str, t: pd.DataFrame, base: pd.DataFrame, termos, log, checagens) -> Path:
    cards = ""
    for e, r in t.iterrows():
        delta = r.nota_30 - r.nota_30_anteriores
        seta = "" if pd.isna(delta) else (f'<span class="{"bom" if delta >= 0 else "ruim"}">{"+" if delta >= 0 else ""}{num(delta)}</span> sobre os 30 dias anteriores')
        cards += (f'<div class="card"><h3>{e}</h3><div class="big">{num(r.nota_30)}</div>'
                  f'<div class="p">nota média nos últimos 30 dias ({int(r.ultimos_30)} avaliações) {seta}</div>'
                  f'<div class="p">{pct(r.uma_estrela_30)} com 1 estrela · {int(r.novas)} nova(s) desde a coleta anterior</div></div>')
    temas = "".join(
        f"<tr><td>{html.escape(tm)}</td>" + "".join(
            f'<td><span class="barra" style="width:{0 if pd.isna(t.loc[e, tm]) else t.loc[e, tm] * 160:.0f}px"></span> {pct(t.loc[e, tm])}</td>'
            for e in t.index) + "</tr>" for tm in termos["tema"])
    novas = base[base["nova"]].sort_values(["empresa", "data"])
    lista = "".join(f"<li><b>{x.empresa}</b>, {x.data}, nota {x.nota}: {html.escape(str(x.titulo))}</li>"
                    for x in novas.itertuples()) or "<li>nenhuma</li>"
    alertas = "".join(f"<li>{html.escape(x['frase'])}: {html.escape(x['detalhe'])}</li>"
                      for x in checagens if not x["ok"]) or "<li>nenhum</li>"
    mexeu = "".join(f"<li>{html.escape(x)}</li>" for x in log)
    doc = f"""<!doctype html><html lang="pt-BR"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Monitor das avaliações dos apps das companhias aéreas</title>
<style>
body{{font-family:system-ui,-apple-system,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#1d1d1f}}
h1{{font-size:1.6rem;margin-bottom:.2rem}}.sub{{color:#666;margin-top:0}}
.cards{{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:.8rem}}
.card{{background:#f4f4f6;border-radius:12px;padding:.9rem 1rem}}.card h3{{margin:0}}
.big{{font-size:2.4rem;font-weight:700}}.p{{color:#555;font-size:.9rem;margin-top:.2rem}}
.bom{{color:#0a7a3d;font-weight:700}}.ruim{{color:#c8102e;font-weight:700}}
table{{border-collapse:collapse;width:100%;font-size:.92rem}}td,th{{padding:.35rem .5rem;border-bottom:1px solid #ddd;text-align:left}}
.barra{{display:inline-block;height:10px;background:#c8102e;border-radius:3px;vertical-align:middle}}
footer{{color:#777;font-size:.85rem;margin-top:2rem;border-top:1px solid #ddd;padding-top:.8rem}}
</style></head><body>
<h1>Monitor das avaliações dos apps das companhias aéreas</h1>
<p class="sub">App Store do Brasil · atualizado com a coleta de {hoje} · {len(base)} avaliações diferentes na base</p>
<div class="cards">{cards}</div>
<h2>Do que falam as avaliações dos últimos 90 dias</h2>
<p class="p">Parcela das avaliações que menciona cada tema (contagem por palavras-chave de regras/termos.csv; uma avaliação pode falar de vários).</p>
<table><tr><th>tema</th>{"".join(f"<th>{e}</th>" for e in t.index)}</tr>{temas}</table>
<h2>Novas desde a coleta anterior</h2><ul>{lista}</ul>
<h2>Alertas para olhar</h2><ul>{alertas}</ul>
<h2>O que as regras mexeram nos dados</h2><ul>{mexeu}</ul>
<footer>Fonte: feed público de avaliações da App Store do Brasil (as 500 mais recentes de cada app, a cada coleta).
Sem o apelido de quem avaliou; telefones, e-mails e CPFs mascarados. Gerado por <code>python rodar.py</code>; as coletas
originais ficam em dados/coletas/ e não são editadas.</footer>
</body></html>"""
    saida = pasta / "saida"
    saida.mkdir(exist_ok=True)
    arq = saida / "index.html"
    arq.write_text(doc, encoding="utf-8")
    return arq
