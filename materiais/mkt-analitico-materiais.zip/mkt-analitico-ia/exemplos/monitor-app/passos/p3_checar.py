"""Passo 3: checagens de consistência. Cada uma é uma frase que precisa ser verdade.

"bloqueia": a página não sai enquanto ela falhar.
"alerta": a página sai, com um aviso para alguém olhar.
"""
import pandas as pd

EMPRESAS = {"LATAM", "GOL", "Azul", "TAP"}
COLUNAS = ["empresa", "id_avaliacao", "data", "nota", "versao_app", "titulo", "texto"]


def checar(coletas: dict[str, pd.DataFrame], base: pd.DataFrame, log: list):
    r = []

    def ch(frase, ok, tipo="bloqueia", detalhe=""):
        r.append({"frase": frase, "ok": bool(ok), "tipo": tipo, "detalhe": detalhe})

    ruins = [d for d, c in coletas.items() if list(c.columns) != COLUNAS]
    ch("toda coleta tem as colunas esperadas", not ruins, detalhe=", ".join(ruins))
    faltam = {d: sorted(EMPRESAS - set(c["empresa"])) for d, c in coletas.items() if EMPRESAS - set(c["empresa"])}
    ch("toda coleta tem as quatro companhias", not faltam, detalhe="; ".join(f"{d}: falta {', '.join(e)}" for d, e in faltam.items()))
    ch("toda nota está entre 1 e 5", base["nota"].between(1, 5).all())
    rep = {d: int(c["id_avaliacao"].duplicated().sum()) for d, c in coletas.items() if c["id_avaliacao"].duplicated().any()}
    ch("nenhuma avaliação repetida dentro de uma mesma coleta", not rep, detalhe=str(rep) if rep else "")
    futuro = {d: int((c["data"] > d).sum()) for d, c in coletas.items() if (c["data"] > d).any()}
    ch("nenhuma avaliação com data depois do dia da coleta", not futuro, detalhe=str(futuro) if futuro else "")

    # alertas
    curtas = [f"{d} {e}: {n}" for d, c in coletas.items() for e, n in c["empresa"].value_counts().items() if n < 500]
    ch("toda companhia veio com as 500 avaliações do feed", not curtas, "alerta",
       "; ".join(curtas) + (" (o feed pode ter falhado no meio)" if curtas else ""))
    dias = sorted(coletas)
    buracos = []
    for a, b in zip(dias, dias[1:]):
        for e in EMPRESAS:
            ant, nov = coletas[a][coletas[a]["empresa"] == e], coletas[b][coletas[b]["empresa"] == e]
            if len(nov) and len(ant) and nov["data"].min() > ant["data"].max():
                buracos.append(f"{e} entre {a} e {b}")
    ch("cada coleta alcança a anterior (nenhuma avaliação perdida no meio)", not buracos, "alerta",
       "; ".join(buracos) + (": colete com mais frequência" if buracos else ""))
    ed = base[base["editada"]]
    ch("nenhuma avaliação mudou entre coletas", ed.empty, "alerta",
       "; ".join(f"{x.empresa}, avaliação de {x.data}, agora com nota {x.nota}" for x in ed.itertuples()))
    pessoais = [x for x in log if "mascarados" in x]
    ch("nenhum texto com cara de dado pessoal", not pessoais, "alerta", "; ".join(pessoais))

    for x in r:
        marca = "ok " if x["ok"] else ("XX " if x["tipo"] == "bloqueia" else "!! ")
        print(f"  {marca} {x['frase']}" + (f"  ({x['detalhe']})" if x["detalhe"] and not x["ok"] else ""))
    return r
