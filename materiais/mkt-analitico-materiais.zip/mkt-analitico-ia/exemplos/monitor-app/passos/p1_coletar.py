"""Passo 1: baixar a coleta de hoje (opcional) e ler todas as coletas, como chegaram.

O feed público da Apple devolve só as 500 avaliações mais recentes de cada
aplicativo. Cada coleta fica em dados/coletas/avaliacoes_AAAA-MM-DD.csv e nunca
é editada. O apelido de quem avaliou não é guardado.
"""
import json
import time
from datetime import date
from pathlib import Path

import pandas as pd
import requests

APPS = {"LATAM": 1497908631, "GOL": 337961662, "Azul": 690105616, "TAP": 440497198}
FEED = "https://itunes.apple.com/br/rss/customerreviews/page={p}/id={app}/sortby=mostrecent/json"


def baixar_hoje(pasta: Path) -> Path:
    linhas = []
    for nome, app in APPS.items():
        for p in range(1, 11):
            r = requests.get(FEED.format(p=p, app=app), timeout=30)
            r.raise_for_status()
            entradas = [e for e in r.json().get("feed", {}).get("entry", []) if "im:rating" in e]
            if not entradas:
                break
            linhas += [{"empresa": nome, "id_avaliacao": e["id"]["label"], "data": e["updated"]["label"][:10],
                        "nota": int(e["im:rating"]["label"]), "versao_app": e.get("im:version", {}).get("label"),
                        "titulo": e["title"]["label"], "texto": e["content"]["label"]} for e in entradas]
            time.sleep(1)
    arq = pasta / "dados" / "coletas" / f"avaliacoes_{date.today().isoformat()}.csv"
    pd.DataFrame(linhas).to_csv(arq, index=False)
    print(f"  coleta de hoje: {len(linhas)} avaliações em {arq.name}")
    return arq


def ler_coletas(pasta: Path) -> dict[str, pd.DataFrame]:
    coletas = {}
    for arq in sorted((pasta / "dados" / "coletas").glob("avaliacoes_*.csv")):
        dia = arq.stem.removeprefix("avaliacoes_")
        coletas[dia] = pd.read_csv(arq, dtype={"id_avaliacao": str, "data": str, "versao_app": str})
        print(f"  coleta de {dia}: {len(coletas[dia])} linhas")
    return coletas
