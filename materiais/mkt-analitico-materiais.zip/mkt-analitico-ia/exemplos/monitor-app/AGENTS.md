# Regras deste projeto (o agente lê antes de qualquer tarefa)

Este projeto acompanha, todo dia, as avaliações dos aplicativos da LATAM, GOL,
Azul e TAP na App Store do Brasil, e publica uma página com o resumo.

## Como rodar

- Um comando refaz tudo: `python rodar.py --baixar` (baixa a coleta de hoje e
  refaz a página). Sem `--baixar`, refaz só com as coletas que já existem.
- A página sai em `saida/index.html`, um arquivo único, pronto para arrastar no
  Netlify Drop. Nunca escreva números na página à mão: todo número sai dos passos.

## Dados

- Cada coleta fica em `dados/coletas/avaliacoes_AAAA-MM-DD.csv` e **nunca é
  editada**. Toda correção é um passo escrito ou uma linha em `regras/`.
- O feed da Apple devolve só as 500 avaliações mais recentes de cada app: colete
  com frequência para não perder nenhuma no meio.
- Em cada passo, diga quantas linhas entraram, quantas saíram e por quê.

## Regras de negócio

- A mesma avaliação aparece em várias coletas e conta **uma vez**.
- Se a avaliação mudou entre coletas (a pessoa editou), vale a versão mais
  recente, e a página avisa.
- "Novas" são as avaliações que não estavam em nenhuma coleta anterior.
- Os temas são contados por palavras-chave, com a lista de `regras/termos.csv`.
  Mudou a lista, mudam os números: anote a data da mudança no README.

## Dados pessoais

- O apelido de quem avaliou não é guardado.
- Telefone, e-mail e CPF dentro do texto são mascarados antes de qualquer saída.
- A página publicada só mostra números agregados e os títulos das avaliações
  novas, nunca o texto inteiro.

## Checagens

- Estão em `passos/p3_checar.py`. Uma checagem que **bloqueia** impede a página;
  um **alerta** entra na página para alguém olhar.
- Todo problema novo vira uma checagem nova. Antes de confiar nela, quebre uma
  cópia do dado de propósito e veja a checagem falhar.

## Chaves

- Este projeto não usa chave de API. Se um passo novo usar (por exemplo, para
  classificar temas com IA), a chave fica só no `.env`.
