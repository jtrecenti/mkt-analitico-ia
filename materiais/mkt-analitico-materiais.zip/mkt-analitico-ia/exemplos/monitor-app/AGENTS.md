# Regras deste projeto (o agente lê antes de qualquer tarefa)

Este projeto acompanha, todo dia, as avaliações dos aplicativos da LATAM, GOL,
Azul e TAP na App Store do Brasil, e publica um relatório HTML com o resumo.

## Como rodar

- Um comando refaz tudo: `python rodar.py --baixar` (baixa a coleta de hoje e
  refaz o relatório). Sem `--baixar`, refaz só com as coletas que já existem.
- O relatório é `relatorio.qmd` (Quarto), renderizado em `saida/index.html`, um
  arquivo único com os gráficos dentro, pronto para arrastar no Netlify Drop.
  Precisa do Quarto (`pip install quarto-cli`) e do Jupyter (`pip install jupyter`).
- Nunca escreva números no relatório à mão: todo número, inclusive o dos títulos
  dos gráficos, sai das contas do `relatorio.qmd`.

## Gráficos

- ECharts, um arquivo só. O título de cada gráfico é a conclusão, calculada.
- Barras ordenadas, começando no zero; uma cor de destaque (o vermelho) no que o
  título fala e cinza no resto; rótulo direto em vez de legenda.
- Nada de pizza, 3D, dois eixos y ou boxplot.
- Fonte e data da coleta no rodapé.

## Dados

- Cada coleta fica em `dados/coletas/avaliacoes_AAAA-MM-DD.csv` e **nunca é
  editada**. Toda correção é um passo escrito ou uma linha em `regras/`.
- O feed da Apple devolve só as 500 avaliações mais recentes de cada app: colete
  com frequência para não perder nenhuma no meio.
- Em cada passo, diga quantas linhas entraram, quantas saíram e por quê.

## Regras de negócio

- A mesma avaliação aparece em várias coletas e conta **uma vez**.
- Se a avaliação mudou entre coletas (a pessoa editou), vale a versão mais
  recente, e a página avisa.
- "Novas" são as avaliações que não estavam em nenhuma coleta anterior.
- O tema de cada avaliação e se ela reclama de algo são classificados por IA (o
  Jev), com as perguntas e as opções de `regras/dicionario.json`, só para os
  últimos 90 dias. As respostas ficam no cache `dados/estruturado/cache.jsonl`:
  rodar de novo não classifica de novo. Mudou o dicionário, apague o cache e
  anote a data da mudança no README.
- Os aplicativos monitorados ficam em `regras/apps.csv` (nome e id da App Store).

## Dados pessoais

- O apelido de quem avaliou não é guardado.
- Telefone, e-mail e CPF dentro do texto são mascarados antes de qualquer saída.
- O relatório publicado só mostra números agregados e os títulos das avaliações
  novas, nunca o texto inteiro.

## Checagens

- Estão em `passos/p3_checar.py`. Uma checagem que **bloqueia** impede o relatório;
  um **alerta** entra no relatório para alguém olhar.
- Todo problema novo vira uma checagem nova. Antes de confiar nela, quebre uma
  cópia do dado de propósito e veja a checagem falhar.

## Chaves

- A chave do Jev (`JEV_API_KEY`) fica só no `.env`, que nunca vai para pasta
  compartilhada. Sem a chave, o relatório sai com o que já está no cache.
