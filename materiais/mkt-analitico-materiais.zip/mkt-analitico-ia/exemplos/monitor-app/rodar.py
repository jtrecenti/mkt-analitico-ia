"""Refaz o monitor das avaliações: python rodar.py [--baixar] [--pasta CAMINHO]

--baixar  baixa a coleta de hoje antes (o feed público da App Store).
--pasta   a pasta do projeto (por padrão, a deste arquivo): precisa ter
          dados/coletas/ e regras/termos.csv. A página sai em saida/index.html.
"""
import sys
from pathlib import Path

import pandas as pd

from passos.p1_coletar import baixar_hoje, ler_coletas
from passos.p2_juntar import juntar
from passos.p3_checar import checar
from passos.p4_pagina import escrever, numeros


def main(pasta: Path, baixar: bool) -> None:
    print("1/4 coletar e ler")
    if baixar:
        baixar_hoje(pasta)
    coletas = ler_coletas(pasta)
    hoje = max(coletas)
    print("2/4 juntar");  base, tudo, log = juntar(coletas)
    print("3/4 checar");  ch = checar(coletas, base, log)
    travas = [x for x in ch if not x["ok"] and x["tipo"] == "bloqueia"]
    if travas:
        print(f"\nPÁGINA NÃO GERADA: {len(travas)} checagem(ns) bloqueando. Resolva e rode de novo.")
        sys.exit(1)
    print("4/4 página")
    termos = pd.read_csv(pasta / "regras" / "termos.csv")
    t = numeros(base, termos, hoje)
    arq = escrever(pasta, hoje, t, base, termos, log, ch)
    print(t[["avaliacoes", "nota_30", "novas"]].round(2).to_string())
    print(f"  gravado em {arq}")


if __name__ == "__main__":
    a = sys.argv[1:]
    pasta = Path(a[a.index("--pasta") + 1]) if "--pasta" in a else Path(__file__).resolve().parent
    main(pasta, "--baixar" in a)
