"""Passo 4: a tabela por canal, a comparação com o mês anterior e o relatório em HTML."""
import html
from pathlib import Path

import pandas as pd

ORDEM = ["Meta", "Google", "TikTok", "E-mail", "Direto"]


def resumir(midia: pd.DataFrame, vendas: pd.DataFrame) -> pd.DataFrame:
    a = midia.groupby("canal")[["investimento", "impressoes", "cliques"]].sum()
    b = vendas.groupby("canal_origem").agg(pedidos=("pedido_id", "size"), receita=("valor", "sum"))
    t = a.join(b, how="outer").reindex(ORDEM).fillna(0)
    t.loc["Total"] = t.sum()
    t["cpa"] = (t["investimento"] / t["pedidos"]).where(t["investimento"] > 0)
    t["roas"] = (t["receita"] / t["investimento"]).where(t["investimento"] > 0)
    return t


def brl(x):
    return "" if pd.isna(x) else f"R$ {x:,.0f}".replace(",", ".")


def var(x, y):
    return "" if y is None or pd.isna(x) or pd.isna(y) or y == 0 else f"{x / y - 1:+.0%}"


def escrever(mes: str, t: pd.DataFrame, ant: pd.DataFrame | None, log: list, checagens: list, pasta: Path) -> Path:
    def a(c, col):
        return None if ant is None or c not in ant.index else ant.loc[c, col]

    linhas = "".join(
        f"<tr><td>{c}</td><td>{brl(r.investimento)}</td><td>{var(r.investimento, a(c, 'investimento'))}</td>"
        f"<td>{int(r.pedidos):,}".replace(",", ".") + f"</td><td>{var(r.pedidos, a(c, 'pedidos'))}</td>"
        f"<td>{brl(r.receita)}</td><td>{brl(r.cpa)}</td>"
        f"<td>{'' if pd.isna(r.roas) else f'{r.roas:.1f}'.replace('.', ',')}</td></tr>"
        for c, r in t.iterrows())
    avisos = "".join(f"<li>{html.escape(x)}</li>" for x in log)
    alertas = "".join(f"<li>{html.escape(x['frase'])}: {html.escape(x['detalhe'])}</li>"
                      for x in checagens if not x["ok"])
    doc = f"""<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Bora Bebidas · mídia · {mes}</title>
<style>body{{font-family:system-ui,sans-serif;max-width:860px;margin:2rem auto;color:#1d1d1f}}
table{{border-collapse:collapse;width:100%}}td,th{{padding:.35rem .6rem;border-bottom:1px solid #ddd;text-align:right}}
td:first-child,th:first-child{{text-align:left}}tr:last-child{{font-weight:700}}h1{{font-size:1.5rem}}
.p{{color:#666;font-size:.9rem}}</style>
<h1>Bora Bebidas: relatório de mídia de {mes}</h1>
<table><tr><th>canal</th><th>investimento</th><th>vs mês anterior</th><th>pedidos</th><th>vs mês anterior</th>
<th>receita</th><th>CPA</th><th>ROAS</th></tr>{linhas}</table>
<h2>Alertas para olhar</h2><ul>{alertas or "<li>nenhum</li>"}</ul>
<h2>O que as regras mexeram nos dados</h2><ul>{avisos or "<li>nada</li>"}</ul>
<p class="p">Gerado por <code>python rodar.py {mes}</code>. Os arquivos originais estão em dados/brutos/ e não foram editados.</p>
</html>"""
    saida = pasta / "saida"
    saida.mkdir(exist_ok=True)
    arq = saida / f"relatorio_{mes}.html"
    arq.write_text(doc, encoding="utf-8")
    return arq
