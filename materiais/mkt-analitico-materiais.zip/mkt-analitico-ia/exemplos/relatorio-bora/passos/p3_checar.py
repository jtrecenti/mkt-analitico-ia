"""Passo 3: checagens de consistência. Cada uma é uma frase que precisa ser verdade.

"bloqueia": o relatório não sai enquanto ela falhar.
"alerta": o relatório sai, com um aviso para alguém olhar.
"""
import pandas as pd

CANAIS = {"Meta", "Google", "TikTok", "E-mail"}
COLUNAS_MIDIA = ["data", "canal", "campanha", "investimento", "impressoes", "cliques"]
COLUNAS_VENDAS = ["pedido_id", "data", "canal_origem", "valor"]


def checar(midia: pd.DataFrame, vendas: pd.DataFrame, mes: str, anterior: dict | None):
    r = []

    def ch(frase, ok, tipo="bloqueia", detalhe=""):
        r.append({"frase": frase, "ok": bool(ok), "tipo": tipo, "detalhe": detalhe})

    ch("os arquivos têm as colunas do dicionário",
       list(midia.columns) == COLUNAS_MIDIA and list(vendas.columns) == COLUNAS_VENDAS)
    desconhecidos = sorted(set(midia["canal"]) - CANAIS) + sorted(set(vendas["canal_origem"]) - CANAIS - {"Direto"})
    ch("todo canal é um canal conhecido", not desconhecidos, detalhe=", ".join(desconhecidos))
    fora = int((~midia["data"].str.startswith(mes)).sum() + (~vendas["data"].str.startswith(mes)).sum())
    ch("toda data está dentro do mês", fora == 0, detalhe=f"{fora} linhas fora do mês" if fora else "")
    rep = int(midia.duplicated(["data", "canal", "campanha"]).sum())
    ch("nenhuma linha de mídia repetida", rep == 0, detalhe=f"{rep} repetidas" if rep else "")
    rep = int(vendas["pedido_id"].duplicated().sum())
    ch("nenhum pedido repetido", rep == 0, detalhe=f"{rep} repetidos" if rep else "")
    neg = int((midia[["investimento", "impressoes", "cliques"]] < 0).any(axis=1).sum() + (vendas["valor"] <= 0).sum())
    ch("nenhum número negativo ou zerado onde não pode", neg == 0, detalhe=f"{neg} linhas" if neg else "")
    ch("cliques nunca passam das impressões", (midia["cliques"] <= midia["impressoes"]).all())
    med = midia.groupby("campanha")["investimento"].transform("median")
    estranhos = midia[midia["investimento"] > 5 * med]
    ch("nenhum investimento diário passa de 5 vezes a mediana da campanha", estranhos.empty,
       detalhe="; ".join(f"{x.campanha} em {x.data}: R$ {x.investimento:,.2f}" for x in estranhos.itertuples()))

    dias = pd.Period(mes).days_in_month
    faltam = {c: dias - n for c, n in midia.groupby("canal")["data"].nunique().items() if n < dias}
    ch("todo canal tem todos os dias do mês", not faltam, "alerta",
       ", ".join(f"{c}: faltam {n} dia(s)" for c, n in faltam.items()))
    if anterior:
        inv = midia.groupby("canal")["investimento"].sum()
        grandes = [f"{c} {v / anterior[c]['investimento'] - 1:+.0%}" for c, v in inv.items()
                   if c in anterior and abs(v / anterior[c]["investimento"] - 1) > 0.5]
        ch("nenhum canal mudou o investimento em mais de 50% sobre o mês anterior", not grandes, "alerta",
           ", ".join(grandes))

    for x in r:
        marca = "ok " if x["ok"] else ("XX " if x["tipo"] == "bloqueia" else "!! ")
        print(f"  {marca} {x['frase']}" + (f"  ({x['detalhe']})" if x["detalhe"] and not x["ok"] else ""))
    return r
