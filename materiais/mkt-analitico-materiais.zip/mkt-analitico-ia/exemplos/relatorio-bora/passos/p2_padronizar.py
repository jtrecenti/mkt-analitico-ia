"""Passo 2: aplicar as regras escritas. Cada regra diz quantas linhas mexeu."""
from pathlib import Path

import pandas as pd

def padronizar(midia: pd.DataFrame, vendas: pd.DataFrame, mes: str, pasta: Path):
    log = []
    REGRAS = pasta / "regras"
    # nomes de canal: "Tik Tok" vira "TikTok", e assim por diante
    canais = pd.read_csv(REGRAS / "canais.csv")
    mapa = dict(zip(canais["como_chega"], canais["nome_padrao"]))
    n = int(midia["canal"].isin(mapa).sum())
    midia = midia.assign(canal=midia["canal"].replace(mapa))
    if n:
        log.append(f"{n} linhas de mídia com nome de canal trocado (regras/canais.csv)")

    # linha de mídia repetida conta uma vez
    antes = len(midia)
    midia = midia.drop_duplicates(["data", "canal", "campanha"])
    if antes - len(midia):
        log.append(f"{antes - len(midia)} linhas de mídia repetidas removidas")

    # correções confirmadas com a agência
    corr = pd.read_csv(REGRAS / "correcoes.csv", dtype={"data": str})
    for _, c in corr[corr["data"].str.startswith(mes)].iterrows():
        i = (midia["data"] == c["data"]) & (midia["campanha"] == c["campanha"])
        midia.loc[i, c["coluna"]] = c["valor_correto"]
        log.append(f"{c['coluna']} de {c['campanha']} em {c['data']} corrigido para "
                   f"{c['valor_correto']} (confirmado por {c['quem_confirmou']})")

    # pedido repetido conta uma vez
    antes = len(vendas)
    vendas = vendas.drop_duplicates("pedido_id")
    if antes - len(vendas):
        log.append(f"{antes - len(vendas)} pedidos repetidos removidos")

    # pedido fora do mês do arquivo não entra
    fora = ~vendas["data"].str.startswith(mes)
    if fora.sum():
        log.append(f"{int(fora.sum())} pedidos com data fora de {mes} deixados de fora")
    vendas = vendas[~fora]

    for linha in log or ["nenhuma regra precisou mexer nos dados"]:
        print("  " + linha)
    return midia, vendas, log
