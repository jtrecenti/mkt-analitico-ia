"""Passo 1: ler os dois arquivos do mês, como chegaram, sem mexer em nada."""
from pathlib import Path

import pandas as pd

def ler(mes: str, pasta: Path) -> tuple[pd.DataFrame, pd.DataFrame]:
    brutos = pasta / "dados" / "brutos"
    midia = pd.read_csv(brutos / f"midia_{mes}.csv", dtype={"data": str})
    vendas = pd.read_csv(brutos / f"vendas_{mes}.csv", dtype={"data": str, "pedido_id": str})
    print(f"  mídia: {len(midia)} linhas lidas; vendas: {len(vendas)} linhas lidas")
    return midia, vendas
