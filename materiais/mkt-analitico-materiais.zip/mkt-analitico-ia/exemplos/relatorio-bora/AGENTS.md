# Regras deste projeto (o agente lê antes de qualquer tarefa)

Este projeto faz o relatório mensal de mídia da Bora Bebidas. O pedido da
diretoria está em `dados/briefing_bora.md`; as colunas, em
`dados/dicionario_bora.md`.

## Como rodar

- Um comando refaz o relatório de um mês: `python rodar.py 2026-10`.
- O relatório sai em `saida/relatorio_2026-10.html`. Nunca escreva números no
  relatório à mão: todo número sai dos passos.

## Dados

- Os arquivos que chegam vão para `dados/brutos/` com o nome original e **nunca
  são editados**. Toda correção é um passo escrito ou uma linha em `regras/`.
- Em cada passo, diga quantas linhas entraram, quantas saíram e por quê.
- Nenhum dado pessoal (nome, CPF, e-mail, telefone) entra no projeto.

## Regras de negócio

- Os canais conhecidos são Meta, Google, TikTok, E-mail e Direto. Nome
  diferente só entra se estiver em `regras/canais.csv` (por exemplo, "Tik Tok").
- Linha de mídia repetida (mesmo dia, canal e campanha) conta uma vez.
- Pedido repetido (mesmo `pedido_id`) conta uma vez.
- Pedido com data fora do mês do arquivo não entra no mês, e o relatório diz
  quantos ficaram de fora.
- Investimento fora do padrão (mais de 5 vezes a mediana da campanha no mês) só
  entra depois de confirmado com a agência e registrado em
  `regras/correcoes.csv`, com quem confirmou.
- O canal Direto não tem investimento: não calcule CPA nem ROAS para ele.

## Checagens

- As checagens estão em `passos/p3_checar.py`. Uma checagem que **bloqueia**
  impede o relatório; um **alerta** entra no relatório para alguém olhar.
- Todo erro novo vira uma checagem nova. Antes de confiar nela, quebre o dado de
  propósito e veja a checagem falhar.

## Chaves

- Chaves de API só no `.env`, nunca dentro de um script ou de uma conversa.
