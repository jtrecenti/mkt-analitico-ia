# Relatório mensal de mídia da Bora Bebidas

O projeto do professor para os exercícios 6 a 8. A Bora Bebidas é uma marca
fictícia; os números são simulados.

## Como rodar

```
python rodar.py 2026-09
python rodar.py 2026-10
```

O relatório sai em `saida/relatorio_AAAA-MM.html`. Precisa só de `pandas`.

## O que tem aqui

```
AGENTS.md            as regras, que o agente lê antes de qualquer tarefa
rodar.py             refaz o relatório de um mês, do arquivo bruto ao HTML
dados/brutos/        os arquivos como chegaram, um por mês (nunca editados)
dados/               o dicionário das colunas e o pedido da diretoria
regras/canais.csv    nomes de canal que chegam diferentes ("Tik Tok")
regras/correcoes.csv correções confirmadas com a agência, com quem confirmou
passos/p1_ler.py         lê os dois arquivos do mês
passos/p2_padronizar.py  aplica as regras e diz quantas linhas mexeu
passos/p3_checar.py      as checagens: bloqueiam ou alertam
passos/p4_relatorio.py   a tabela por canal, a comparação e o HTML
saida/               os relatórios gerados
```

## O que outubro ensinou

Sem as regras de outubro (`regras/` vazia), o relatório não sai: o canal
"Tik Tok" é desconhecido e um investimento de R$ 47.757 num dia é 100 vezes o
normal da campanha. Somando o arquivo como chegou, o investimento de outubro
seria R$ 115.632 e o ROAS 2,43 (contra 4,45 em setembro). Com as regras, o
investimento é R$ 66.809 e o ROAS 4,17.
