"""Refaz o relatório de um mês: python rodar.py 2026-10 [--pasta CAMINHO]

A pasta (por padrão, a deste arquivo) precisa ter dados/brutos/ e regras/.
"""
import sys
from pathlib import Path

import pandas as pd

from passos.p1_ler import ler
from passos.p2_padronizar import padronizar
from passos.p3_checar import checar
from passos.p4_relatorio import escrever, resumir


def mes_limpo(mes, pasta):
    m, v = ler(mes, pasta)
    m, v, log = padronizar(m, v, mes, pasta)
    return m, v, log


def main(mes: str, pasta: Path) -> None:
    anterior = str(pd.Period(mes) - 1)
    ant = None
    try:
        print(f"mês anterior ({anterior}), para comparar:")
        ant = resumir(*mes_limpo(anterior, pasta)[:2])
    except FileNotFoundError:
        print("  sem o mês anterior; o relatório sai sem comparação")

    print(f"1/4 ler {mes}");        midia, vendas = ler(mes, pasta)
    print("2/4 padronizar");       midia, vendas, log = padronizar(midia, vendas, mes, pasta)
    print("3/4 checar")
    ch = checar(midia, vendas, mes, None if ant is None else ant.to_dict("index"))
    travas = [x for x in ch if not x["ok"] and x["tipo"] == "bloqueia"]
    if travas:
        print(f"\nRELATÓRIO NÃO GERADO: {len(travas)} checagem(ns) bloqueando. Resolva e rode de novo.")
        sys.exit(1)
    print("4/4 relatório")
    t = resumir(midia, vendas)
    arq = escrever(mes, t, ant, log, ch, pasta)
    tot = t.loc["Total"]
    print(f"  investimento R$ {tot.investimento:,.0f}, {int(tot.pedidos)} pedidos, ROAS {tot.roas:.2f}")
    print(f"  gravado em {arq}")


if __name__ == "__main__":
    args = sys.argv[1:]
    pasta = Path(args[args.index("--pasta") + 1]) if "--pasta" in args else Path(__file__).resolve().parent
    mes = next((a for a in args if a[:2] == "20"), "2026-10")
    main(mes, pasta)
