# Dicionário de dados

## `relatos_estruturados.csv` (aulas de quarta à tarde)

3.442 reclamações contra Azul, LATAM e Gol registradas no consumidor.gov.br
entre 10 de agosto e 21 de setembro de 2024, cujo relato estava público no
site. Cada linha é **uma reclamação**. CSV, separador vírgula, UTF-8.

### Como funciona uma reclamação no consumidor.gov.br

1. O consumidor registra a reclamação, com um relato escrito.
2. A empresa tem até 10 dias para responder, por escrito.
3. Depois da resposta, o consumidor tem até 20 dias para avaliar: diz se a
   reclamação foi resolvida, dá uma nota de 1 a 5 e pode deixar um comentário
   final.

A base reúne só reclamações **avaliadas** com relato público. Por isso as notas
são mais altas que nos dados abertos completos: aqui, 74% deram nota 5.

### Colunas que vieram do site

| coluna | tipo | descrição |
|---|---|---|
| `id_relato` | texto | identificador criado para o curso |
| `empresa` | texto | Azul, LATAM ou Gol |
| `data_reclamacao` | data | dia em que o consumidor registrou a reclamação |
| `data_resposta` | data | dia em que a empresa respondeu |
| `dias_resposta` | inteiro | dias entre a reclamação e a resposta da empresa |
| `uf`, `regiao` | texto | estado e região do consumidor |
| `palavras_reclamacao` | inteiro | tamanho do relato, em palavras |
| `tem_comentario_final` | sim/não | se o consumidor deixou comentário na avaliação |
| `resolvida` | sim/não | avaliação do consumidor: a reclamação foi resolvida? |
| `nota` | inteiro | nota do consumidor para o atendimento, de 1 a 5 |

### Colunas extraídas dos textos com IA

Extraídas pela OpenAI (`gpt-5.6-luna`, saída estruturada) com o dicionário
`exercicios/05-extracao/dicionario_relatos.json`. Comparadas com o Jev, as
respostas coincidem em 77% a 99,8% dos casos, conforme a variável.

| coluna | sai de | tipo | descrição |
|---|---|---|---|
| `problema` | reclamação | categoria | problema principal: cancelamento_ou_alteracao, atraso, bagagem, reembolso, cobranca_ou_taxa, milhas_ou_pontos, embarque_ou_assento, atendimento, outro |
| `pedido` | reclamação | categoria | o que o consumidor pede: reembolso, indenizacao, reacomodacao_ou_remarcacao, credito_ou_milhas, cancelar_cobranca, explicacao_ou_contato, outro_ou_nao_diz |
| `valor_mencionado` | reclamação | categoria com ordem | nao_menciona, ate_500, de_500_a_2000, acima_de_2000 (o maior valor em reais citado) |
| `valor_rs` | reclamação | número | o mesmo valor, em reais (vazio se não menciona) |
| `tom` | reclamação | categoria com ordem | neutro, irritado, muito_irritado |
| `acao_judicial` | reclamação | sim/não | menciona advogado, processo, Procon, Juizado ou Justiça |
| `contato_previo` | reclamação | sim/não | diz que já tentou resolver com a empresa antes |
| `viagem_internacional` | reclamação | sim/não | origem ou destino fora do Brasil |
| `passageiro_vulneravel` | reclamação | sim/não | menciona criança, bebê, idoso, gestante ou pessoa com deficiência |
| `resposta_padrao` | resposta da empresa | sim/não | resposta genérica, que não trata do caso concreto |
| `feedback_elogia` | comentário final | sim/não | o consumidor elogia o atendimento ou a solução (vazio se não houve comentário) |

Os textos não estão na base: têm dados pessoais. O script e o dicionário da
extração estão em `exercicios/05-extracao/` (`extrair.py` e
`dicionario_relatos.json`).

## `reclamacoes_aereas_real.csv` (painel de quinta)

20 mil reclamações finalizadas contra Azul, LATAM e Gol entre outubro de 2025
e setembro de 2026, sorteadas dos dados abertos do consumidor.gov.br. Só as
colunas públicas dos dados abertos, sem texto e sem dados pessoais: local,
sexo e faixa etária do consumidor, data de finalização, tempo de resposta,
empresa, assunto, grupo de problema, problema, canal de compra, se procurou a
empresa antes, se foi respondida, situação, avaliação e nota.

Para baixar outros meses, empresas ou setores: `skills/consumidor-gov/`.
