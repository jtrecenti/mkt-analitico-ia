# O pedido da diretoria de marketing da Bora Bebidas

Todo começo de mês, a diretoria quer **um relatório de uma página** sobre o mês
anterior:

1. Quanto investimos em mídia, quantos pedidos vieram e quanto eles renderam,
   no total e por canal (Meta, Google, TikTok, E-mail e Direto).
2. O custo por pedido (CPA) e o retorno sobre o investimento (ROAS) de cada
   canal.
3. O que mudou em relação ao mês anterior, com as variações em porcentagem.
4. Três frases de leitura: o que foi bem, o que foi mal e o que sugerimos para
   o mês seguinte.

Hoje esse relatório é feito à mão, numa conversa nova a cada mês. Dois meses
seguidos, o número de setembro que apareceu no relatório de outubro não bateu
com o do relatório de setembro, e ninguém soube dizer por quê.
