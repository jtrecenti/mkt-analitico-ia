# Dicionário dos arquivos mensais da Bora Bebidas

A Bora Bebidas é uma marca fictícia de bebidas. Os números são simulados, para
fins didáticos. Todo mês chegam dois arquivos: um da agência de mídia e um do
e-commerce. O nome do arquivo diz o mês: `midia_2026-10.csv` é outubro de 2026.

## midia_AAAA-MM.csv (da agência)

Uma linha por campanha e por dia.

| coluna | o que é | exemplo |
|---|---|---|
| `data` | o dia, no formato AAAA-MM-DD | 2026-10-14 |
| `canal` | a plataforma: Meta, Google, TikTok ou E-mail | Meta |
| `campanha` | o nome da campanha na plataforma | Remarketing site |
| `investimento` | quanto foi gasto no dia, em reais, com ponto decimal | 482.30 |
| `impressoes` | quantas vezes o anúncio apareceu (no e-mail: aberturas) | 21540 |
| `cliques` | quantos cliques o anúncio recebeu | 312 |

## vendas_AAAA-MM.csv (do e-commerce)

Um pedido por linha. Não tem nenhum dado de cliente.

| coluna | o que é | exemplo |
|---|---|---|
| `pedido_id` | o código do pedido; um pedido aparece uma vez só | 202610-00042 |
| `data` | o dia do pedido, no formato AAAA-MM-DD | 2026-10-03 |
| `canal_origem` | de onde veio o cliente: Meta, Google, TikTok, E-mail ou Direto | Google |
| `valor` | o valor do pedido, em reais, com ponto decimal | 96.40 |

`Direto` são os clientes que chegaram sem anúncio (digitaram o endereço da loja).
Esse canal não tem investimento, então não tem custo por pedido nem ROAS.

## As contas do relatório

| indicador | conta |
|---|---|
| CTR | cliques ÷ impressões |
| pedidos | número de linhas de vendas do canal |
| receita | soma do `valor` dos pedidos do canal |
| CPA (custo por pedido) | investimento ÷ pedidos |
| ROAS (retorno sobre o investimento em mídia) | receita ÷ investimento |

No total do mês, a receita inclui todos os canais, inclusive o Direto, e o
investimento é a soma de todos os canais pagos.
