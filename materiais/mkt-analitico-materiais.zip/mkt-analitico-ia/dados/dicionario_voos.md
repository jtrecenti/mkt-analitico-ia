# Dicionário da base `voos_2026.csv`

Base **simulada** para a tarde de quarta: 8.000 voos de janeiro a outubro de
2026, 2.000 de cada companhia (LATAM, Gol, Azul e TAP). Uma linha por voo. O
desfecho é a **nota média** que os passageiros daquele voo deram na pesquisa
enviada depois da viagem (0 a 10).

Os números não são reais. As histórias que estão por trás deles vêm do que os
textos reais mostraram de manhã (avaliações na App Store e sentenças do TJSP).
A base é gerada por `scripts/simular_voos.py`, com semente fixa: quem rodar o
script de novo recebe exatamente os mesmos números.

A TAP só faz voos entre o Brasil e Portugal (Lisboa e Porto). As outras três
fazem só voos domésticos. Por isso preço, distância e número de assentos da TAP
estão numa escala diferente: compare a TAP com ela mesma.

## Colunas

| coluna | descrição |
|---|---|
| `id_voo` | identificador do voo (V00001 a V08000) |
| `empresa` | LATAM, Gol, Azul ou TAP |
| `data` | data do voo (AAAA-MM-DD) |
| `mes` | mês do voo, por extenso |
| `dia_semana` | dia da semana do voo |
| `alta_temporada` | sim em janeiro, julho e feriados emendados; na TAP, também em junho e agosto |
| `origem` | código do aeroporto de partida |
| `destino` | código do aeroporto de chegada |
| `distancia_km` | distância percorrida, em km |
| `faixa_horario` | madrugada, manhã, tarde ou noite (horário de partida) |
| `idade_aeronave_anos` | idade do avião escalado, em anos |
| `preco_medio_rs` | preço médio pago pelos passageiros do voo, em R$ |
| `ocupacao_pct` | % dos assentos vendidos |
| `checkin_app_pct` | % dos passageiros que fizeram check-in pelo aplicativo |
| `passageiros_conexao_pct` | % dos passageiros que seguem viagem em outro voo depois deste |
| `motivo_atraso` | nenhum, clima, manutenção, tráfego aéreo ou malha |
| `atraso_chegada_min` | minutos de atraso na chegada (negativo: chegou antes) |
| `reacomodado` | sim quando o voo original foi cancelado e os passageiros foram para outro |
| `assistencia_oferecida` | sim quando a companhia deu alimentação, hotel ou transporte no atraso |
| `falha_checkin_app_pct` | % de quem tentou check-in pelo aplicativo e não conseguiu |
| `conexoes_perdidas_pct` | % dos passageiros em conexão que perderam o voo seguinte |
| `bagagens_extraviadas_por_mil` | malas que não chegaram junto com o passageiro, por mil passageiros |
| `nota_media` | **nota média da pesquisa pós-voo, de 0 a 10** |
| `respondentes` | quantos passageiros responderam à pesquisa |
| `comentarios_negativos_pct` | % dos comentários abertos da pesquisa classificados como negativos |
| `reclamacoes_7d_por_mil` | reclamações registradas nos 7 dias seguintes ao voo, por mil passageiros |
| `compensacao_paga_rs` | total pago em compensações aos passageiros do voo, em R$ |
