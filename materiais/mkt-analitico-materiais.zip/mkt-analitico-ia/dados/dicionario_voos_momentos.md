# Dicionário da base `voos_2026.csv`, com o momento de cada coluna

Versão do estúdio 3 (spoiler até quarta, 18h). Para os alunos, a versão sem os
momentos está em `dicionario_voos.md`.

Base **simulada** para a tarde de quarta: 8.000 voos de janeiro a outubro de
2026, 2.000 de cada companhia (LATAM, Gol, Azul e TAP). Uma linha por voo. O
desfecho é a **nota média** que os passageiros daquele voo deram na pesquisa
enviada depois da viagem (0 a 10).

Os números não são reais. As histórias que estão por trás deles vêm do que os
textos reais mostraram de manhã (avaliações na App Store e sentenças do TJSP).
A base é gerada por `scripts/simular_voos.py`, com semente fixa: quem rodar o
script de novo recebe exatamente os mesmos números.

A TAP só faz voos entre o Brasil e Portugal (Lisboa e Porto). As outras três
fazem só voos domésticos. Por isso preço, distância e número de assentos da TAP
estão numa escala diferente: compare a TAP com ela mesma.

## Quando cada coluna passa a existir

Antes de usar uma coluna para explicar a nota, pergunte quando ela passa a
existir. A nota nasce quando o passageiro responde à pesquisa, depois do voo.

| momento | o que quer dizer |
|---|---|
| **antes** | já se sabe na hora de vender a passagem ou de montar a escala |
| **durante** | acontece no dia do voo, antes de o passageiro responder à pesquisa |
| **junto** | nasce com a própria pesquisa |
| **depois** | só existe dias depois do voo, e depende do que o passageiro achou |

| coluna | momento | descrição |
|---|---|---|
| `id_voo` | antes | identificador do voo (V00001 a V08000) |
| `empresa` | antes | LATAM, Gol, Azul ou TAP |
| `data` | antes | data do voo (AAAA-MM-DD) |
| `mes` | antes | mês do voo, por extenso |
| `dia_semana` | antes | dia da semana do voo |
| `alta_temporada` | antes | sim em janeiro, julho e feriados emendados; na TAP, também em junho e agosto |
| `origem` | antes | código do aeroporto de partida |
| `destino` | antes | código do aeroporto de chegada |
| `distancia_km` | antes | distância percorrida, em km |
| `faixa_horario` | antes | madrugada, manhã, tarde ou noite (horário de partida) |
| `idade_aeronave_anos` | antes | idade do avião escalado, em anos |
| `preco_medio_rs` | antes | preço médio pago pelos passageiros do voo, em R$ |
| `ocupacao_pct` | antes | % dos assentos vendidos |
| `checkin_app_pct` | antes | % dos passageiros que fizeram check-in pelo aplicativo |
| `passageiros_conexao_pct` | antes | % dos passageiros que seguem viagem em outro voo depois deste |
| `motivo_atraso` | durante | nenhum, clima, manutenção, tráfego aéreo ou malha |
| `atraso_chegada_min` | durante | minutos de atraso na chegada (negativo: chegou antes) |
| `reacomodado` | durante | sim quando o voo original foi cancelado e os passageiros foram para outro |
| `assistencia_oferecida` | durante | sim quando a companhia deu alimentação, hotel ou transporte no atraso |
| `falha_checkin_app_pct` | durante | % de quem tentou check-in pelo aplicativo e não conseguiu |
| `conexoes_perdidas_pct` | durante | % dos passageiros em conexão que perderam o voo seguinte |
| `bagagens_extraviadas_por_mil` | durante | malas que não chegaram junto com o passageiro, por mil passageiros |
| `nota_media` | **desfecho** | nota média da pesquisa pós-voo, de 0 a 10 |
| `respondentes` | junto | quantos passageiros responderam à pesquisa |
| `comentarios_negativos_pct` | junto | % dos comentários abertos da pesquisa classificados como negativos |
| `reclamacoes_7d_por_mil` | depois | reclamações registradas nos 7 dias seguintes ao voo, por mil passageiros |
| `compensacao_paga_rs` | depois | total pago em compensações aos passageiros do voo, em R$ |

## Cuidado

- `comentarios_negativos_pct`, `reclamacoes_7d_por_mil` e `compensacao_paga_rs`
  explicam a nota quase inteira, mas nascem junto com ela ou depois dela. São
  consequência da nota, não causa. Elas não servem para decidir nada antes do
  voo.
- `atraso_chegada_min` e `conexoes_perdidas_pct` andam juntos: quanto mais o
  voo atrasa, mais gente perde a conexão. Olhe as duas antes de concluir qual
  pesa mais.
- Na TAP, a compensação inclui a regra europeia para voos de e para a Europa,
  e por isso os valores são maiores.
