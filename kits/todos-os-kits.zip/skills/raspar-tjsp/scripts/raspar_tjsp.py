"""Raspa sentenças da consulta de julgados de primeiro grau do TJSP (CJPG).

Página: https://esaj.tjsp.jus.br/cjpg/ (pública, sem login e sem captcha).

Uso:
    python raspar_tjsp.py baixar --busca 'voo E atraso E (LATAM OU GOL OU AZUL)' --inicio 01/08/2026 --fim 31/10/2026 --pasta brutos
    python raspar_tjsp.py ler --pasta brutos --saida sentencas.csv

Segue o ciclo do web scraping: a busca é a mesma do formulário do site
(replicar), cada página de resultado é salva em disco antes de qualquer
leitura (bruto primeiro), a leitura vira tabela (parsear) e o script confere
se o número de sentenças lidas bate com o total que o site anunciou (validar).

Boas práticas embutidas:
- uma página por vez, com pausa de 2 segundos: o servidor é público e é de todos;
- se uma página já está na pasta, não baixa de novo (dá para parar e retomar);
- limite de páginas por padrão (20 páginas, 200 sentenças);
- não guarda nada além do que a própria página mostra.

As sentenças trazem nomes das partes. Use para análise e não publique a base
com nomes.
"""
from __future__ import annotations

import argparse
import re
import sys
import time
from pathlib import Path

import pandas as pd
import requests
from bs4 import BeautifulSoup

BASE = "https://esaj.tjsp.jus.br/cjpg"
PAUSA = 2.0
CAMPOS = {"Classe": "classe", "Assunto": "assunto", "Magistrado": "magistrado", "Comarca": "comarca",
          "Foro": "foro", "Vara": "vara", "Data de Disponibilização": "data_disponibilizacao"}


def total_anunciado(html: str) -> int | None:
    texto = re.sub(r"<[^>]+>", " ", html)  # o total vem com tags no meio: Resultados <strong>1 a 10</strong> de ...
    m = re.search(r"Resultados\s+\d+\s+a\s+\d+\s+de\s+(\d+)", texto)
    return int(m.group(1)) if m else None


def baixar(busca: str, inicio: str, fim: str, pasta: Path, max_paginas: int) -> None:
    pasta.mkdir(parents=True, exist_ok=True)
    s = requests.Session()
    # 1) a busca: TODOS os campos que o formulário do site envia, mesmo os vazios.
    #    Sem os vazios, o site responde 200 mas sem nenhum resultado.
    params = {"conversationId": "", "dadosConsulta.pesquisaLivre": busca, "tipoNumero": "UNIFICADO",
              "numeroDigitoAnoUnificado": "", "foroNumeroUnificado": "", "dadosConsulta.nuProcesso": "",
              "dadosConsulta.nuProcessoAntigo": "", "classeTreeSelection.values": "", "assuntoTreeSelection.values": "",
              "dadosConsulta.dtInicio": inicio, "dadosConsulta.dtFim": fim, "varasTreeSelection.values": "",
              "dadosConsulta.ordenacao": "DESC"}
    r = s.get(f"{BASE}/pesquisar.do", params=params, timeout=60)
    r.raise_for_status()
    total = total_anunciado(r.text)
    if total is None:
        sys.exit("A página não trouxe resultados. Confira a busca no site antes de rodar de novo.")
    paginas = min(max_paginas, -(-total // 10))
    print(f"O site anuncia {total} sentenças ({-(-total // 10)} páginas). Vou baixar {paginas}.")
    (pasta / "pagina_001.html").write_text(r.text, encoding="utf-8")
    # 2) as outras páginas: o site guarda a busca na sessão e só pede o número da página
    for p in range(2, paginas + 1):
        arq = pasta / f"pagina_{p:03d}.html"
        if arq.exists():
            continue
        time.sleep(PAUSA)
        r = s.get(f"{BASE}/trocarDePagina.do", params={"pagina": p, "conversationId": ""}, timeout=60)
        if r.status_code != 200:
            print(f"página {p}: erro {r.status_code}. Parei aqui; rode de novo para retomar.")
            break
        arq.write_text(r.text, encoding="utf-8")
        print(f"página {p}/{paginas} salva")
    (pasta / "busca.txt").write_text(f"busca: {busca}\ninicio: {inicio}\nfim: {fim}\ntotal anunciado: {total}\n", encoding="utf-8")


def ler_pagina(html: str) -> list[dict]:
    soup = BeautifulSoup(html, "html.parser")
    linhas = []
    for caso in soup.select("tr.fundocinza1"):
        d = {"processo": caso.select_one("span.fonteNegrito").get_text(strip=True)}
        for td in caso.select("tr.fonte td"):
            rotulo = td.find("strong")
            if rotulo:
                chave = rotulo.get_text(strip=True).rstrip(":")
                if chave in CAMPOS:
                    d[CAMPOS[chave]] = td.get_text(" ", strip=True).split(":", 1)[1].strip()
        # o inteiro teor vem na própria lista, num bloco escondido (display: none)
        escondido = caso.select_one("div[style*='display: none']")
        if escondido:
            for em in escondido.find_all("em"):  # destaques da busca: tira a tag, fica a palavra
                em.unwrap()
            texto = re.sub(r"[ \t]+", " ", escondido.get_text())
            d["texto"] = re.sub(r"\s*\n\s*\n\s*", "\n\n", texto).strip()
        else:
            d["texto"] = ""
        linhas.append(d)
    return linhas


def ler(pasta: Path, saida: Path) -> None:
    arquivos = sorted(pasta.glob("pagina_*.html"))
    linhas = [l for a in arquivos for l in ler_pagina(a.read_text(encoding="utf-8"))]
    df = pd.DataFrame(linhas)
    total = total_anunciado(arquivos[0].read_text(encoding="utf-8")) if arquivos else None
    repetidas = int(df.duplicated("processo").sum())
    df = df.drop_duplicates("processo")
    df["palavras"] = df["texto"].str.split().str.len()
    df.to_csv(saida, index=False, encoding="utf-8-sig")
    # validar: o que lemos bate com o que o site disse?
    print(f"{len(arquivos)} páginas lidas, {len(df)} sentenças em {saida.name} ({repetidas} repetidas removidas).")
    print(f"O site anunciou {total}. Sem texto: {int((df['texto'] == '').sum())}.")
    if total and len(df) + repetidas < min(total, len(arquivos) * 10):
        print("Atenção: li menos sentenças do que as páginas deveriam ter.")


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("modo", choices=["baixar", "ler"])
    p.add_argument("--busca", default="voo E atraso E (LATAM OU GOL OU AZUL)")
    p.add_argument("--inicio", default="01/08/2026")
    p.add_argument("--fim", default="31/10/2026")
    p.add_argument("--pasta", type=Path, default=Path("brutos"))
    p.add_argument("--max-paginas", type=int, default=20)
    p.add_argument("--saida", type=Path, default=Path("sentencas.csv"))
    a = p.parse_args()
    if a.modo == "baixar":
        baixar(a.busca, a.inicio, a.fim, a.pasta, a.max_paginas)
    else:
        ler(a.pasta, a.saida)


if __name__ == "__main__":
    main()
