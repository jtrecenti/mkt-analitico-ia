---
name: raspar-tjsp
description: Baixa sentenças da Consulta de Julgados de 1º Grau do TJSP (esaj.tjsp.jus.br/cjpg) para uma busca e um período, salva as páginas brutas e monta um CSV com o texto inteiro de cada sentença. Use quando pedirem sentenças, decisões ou julgados de primeiro grau do TJSP sobre um tema.
---

# Raspar sentenças do TJSP

## Como usar

1. Combine a busca e o período. A pesquisa livre aceita `E`, `OU`, `NAO`,
   aspas e parênteses. Mostre a busca antes de rodar: sem parênteses,
   `A E B OU C` não significa o que parece.
2. Baixe as páginas (salvas em disco antes de qualquer leitura):

   ```bash
   python scripts/raspar_tjsp.py baixar --busca "voo E atraso E (LATAM OU GOL OU AZUL)" --inicio 01/08/2026 --fim 31/10/2026 --pasta brutos --max-paginas 3
   ```

   Comece com 3 páginas, mostre o resultado e só então aumente
   `--max-paginas`. Se parar no meio, rode de novo: ele continua.
3. Leia as páginas e monte a tabela:

   ```bash
   python scripts/raspar_tjsp.py ler --pasta brutos --saida sentencas.csv
   ```

4. Responda com o que o script imprimiu: quantas sentenças o site anunciou,
   quantas foram lidas, quantas sem texto. Se não bater, diga.

## Regras

- Uma página por vez, com pausa. Nunca rode em paralelo.
- Não mostre nomes de partes na conversa sem necessidade, e não publique a
  base com nomes.
- Se a página mudar e o script não achar resultados, abra a página, refaça a
  busca e compare a requisição do navegador com a do script antes de mexer no
  código.
