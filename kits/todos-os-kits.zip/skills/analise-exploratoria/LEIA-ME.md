# Skill analise-exploratoria

**O que faz:** o primeiro relatório de qualquer base: o que ela tem, o tipo de
cada coluna, vazios, duplicatas, outliers, categorias mais frequentes,
correlações, gráficos e 5 perguntas para investigar. Sai em HTML e Markdown.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip. Ou, numa conversa no modo Work: "crie esta habilidade a partir deste
zip".

**Como adaptar:** em `scripts/explorar.py`, ajuste as regras de tipo (por
exemplo, nomes de coluna que na sua empresa são sempre códigos) e o limite de
gráficos (`--max-graficos`).

**Pedido de exemplo:** "Recebi a base de clientes do CRM em `crm.xlsx`. Faça a
análise exploratória com a habilidade analise-exploratoria e me diga o que
pode atrapalhar uma análise de recompra."
