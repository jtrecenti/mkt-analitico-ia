---
name: analise-exploratoria
description: Faz a análise exploratória de uma planilha (CSV ou Excel) num relatório HTML e Markdown, com dimensões, tipo sugerido de cada coluna, vazios, duplicatas, resumo das numéricas com outliers, categorias mais frequentes, período das datas, correlações mais fortes, gráficos com boas práticas e 5 perguntas sugeridas para investigar. Use quando o usuário enviar uma base nova e pedir para explorar, entender, descrever, fazer um raio-x ou um primeiro relatório antes de qualquer análise.
---

# Análise exploratória

**O script conta; você interpreta.** Nenhum número do relatório sai da sua
cabeça: todos vêm do script.

Precisa de `pandas`, `matplotlib` e `openpyxl` para Excel
(`pip install pandas matplotlib openpyxl`).

## Passo 1: rodar

```bash
python scripts/explorar.py DADOS.csv --saida exploratorio.html
```

Sai `exploratorio.html` (um arquivo só, com os gráficos dentro) e
`exploratorio.md`. A tela mostra linhas, colunas, duplicatas e as 5 perguntas.

## Passo 2: interpretar para o usuário

Em linguagem simples, nesta ordem:

1. **O que é cada linha** (um voo, um cliente, um pedido, um dia).
2. **O tipo de cada variável.** O script sugere; você confirma. Ele não sabe
   se uma categoria tem ordem (faixa etária, nota de 1 a 5): decida e diga.
   Coluna marcada como "identificador ou texto livre" não entra em média.
3. **O que pode estragar uma conta**: linhas repetidas, vazios que mudam o
   total, outliers que podem ser erro de registro, número guardado como texto.
4. **As 5 perguntas.** Reescreva na linguagem do negócio do usuário. Correlação
   não é causa: diga isso quando falar das colunas que andam juntas.
5. **Um próximo passo**: o gráfico ou a comparação que responde à pergunta mais
   útil.

## Regras

- Não corrija a base sem avisar. Primeiro mostre o problema; corrija só se o
  usuário pedir, gerando um arquivo novo.
- Nenhum dado pessoal no relatório. Se houver coluna de nome, e-mail, CPF ou
  telefone, avise e tire antes de compartilhar.
- Para gráficos de apresentação, use a habilidade graficos-executivos.
