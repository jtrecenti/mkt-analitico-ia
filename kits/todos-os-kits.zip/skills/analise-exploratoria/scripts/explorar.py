"""Relatório exploratório de uma base: o que ela tem, o que está estranho e o que investigar.

Uso: python explorar.py DADOS.csv [--saida exploratorio.html] [--max-graficos 8]

Lê CSV ou Excel. Conta linhas, colunas, vazios e duplicatas; sugere o tipo de
cada coluna; resume numéricas (com outliers pela regra do intervalo
interquartil), categóricas (as mais frequentes) e datas (período); lista as
correlações mais fortes; desenha os gráficos com as boas práticas executivas; e
sugere 5 perguntas para investigar, a partir do que os números mostram.
O relatório sai em HTML (um arquivo só, com as imagens dentro) e em Markdown.
"""
from __future__ import annotations

import argparse
import base64
import html
import io
import warnings
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

DESTAQUE, CINZA = "#c8102e", "#b9bcc2"
warnings.simplefilter("ignore")


def ler(arq: Path) -> pd.DataFrame:
    return pd.read_excel(arq) if arq.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(arq, low_memory=False)


def tipo(s: pd.Series) -> str:
    nome = str(s.name).lower()
    if nome == "id" or nome.startswith("id_") or nome.endswith("_id") or "codigo" in nome:
        return "identificador ou texto livre"
    if pd.api.types.is_numeric_dtype(s) and s.nunique() > 0.95 * len(s.dropna()) and (s.dropna() % 1 == 0).all() and len(s) > 50:
        return "identificador ou texto livre"
    if pd.api.types.is_numeric_dtype(s):
        if s.dropna().isin([0, 1]).all():
            return "categórica (sim/não)"
        return "numérica discreta" if (s.dropna() % 1 == 0).all() and s.nunique() < 30 else (
            "numérica discreta" if (s.dropna() % 1 == 0).all() else "numérica contínua")
    if pd.to_datetime(s, errors="coerce").notna().mean() > 0.9:
        return "data"
    if s.nunique() > 0.9 * len(s.dropna()) and s.nunique() > 50:
        return "identificador ou texto livre"
    return "categórica"


def png(fig) -> str:
    b = io.BytesIO()
    fig.savefig(b, format="png", dpi=100, bbox_inches="tight")
    plt.close(fig)
    return base64.b64encode(b.getvalue()).decode()


def _ax(titulo):
    plt.rcParams.update({"font.size": 14})
    fig, ax = plt.subplots(figsize=(9, 4.5))
    for lado in ("top", "right", "left"):
        ax.spines[lado].set_visible(False)
    ax.set_title(titulo, loc="left", fontsize=16, fontweight="bold")
    return fig, ax


def hist(s: pd.Series, nome: str) -> str:
    fig, ax = _ax(f"{nome}: mediana {s.median():,.2f}".replace(",", "X").replace(".", ",").replace("X", "."))
    ax.hist(s.dropna(), bins=30, color=CINZA, edgecolor="white")
    ax.axvline(s.median(), color=DESTAQUE, linewidth=3)
    ax.yaxis.set_visible(False)
    return png(fig)


def barras(v: pd.Series, nome: str) -> str:
    v = v.sort_values()
    fig, ax = _ax(f"{nome}: a mais frequente é {v.index[-1]} ({v.iloc[-1] / v.sum():.0%})")
    ax.barh([str(i)[:30] for i in v.index], v.values, color=[CINZA] * (len(v) - 1) + [DESTAQUE])
    for i, x in enumerate(v.values):
        ax.text(x, i, f" {x:,}".replace(",", "."), va="center")
    ax.xaxis.set_visible(False)
    return png(fig)


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("dados", type=Path)
    p.add_argument("--saida", type=Path, default=Path("exploratorio.html"))
    p.add_argument("--max-graficos", type=int, default=8)
    a = p.parse_args()
    d = ler(a.dados)
    n, k = d.shape
    tipos = {c: tipo(d[c]) for c in d.columns}
    dup = int(d.duplicated().sum())
    vaz = d.isna().mean().sort_values(ascending=False)
    num = [c for c, t in tipos.items() if t.startswith("numérica")]
    cat = [c for c, t in tipos.items() if t.startswith("categórica")]
    dat = [c for c, t in tipos.items() if t == "data"]

    md = [f"# Exploratório de {a.dados.name}", "",
          f"- {n:,} linhas e {k} colunas; {dup:,} linhas repetidas por inteiro.".replace(",", "."),
          f"- Colunas com vazios: {int((vaz > 0).sum())} de {k}." , ""]
    md += ["## Colunas", "", "| coluna | tipo sugerido | vazios | valores diferentes |", "|---|---|---|---|"]
    md += [f"| {c} | {tipos[c]} | {d[c].isna().mean():.0%} | {d[c].nunique():,} |".replace(",", ".") for c in d.columns]

    graficos, perguntas, outs = [], [], []
    if num:
        md += ["", "## Numéricas", "", "| coluna | mínimo | mediana | média | máximo | outliers |", "|---|---|---|---|---|---|"]
        for c in num:
            s = d[c].dropna()
            q1, q3 = s.quantile([0.25, 0.75])
            out = int(((s < q1 - 1.5 * (q3 - q1)) | (s > q3 + 1.5 * (q3 - q1))).sum())
            md.append(f"| {c} | {s.min():.2f} | {s.median():.2f} | {s.mean():.2f} | {s.max():.2f} | {out} ({out / max(len(s), 1):.0%}) |")
            if out / max(len(s), 1) > 0.05:
                outs.append((out / len(s), c, out))
    if cat:
        md += ["", "## Categóricas (as 5 mais frequentes)", ""]
        for c in cat:
            top = d[c].value_counts().head(5)
            md.append(f"- **{c}**: " + "; ".join(f"{i} ({v / n:.0%})" for i, v in top.items()))
    if dat:
        md += ["", "## Datas", ""]
        for c in dat:
            s = pd.to_datetime(d[c], errors="coerce")
            md.append(f"- **{c}**: de {s.min():%d/%m/%Y} a {s.max():%d/%m/%Y}")
            perguntas.append(f"Os números mudam ao longo do tempo em {c}? Vale uma linha no tempo da principal métrica.")

    pares = []
    if len(num) > 1:
        cor = d[num].corr()
        for i, x in enumerate(num):
            for y in num[i + 1:]:
                if pd.notna(cor.loc[x, y]):
                    pares.append((abs(cor.loc[x, y]), cor.loc[x, y], x, y))
        pares.sort(reverse=True)
        md += ["", "## Correlações mais fortes", ""]
        md += [f"- {x} e {y}: {r:+.2f}" for _, r, x, y in pares[:6]]
        for _, r, x, y in pares[:2]:
            perguntas.append(f"{x} e {y} andam juntas (correlação {r:+.2f}".replace(".", ",") + "): uma explica a outra, ou as duas vêm de uma terceira coisa?")
    if cat and num:
        cand = [(d.groupby(c)[y].mean().std() / (d[y].std() or 1), c, y) for c in cat if 2 <= d[c].nunique() <= 30 for y in num]
        if cand:
            _, melhor, alvo = max(cand)
            m = d.groupby(melhor)[alvo].mean().sort_values()
            f = lambda x: f"{x:,.2f}".replace(",", "X").replace(".", ",").replace("X", ".")
            perguntas.insert(0, f"A média de {alvo} vai de {f(m.iloc[0])} ({m.index[0]}) a {f(m.iloc[-1])} ({m.index[-1]}) conforme {melhor}: a diferença continua quando se compara casos parecidos?")
    if outs:
        f, c, o = max(outs)
        perguntas.append(f"{c} tem {o} valores fora do padrão ({f:.0%}): são erros de registro ou casos reais que merecem um olhar à parte?")
    if dup:
        perguntas.append(f"Há {dup} linhas repetidas por inteiro: são registros duplicados que precisam sair antes de qualquer soma?")
    if (vaz > 0.2).any():
        c = vaz.index[0]
        perguntas.append(f"{c} está vazia em {vaz.iloc[0]:.0%} das linhas: o vazio quer dizer zero, não se aplica ou falha na coleta?")
    perguntas = (perguntas + ["Qual decisão esta base ajuda a tomar? Escreva a pergunta do negócio antes de cruzar colunas."])[:5]
    md += ["", "## 5 perguntas para investigar", ""] + [f"{i}. {q}" for i, q in enumerate(perguntas, 1)]

    for c in num[: a.max_graficos // 2]:
        graficos.append((c, hist(d[c], c)))
    for c in [c for c in cat if d[c].nunique() <= 40][: a.max_graficos - len(graficos)]:
        graficos.append((c, barras(d[c].value_counts().head(8), c)))

    texto = "\n".join(md)
    a.saida.with_suffix(".md").write_text(texto, encoding="utf-8")
    corpo = ""
    for linha in md:
        if linha.startswith("# "):
            corpo += f"<h1>{html.escape(linha[2:])}</h1>"
        elif linha.startswith("## "):
            corpo += f"<h2>{html.escape(linha[3:])}</h2>"
        elif linha.startswith("|---"):
            continue
        elif linha.startswith("| "):
            cel = [c.strip() for c in linha.strip("|").split("|")]
            corpo += "<tr>" + "".join(f"<td>{html.escape(c)}</td>" for c in cel) + "</tr>"
        elif linha:
            corpo += f"<p>{html.escape(linha).replace('**', '')}</p>"
    corpo = corpo.replace("</h2><tr>", "</h2><table><tr>").replace("</tr><h2>", "</tr></table><h2>").replace("</tr><p>", "</tr></table><p>")
    imgs = "".join(f'<figure><img src="data:image/png;base64,{b}" alt="{html.escape(c)}"></figure>' for c, b in graficos)
    a.saida.write_text(f"""<!doctype html><html lang="pt-BR"><meta charset="utf-8"><title>Exploratório</title>
<style>body{{font-family:system-ui,sans-serif;max-width:980px;margin:2rem auto;padding:0 1rem;color:#1d1d1f}}
table{{border-collapse:collapse;width:100%;font-size:.9rem}}td{{border-bottom:1px solid #ddd;padding:.3rem .5rem}}
img{{max-width:100%}}figure{{margin:1rem 0}}</style>{corpo}<h2>Gráficos</h2>{imgs}</html>""", encoding="utf-8")
    print(f"{n} linhas, {k} colunas, {dup} repetidas; {len(num)} numéricas, {len(cat)} categóricas, {len(dat)} datas")
    print(f"gravado: {a.saida} e {a.saida.with_suffix('.md')}")
    print("\n".join(f"  pergunta {i}: {q}" for i, q in enumerate(perguntas, 1)))


if __name__ == "__main__":
    main()
