"""Padroniza um cadastro de clientes ou parceiros, sem sobrescrever o original.

Uso:
    python limpar_cadastro.py cadastro.csv --saida cadastro_limpo.csv
    python limpar_cadastro.py cadastro.xlsx --saida limpo.csv --colunas cnpj=documento,cep=cep_loja
    python limpar_cadastro.py --exemplo cadastro_exemplo.csv   (gera um cadastro fictício para testar)

O que faz, coluna a coluna (reconhece os nomes comuns; use --colunas para dizer
qual coluna é qual):
- documento (CNPJ ou CPF): tira a pontuação, devolve os zeros que o Excel come,
  confere o dígito verificador e diz se é CNPJ, CPF ou inválido;
- cep: 8 dígitos, com hífen; inválido se não tiver 8 dígitos;
- telefone: só dígitos, com DDD; marca fixo, celular ou inválido;
- email: minúsculas, sem espaços; inválido se não tiver o formato;
- uf: sigla em maiúsculas, conferida contra a lista das 27;
- nome: espaços extras fora e caixa de título ("MARIA  DA SILVA" vira "Maria da Silva").

Depois aponta duplicatas prováveis: mesmo documento, mesmo e-mail ou mesmo
telefone. Grava o arquivo limpo com colunas novas (`_limpo`, `_status`) ao lado
das originais e imprime só contagens e exemplos mascarados: nenhum dado pessoal
inteiro aparece na tela.
"""
from __future__ import annotations

import argparse
import re
import sys
from pathlib import Path

import pandas as pd

UFS = set("AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO".split())
NOMES = {
    "documento": ["cnpj", "cpf", "documento", "doc", "cpf_cnpj", "cnpj_cpf"],
    "cep": ["cep", "cep_cadastro", "codigo_postal"],
    "telefone": ["telefone", "fone", "celular", "whatsapp", "tel", "telefone_cadastro"],
    "email": ["email", "e-mail", "e_mail", "mail"],
    "uf": ["uf", "estado", "sigla_uf"],
    "nome": ["nome", "razao_social", "nome_fantasia", "cliente", "parceiro"],
}
MINUSCULAS = {"da", "de", "do", "das", "dos", "e"}


def so_digitos(x) -> str:
    return re.sub(r"\D", "", str(x)) if pd.notna(x) else ""


def dv_ok(d: str, pesos: list[list[int]]) -> bool:
    for p in pesos:
        n = len(p)
        s = sum(int(a) * b for a, b in zip(d[:n], p)) % 11
        if int(d[n]) != (0 if s < 2 else 11 - s):
            return False
    return True


def documento(x) -> tuple[str, str]:
    d = so_digitos(x)
    if not d:
        return "", "vazio"
    if len(d) <= 11 and len(d) != 11 and len(d) > 8:
        d = d.zfill(11)
    if 11 < len(d) < 14:
        d = d.zfill(14)
    if len(d) == 11 and len(set(d)) > 1 and dv_ok(d, [list(range(10, 1, -1)), list(range(11, 1, -1))]):
        return f"{d[:3]}.{d[3:6]}.{d[6:9]}-{d[9:]}", "CPF"
    if len(d) == 14 and len(set(d)) > 1 and dv_ok(d, [[5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2], [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]]):
        return f"{d[:2]}.{d[2:5]}.{d[5:8]}/{d[8:12]}-{d[12:]}", "CNPJ"
    return d, "inválido"


def cep(x) -> tuple[str, str]:
    d = so_digitos(x)
    if not d:
        return "", "vazio"
    if 5 <= len(d) < 8:
        d = d.zfill(8)
    return (f"{d[:5]}-{d[5:]}", "ok") if len(d) == 8 else (d, "inválido")


def telefone(x) -> tuple[str, str]:
    d = so_digitos(x)
    if not d:
        return "", "vazio"
    if d.startswith("55") and len(d) in (12, 13):
        d = d[2:]
    d = d.lstrip("0")
    if len(d) == 11 and d[2] == "9":
        return f"({d[:2]}) {d[2:7]}-{d[7:]}", "celular"
    if len(d) == 10:
        return f"({d[:2]}) {d[2:6]}-{d[6:]}", "fixo"
    return d, "inválido"


def email(x) -> tuple[str, str]:
    if pd.isna(x) or not str(x).strip():
        return "", "vazio"
    e = str(x).strip().lower().replace(" ", "")
    return (e, "ok") if re.fullmatch(r"[\w.+-]+@[\w-]+(\.[\w-]+)+", e) else (e, "inválido")


def uf(x) -> tuple[str, str]:
    if pd.isna(x) or not str(x).strip():
        return "", "vazio"
    u = str(x).strip().upper()
    return (u, "ok") if u in UFS else (u, "inválido")


def nome(x) -> tuple[str, str]:
    if pd.isna(x) or not str(x).strip():
        return "", "vazio"
    partes = re.sub(r"\s+", " ", str(x).strip()).split(" ")
    n = " ".join(p.lower() if p.lower() in MINUSCULAS and i else p.capitalize() for i, p in enumerate(partes))
    return n, "ok" if n == str(x) else "ajustado"


FUNCOES = {"documento": documento, "cep": cep, "telefone": telefone, "email": email, "uf": uf, "nome": nome}


def mascarar(v: str) -> str:
    v = str(v)
    if "@" in v:
        a, b = v.split("@", 1)
        return a[:1] + "***@" + b
    return v[:3] + "*" * max(0, len(v) - 5) + v[-2:] if len(v) > 5 else "***"


def ler(arq: Path) -> pd.DataFrame:
    if arq.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(arq, dtype=str)
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(arq, dtype=str, sep=None, engine="python", encoding=enc)
        except UnicodeDecodeError:
            continue
    raise SystemExit(f"não consegui ler {arq}")


def exemplo(destino: Path) -> None:
    linhas = [
        ("AGÊNCIA  SOL  E MAR", "10760260000119", "1310100", "11 98765-4321", " Contato@SolEMar.com.br", "sp"),
        ("agência sol e mar ltda", "10.760.260/0001-19", "01310-100", "(11)98765-4321", "contato@solemar.com.br", "SP"),
        ("Viagens do Norte", "123", "6900000", "92 3232 1010", "norte@viagens", "AM"),
        ("MARIA DA SILVA TURISMO", "52998224725", "30130010", "31987654321", "maria@turismo.com", "MG"),
        ("Rota Sul", "11222333000181", "90010-000", "5551999990000", "rota@sul.com.br", "XX"),
    ]
    pd.DataFrame(linhas, columns=["nome", "cnpj", "cep", "telefone", "email", "uf"]).to_csv(destino, index=False)
    print(f"cadastro fictício com {len(linhas)} linhas em {destino}")


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("arquivo", nargs="?", type=Path)
    p.add_argument("--saida", type=Path)
    p.add_argument("--colunas", default="", help="tipo=coluna,tipo=coluna (tipos: documento, cep, telefone, email, uf, nome)")
    p.add_argument("--exemplo", type=Path, help="gera um cadastro fictício neste arquivo e sai")
    a = p.parse_args()
    if a.exemplo:
        exemplo(a.exemplo)
        return
    if not a.arquivo:
        p.error("informe o arquivo do cadastro")
    df = ler(a.arquivo)
    saida = a.saida or a.arquivo.with_name(a.arquivo.stem + "_limpo.csv")
    if saida.resolve() == a.arquivo.resolve():
        raise SystemExit("a saída não pode ser o arquivo original")
    mapa = dict(x.split("=", 1) for x in a.colunas.split(",") if "=" in x)
    baixo = {c.lower().strip(): c for c in df.columns}
    for tipo, nomes in NOMES.items():
        if tipo not in mapa:
            achou = next((baixo[n] for n in nomes if n in baixo), None)
            if achou:
                mapa[tipo] = achou
    print(f"{len(df)} linhas lidas de {a.arquivo.name}; colunas reconhecidas: "
          + ", ".join(f"{t} = {c}" for t, c in mapa.items()))
    print()
    for tipo, col in mapa.items():
        res = df[col].map(FUNCOES[tipo])
        df[f"{col}_limpo"] = res.str[0]
        df[f"{col}_status"] = res.str[1]
        cont = df[f"{col}_status"].value_counts()
        mudou = int((df[col].fillna("").astype(str) != df[f"{col}_limpo"]).sum())
        print(f"{tipo} ({col}): {mudou} valores mudaram; " + ", ".join(f"{k}: {v}" for k, v in cont.items()))
        ex = df[df[f"{col}_status"] == "inválido"][f"{col}_limpo"].head(2).map(mascarar).tolist()
        if ex:
            print(f"   exemplos de inválidos (mascarados): {ex}")
    # duplicatas prováveis
    print()
    df["grupo_duplicata"] = ""
    for tipo in ("documento", "email", "telefone"):
        if tipo not in mapa:
            continue
        col = f"{mapa[tipo]}_limpo"
        validos = df[(df[f"{mapa[tipo]}_status"] != "inválido") & (df[col] != "")]
        rep = validos[validos.duplicated(col, keep=False)]
        for i, (_, g) in enumerate(rep.groupby(col)):
            for ix in g.index:
                df.loc[ix, "grupo_duplicata"] = (df.loc[ix, "grupo_duplicata"] + f" {tipo}{i + 1}").strip()
        print(f"duplicatas pelo {tipo}: {rep[col].nunique()} grupo(s), {len(rep)} linhas")
    df.to_csv(saida, index=False, encoding="utf-8-sig")
    print(f"\n{len(df)} linhas gravadas em {saida} (o original não foi alterado)")


if __name__ == "__main__":
    main()
