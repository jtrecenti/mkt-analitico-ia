---
name: limpar-cadastro
description: Padroniza um cadastro de clientes, lojas ou parceiros (CNPJ e CPF com dígito verificador, CEP, telefone, e-mail, UF e nome), aponta duplicatas prováveis e grava um arquivo novo, sem tocar no original e sem mostrar dados pessoais no chat. Use quando pedirem para limpar, padronizar, conferir ou deduplicar um cadastro, uma lista de clientes, de parceiros ou de lojas.
---

# Limpar um cadastro

**O script padroniza e conta; você explica o que mudou.** Nunca corrija um
documento, telefone ou e-mail "de olho": o script segue sempre a mesma regra.

## Passo 1: reconhecer as colunas

Mostre ao usuário só os **nomes das colunas** e quantas linhas o arquivo tem
(nunca os valores). O script reconhece nomes comuns (`cnpj`, `cpf`, `cep`,
`telefone`, `email`, `uf`, `nome`, `razao_social`...). Se os nomes forem
outros, combine com o usuário e passe `--colunas tipo=coluna`.

## Passo 2: rodar

```bash
python scripts/limpar_cadastro.py ARQUIVO --saida ARQUIVO_limpo.csv
python scripts/limpar_cadastro.py ARQUIVO --saida limpo.csv --colunas documento=cpf_cnpj,telefone=celular
```

Para testar sem dados reais: `python scripts/limpar_cadastro.py --exemplo exemplo.csv`.

## Passo 3: explicar

Responda com os números que o script imprimiu, sem mudar nenhum:

1. Quantas linhas entraram e quantas saíram (devem ser as mesmas: nada é apagado).
2. Para cada coluna: quantos valores mudaram e quantos ficaram inválidos.
3. As duplicatas prováveis (por documento, e-mail ou telefone) e o que fazer
   com elas: **perguntar** antes de juntar qualquer registro.
4. O que o usuário precisa conferir na fonte (documentos inválidos, CEPs sem 8
   dígitos).

## Regras

- O arquivo original nunca é sobrescrito. As colunas novas (`_limpo`,
  `_status`, `grupo_duplicata`) ficam ao lado das originais.
- **Dados pessoais não aparecem no chat**: só contagens e os exemplos
  mascarados que o script mostra. Não abra o arquivo para "dar uma olhada" nas
  linhas.
- Não apague duplicatas sozinho: marque e pergunte.
- Use só em ferramentas que a empresa aprovou para dados de clientes.
