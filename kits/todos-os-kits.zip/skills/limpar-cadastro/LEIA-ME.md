# Skill limpar-cadastro

**O que faz:** padroniza um cadastro (CNPJ e CPF com dígito verificador, CEP,
telefone, e-mail, UF e nome), aponta duplicatas prováveis e grava um arquivo
novo com o status de cada campo. O original não é tocado e o chat só vê
contagens e exemplos mascarados.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip (ou a pasta `limpar-cadastro`, com o `SKILL.md` e a pasta `scripts`).

**Pedido de exemplo:**

> Use a habilidade limpar-cadastro na planilha lojas_parceiras.xlsx. Me diga
> quantos CNPJs são inválidos, quantos telefones não têm DDD e quais lojas
> parecem duplicadas. Não junte nada sem me perguntar.

**Como adaptar:**

- Outras colunas: acrescente um tipo em `NOMES` e uma função em `FUNCOES`, em
  `scripts/limpar_cadastro.py` (por exemplo, padronizar o nome da cidade).
- Outra regra de duplicata: o bloco "duplicatas prováveis" no fim do script
  (por exemplo, mesmo nome e mesmo CEP).
- Teste sem dado real: `python scripts/limpar_cadastro.py --exemplo exemplo.csv`.

**Cuidado:** cadastro de cliente é dado pessoal. Use só em ferramenta que a
empresa aprovou.
