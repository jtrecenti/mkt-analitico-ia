---
name: monitor-avaliacoes-app
description: Acompanha todo dia as avaliações de aplicativos na App Store do Brasil (por padrão LATAM, GOL, Azul e TAP), junta a coleta de hoje com as anteriores sem contar repetidas, roda checagens de consistência, classifica o tema de cada avaliação com IA (o Jev) e gera um relatório HTML reprodutível em Quarto, com gráficos do ECharts. Use quando pedirem para atualizar o monitor de avaliações, ver o que mudou nas avaliações de um app desde a última coleta ou gerar o relatório do monitor.
---

# Monitor de avaliações de aplicativos

Todo dia, a mesma receita: os mesmos passos, as mesmas regras e as mesmas
checagens. **O script conta; você lê e escreve o resumo.** Nunca refaça as
contas de cabeça nem escreva um número que não saiu do script.

## Passo 1: a pasta

A pasta de trabalho precisa ter `dados/coletas/`, com as coletas anteriores
(uma por dia, `avaliacoes_AAAA-MM-DD.csv`). Na primeira rodada, o script copia
do `modelo/` desta skill o que faltar: `relatorio.qmd`, `regras/apps.csv` (os
aplicativos), `regras/dicionario.json` (as perguntas para a IA) e
`regras/estilo.css`. Ele nunca sobrescreve um arquivo que já existe. Nunca
edite um arquivo de `dados/coletas/`.

Para outros aplicativos, edite `regras/apps.csv` com o nome e o número da App
Store (o `id1497908631` do endereço do app). Para outros temas, edite as opções
de `regras/dicionario.json` e apague `dados/estruturado/cache.jsonl`.

## Passo 2: rodar

```bash
python scripts/rodar.py --baixar --pasta CAMINHO_DA_PASTA
```

Precisa de `pandas`, `requests`, `python-dotenv`, `typesafe-sdk`, `jupyter` e do
Quarto (`pip install pandas requests python-dotenv typesafe-sdk jupyter quarto-cli`).
A chave `JEV_API_KEY` fica no `.env` da pasta: peça ao usuário para criar o
arquivo ele mesmo e nunca peça a chave na conversa. Sem chave, o relatório sai
com o que já estiver no cache, e o script diz quantas ficaram sem tema.

Se a internet do ambiente não alcançar a Apple, peça ao usuário o arquivo da
coleta de hoje e rode sem `--baixar`.

## Passo 3: se alguma checagem bloquear

Mostre a checagem que falhou e o detalhe, e **pergunte** o que fazer. Não
resolva sozinho, e nunca edite uma coleta para a checagem passar.

## Passo 4: entregar

1. O relatório `saida/index.html`.
2. Um resumo de três frases: o que mudou desde a coleta anterior, o aplicativo
   que merece atenção e por quê, e o tema mais comum nas reclamações. Só
   números do relatório.
3. Os alertas (avaliações editadas, dado pessoal mascarado, coleta incompleta,
   classificações com confiança baixa), em linguagem simples.
4. Lembre que o relatório pode ser publicado arrastando a pasta `saida/` no
   Netlify Drop (app.netlify.com/drop).

## Regras

- A mesma avaliação em várias coletas conta uma vez; se mudou, vale a mais recente.
- Telefone, e-mail e CPF no texto são mascarados antes de ir para a IA. O
  relatório mostra só números agregados e títulos, nunca o apelido de quem avaliou.
- Gráficos: título que conclui (calculado), barras ordenadas a partir do zero,
  uma cor de destaque e cinza no resto, rótulo direto. Nada de pizza, 3D, dois
  eixos y ou boxplot.
