"""Passo 4: estruturar os textos com IA (o tema de cada avaliação e se ela reclama de algo).

Usa o Jev (typesafe-sdk), que responde perguntas tipadas e devolve a confiança de
cada resposta. As perguntas e as opções ficam em regras/dicionario.json. Só entram
as avaliações dos últimos 90 dias. Cada resposta fica guardada em
dados/estruturado/cache.jsonl assim que chega, com uma marca do texto: rodar de
novo não paga de novo, e uma avaliação editada é classificada outra vez.
A chave JEV_API_KEY fica no .env. Sem chave, o passo usa só o que já está no
cache e avisa quantas ficaram sem tema.
"""
import asyncio
import hashlib
import json
import os
from pathlib import Path

import pandas as pd

MODELO = "jev-latest"
DIAS = 90


def marca(titulo, texto) -> str:
    return hashlib.sha1(f"{titulo}\n{texto}".encode("utf-8")).hexdigest()[:12]


def perguntas(dic: dict) -> dict:
    q = {}
    for nome, v in dic["variaveis"].items():
        instr = f"{dic['_instrucoes']} {v['pergunta']}"
        q[nome] = ({"type": "choice", "instructions": instr, "criteria": v["opcoes"]} if v["tipo"] == "escolha"
                   else {"type": "noul", "instructions": instr})
    return q


async def classificar(faltam: pd.DataFrame, dic: dict, cache: dict, cache_arq: Path) -> int:
    os.environ.setdefault("TYPESAFE_API_KEY", os.environ.get("JEV_API_KEY", ""))
    from typesafe_sdk import AsyncTypeSafeClient
    cli, q, sem, erros = AsyncTypeSafeClient(model=MODELO), perguntas(dic), asyncio.Semaphore(16), 0
    with cache_arq.open("a", encoding="utf-8") as arq:
        async def uma(x):
            nonlocal erros
            estado = {k: str(v) for k, v in {"titulo": x.titulo, "texto": x.texto}.items() if str(v).strip()}
            async with sem:
                try:
                    r = await cli.system_one(state=estado, questions=q, model=MODELO)
                except Exception as e:  # registra e segue; a próxima rodada tenta de novo
                    erros += 1
                    print(f"  erro: {type(e).__name__}: {str(e)[:100]}")
                    return
            reg = {"id_avaliacao": x.id_avaliacao, "marca": x.marca}
            for k, a in r.answers.items():
                if a.type == "noul":
                    reg[k], reg[f"conf_{k}"] = a.noul >= 0.5, round(max(a.noul, 1 - a.noul), 3)
                else:
                    reg[k], reg[f"conf_{k}"] = a.choice, round(a.probabilities[a.choice], 3)
            arq.write(json.dumps(reg, ensure_ascii=False) + "\n")
            arq.flush()
            cache[(reg["id_avaliacao"], reg["marca"])] = reg
        await asyncio.gather(*(uma(x) for x in faltam.itertuples()))
    return erros


def estruturar(pasta: Path, base: pd.DataFrame, hoje: str) -> pd.DataFrame:
    dic = json.loads((pasta / "regras" / "dicionario.json").read_text(encoding="utf-8"))
    nomes = list(dic["variaveis"])
    corte = (pd.Timestamp(hoje) - pd.Timedelta(days=DIAS)).strftime("%Y-%m-%d")
    alvo = base[base["data"] > corte].copy()
    alvo["marca"] = [marca(a, b) for a, b in zip(alvo["titulo"].fillna(""), alvo["texto"].fillna(""))]

    cache_arq = pasta / "dados" / "estruturado" / "cache.jsonl"
    cache_arq.parent.mkdir(parents=True, exist_ok=True)
    cache = {}
    if cache_arq.exists():
        for linha in cache_arq.read_text(encoding="utf-8").splitlines():
            reg = json.loads(linha)
            cache[(reg["id_avaliacao"], reg["marca"])] = reg
    faltam = alvo[[(i, m) not in cache for i, m in zip(alvo["id_avaliacao"], alvo["marca"])]]
    print(f"  {len(base)} avaliações; {len(alvo)} dos últimos {DIAS} dias; "
          f"{len(alvo) - len(faltam)} já no cache; {len(faltam)} para classificar")

    if len(faltam):
        try:
            from dotenv import load_dotenv
            load_dotenv(pasta / ".env")
        except ImportError:
            pass
        if not (os.environ.get("JEV_API_KEY") or os.environ.get("TYPESAFE_API_KEY")):
            print(f"  sem JEV_API_KEY no .env: {len(faltam)} avaliações ficam sem tema nesta rodada")
        else:
            erros = asyncio.run(classificar(faltam, dic, cache, cache_arq))
            print(f"  classificadas agora: {len(faltam) - erros}; erros: {erros}")

    for n in nomes:
        alvo[n] = [cache.get((i, m), {}).get(n) for i, m in zip(alvo["id_avaliacao"], alvo["marca"])]
        alvo[f"conf_{n}"] = [cache.get((i, m), {}).get(f"conf_{n}") for i, m in zip(alvo["id_avaliacao"], alvo["marca"])]
    sem = int(alvo[nomes[0]].isna().sum())
    baixa = int((alvo[f"conf_{nomes[0]}"] < 0.6).sum())
    print(f"  saída: {len(alvo)} avaliações estruturadas, {sem} sem tema, {baixa} com confiança abaixo de 60% no tema")
    return alvo.drop(columns="marca")
