"""Passo 5: gravar os dados prontos e gerar o relatório com o Quarto (saida/index.html).

O relatório (relatorio.qmd) só lê dados/processados/: todo número sai dos passos
anteriores, nenhum é escrito à mão. Sai um arquivo único, com os gráficos dentro,
pronto para o Netlify Drop. Precisa do Quarto (quarto.org, ou pip install quarto-cli)
e do Jupyter (pip install jupyter).
"""
import json
import shutil
import subprocess
from pathlib import Path

import pandas as pd

COLUNAS = ["empresa", "id_avaliacao", "data", "nota", "nova", "editada", "titulo"]


def gravar(pasta: Path, hoje: str, base: pd.DataFrame, estruturado: pd.DataFrame, log, checagens) -> None:
    proc = pasta / "dados" / "processados"
    proc.mkdir(parents=True, exist_ok=True)
    temas = estruturado[["id_avaliacao", "tema", "conf_tema", "reclamacao"]]
    saida = base[COLUNAS].merge(temas, on="id_avaliacao", how="left")  # sem o texto inteiro
    saida.sort_values(["empresa", "data"]).to_csv(proc / "avaliacoes.csv", index=False, encoding="utf-8")
    (proc / "rodada.json").write_text(json.dumps(
        {"hoje": hoje, "log": log, "checagens": checagens}, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"  {len(base)} avaliações entraram; {len(saida)} linhas em dados/processados/avaliacoes.csv "
          f"({int(saida['tema'].notna().sum())} com tema)")


def renderizar(pasta: Path) -> Path:
    quarto = shutil.which("quarto")
    if not quarto:
        raise SystemExit("Quarto não encontrado: instale em quarto.org ou com pip install quarto-cli")
    subprocess.run([quarto, "render", "relatorio.qmd", "--output-dir", "saida"], cwd=pasta, check=True)
    return pasta / "saida" / "index.html"
