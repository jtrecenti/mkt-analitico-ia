"""Passo 2: juntar as coletas numa base só, uma linha por avaliação.

Regras (AGENTS.md): a mesma avaliação aparece em várias coletas e conta uma vez;
se ela mudou entre coletas (a pessoa editou a nota ou o texto), vale a versão
mais recente, e o relatório diz quantas mudaram. Telefone, e-mail e CPF no texto
são mascarados.
"""
import re

import pandas as pd

PESSOAIS = {
    "e-mail": r"[\w.+-]+@[\w-]+\.[\w.]+",
    "CPF": r"\b\d{3}\.?\d{3}\.?\d{3}-?\d{2}\b",
    "telefone": r"(?:\(?\d{2}\)?\s?)?9?\d{4}[-\s]?\d{4}\b",
}


def mascarar(texto: str) -> tuple[str, int]:
    n = 0
    for padrao in PESSOAIS.values():
        texto, k = re.subn(padrao, "[removido]", texto)
        n += k
    return texto, n


def juntar(coletas: dict[str, pd.DataFrame]):
    log = []
    tudo = pd.concat([d.assign(coleta=dia) for dia, d in coletas.items()], ignore_index=True)
    dias = sorted(coletas)
    # a versão mais recente de cada avaliação
    base = tudo.sort_values("coleta").drop_duplicates("id_avaliacao", keep="last").copy()
    log.append(f"{len(tudo)} linhas nas coletas viraram {len(base)} avaliações diferentes "
               f"({len(tudo) - len(base)} repetidas entre coletas)")
    # avaliações que mudaram entre coletas
    versoes = tudo.drop_duplicates(["id_avaliacao", "nota", "titulo", "texto"])
    editadas = versoes["id_avaliacao"][versoes["id_avaliacao"].duplicated()].unique()
    base["editada"] = base["id_avaliacao"].isin(editadas)
    if len(editadas):
        log.append(f"{len(editadas)} avaliação(ões) editada(s) entre coletas: vale a versão mais recente")
    # novas desde a coleta anterior
    if len(dias) > 1:
        antes = set(tudo.loc[tudo["coleta"] < dias[-1], "id_avaliacao"])
        base["nova"] = ~base["id_avaliacao"].isin(antes)
    else:
        base["nova"] = False
    # dados pessoais no texto
    total = 0
    for col in ["titulo", "texto"]:
        res = base[col].fillna("").map(mascarar)
        base[col] = res.str[0]
        total += int(res.str[1].sum())
    if total:
        log.append(f"{total} trecho(s) com cara de telefone, e-mail ou CPF mascarados")
    for linha in log:
        print("  " + linha)
    return base, tudo, log
