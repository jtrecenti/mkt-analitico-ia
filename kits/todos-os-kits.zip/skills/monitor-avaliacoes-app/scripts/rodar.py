"""Refaz o monitor das avaliações: python rodar.py [--baixar] [--pasta CAMINHO]

--baixar  baixa a coleta de hoje antes (o feed público da App Store).
--pasta   a pasta do projeto (por padrão, a pasta atual): precisa ter
          dados/coletas/. O que faltar de relatorio.qmd e regras/ vem do
          modelo/ desta skill.
O relatório sai em saida/index.html.
"""
import shutil
import sys
from pathlib import Path

from passos.p1_coletar import apps, baixar_hoje, ler_coletas
from passos.p2_juntar import juntar
from passos.p3_checar import checar
from passos.p4_estruturar import estruturar
from passos.p5_relatorio import gravar, renderizar


MODELO = Path(__file__).resolve().parents[1] / "modelo"


def preparar(pasta: Path) -> None:
    """Copia para a pasta o que faltar do modelo (o relatório e as regras), sem sobrescrever."""
    (pasta / "dados" / "coletas").mkdir(parents=True, exist_ok=True)
    for f in MODELO.rglob("*"):
        alvo = pasta / f.relative_to(MODELO)
        if f.is_file() and not alvo.exists():
            alvo.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(f, alvo)
            print(f"  copiado do modelo: {alvo.relative_to(pasta)}")


def main(pasta: Path, baixar: bool) -> None:
    preparar(pasta)
    print("1/5 coletar e ler")
    if baixar:
        baixar_hoje(pasta)
    coletas = ler_coletas(pasta)
    hoje = max(coletas)
    print("2/5 juntar");  base, tudo, log = juntar(coletas)
    print("3/5 checar");  ch = checar(coletas, base, log, apps(pasta))
    travas = [x for x in ch if not x["ok"] and x["tipo"] == "bloqueia"]
    if travas:
        print(f"\nRELATÓRIO NÃO GERADO: {len(travas)} checagem(ns) bloqueando. Resolva e rode de novo.")
        sys.exit(1)
    print("4/5 estruturar os textos"); est = estruturar(pasta, base, hoje)
    print("5/5 relatório");  gravar(pasta, hoje, base, est, log, ch)
    arq = renderizar(pasta)
    print(f"  relatório em {arq}")


if __name__ == "__main__":
    a = sys.argv[1:]
    pasta = Path(a[a.index("--pasta") + 1]) if "--pasta" in a else Path.cwd()
    main(pasta, "--baixar" in a)
