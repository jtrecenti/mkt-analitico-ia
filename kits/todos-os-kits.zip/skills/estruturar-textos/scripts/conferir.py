"""Monta a planilha de conferência à mão e, com duas extrações, a concordância.

Uso:
    python conferir.py amostra DADOS.csv EXTRAIDO.csv --id id --texto texto --n 10 --saida conferencia.csv
    python conferir.py concordancia EXTRAIDO_A.csv EXTRAIDO_B.csv --id id --saida concordancia.csv

amostra: sorteia N textos (semente fixa, sempre os mesmos), junta as respostas
da IA e deixa uma coluna vazia "minha_resposta_<var>" para cada variável. A
pessoa preenche e depois roda "acerto".
acerto: compara as colunas minha_resposta_<var> com as da IA.
concordancia: compara duas extrações (por exemplo OpenAI e Jev), variável a
variável, e diz em quantos % elas concordam.
"""
import argparse

import pandas as pd


def norm(s: pd.Series) -> pd.Series:
    s = s.astype(str).str.strip().str.lower()
    return s.replace({"1": "true", "1.0": "true", "sim": "true", "0": "false", "0.0": "false", "não": "false", "nan": ""})


def variaveis(df, chave):
    return [c for c in df.columns if c != chave and not c.startswith("conf_") and not c.startswith("minha_resposta_")]


p = argparse.ArgumentParser()
p.add_argument("modo", choices=["amostra", "acerto", "concordancia"])
p.add_argument("a")
p.add_argument("b", nargs="?")
p.add_argument("--id", default="id")
p.add_argument("--texto", default="texto")
p.add_argument("--n", type=int, default=10)
p.add_argument("--saida", required=True)
x = p.parse_args()

if x.modo == "amostra":
    dados = pd.read_csv(x.a, dtype=str)
    ext = pd.read_csv(x.b, dtype=str)
    m = dados[[x.id, x.texto]].merge(ext, on=x.id).sample(min(x.n, len(ext)), random_state=1)
    for v in variaveis(ext, x.id):
        m[f"minha_resposta_{v}"] = ""
    m.to_csv(x.saida, index=False, encoding="utf-8-sig")
    print(f"{len(m)} textos sorteados em {x.saida}: preencha as colunas minha_resposta_ e rode o modo acerto")
elif x.modo == "acerto":
    m = pd.read_csv(x.a, dtype=str)
    linhas = []
    for v in variaveis(m, x.id):
        if v == x.texto or f"minha_resposta_{v}" not in m:
            continue
        ok = m[f"minha_resposta_{v}"].notna()
        if ok.sum():
            linhas.append({"variavel": v, "conferidos": int(ok.sum()),
                           "IA acertou (%)": round(100 * (norm(m.loc[ok, v]) == norm(m.loc[ok, f"minha_resposta_{v}"])).mean(), 1)})
    r = pd.DataFrame(linhas)
    r.to_csv(x.saida, index=False)
    print(r.to_string(index=False))
else:
    a, b = pd.read_csv(x.a, dtype=str), pd.read_csv(x.b, dtype=str)
    m = a.merge(b, on=x.id, suffixes=("_a", "_b"))
    print(f"{len(a)} linhas em A, {len(b)} em B, {len(m)} em comum")
    linhas = []
    for v in variaveis(a, x.id):
        if f"{v}_b" not in m:
            continue
        ok = norm(m[f"{v}_a"]) == norm(m[f"{v}_b"])
        lin = {"variavel": v, "textos": len(m), "concordam (%)": round(100 * ok.mean(), 1)}
        conf = f"conf_{v}"
        for lado in ("_a", "_b"):
            if conf + lado in m or conf in b.columns:
                c = pd.to_numeric(m.get(conf + lado, m.get(conf)), errors="coerce")
                if c.notna().any():
                    lin["com confiança de 95% ou mais (%)"] = round(100 * ok[c >= 0.95].mean(), 1) if (c >= 0.95).any() else None
                    lin["com confiança abaixo de 80% (%)"] = round(100 * ok[c < 0.8].mean(), 1) if (c < 0.8).any() else None
                    break
        linhas.append(lin)
    r = pd.DataFrame(linhas)
    r.to_csv(x.saida, index=False)
    print(r.to_string(index=False))
