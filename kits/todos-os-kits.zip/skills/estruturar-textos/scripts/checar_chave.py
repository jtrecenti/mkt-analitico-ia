"""Confere se as chaves de API estão no .env, sem mostrar a chave.

Uso: python checar_chave.py [--env CAMINHO_DO_.env]

Mostra só se cada chave existe e os 4 últimos caracteres, para a pessoa
reconhecer qual chave é. Nunca imprime a chave inteira.
"""
import argparse
from pathlib import Path

from dotenv import dotenv_values

p = argparse.ArgumentParser()
p.add_argument("--env", type=Path, default=Path(".env"))
a = p.parse_args()
if not a.env.exists():
    print(f"Não achei {a.env.resolve()}.")
    print("Crie um arquivo de texto chamado .env nesta pasta com uma linha por chave, por exemplo:")
    print("  OPENAI_API_KEY=sk-...")
    print("  JEV_API_KEY=...")
    print("Escreva a chave você mesmo no arquivo. Nunca cole a chave na conversa.")
    raise SystemExit(1)
v = dotenv_values(a.env)
for nome in ["OPENAI_API_KEY", "JEV_API_KEY"]:
    k = (v.get(nome) or "").strip()
    print(f"{nome}: " + (f"encontrada (termina em ...{k[-4:]}, {len(k)} caracteres)" if k else "não encontrada"))
