"""Extrai variáveis de textos com um modelo de linguagem, a partir de um dicionário.

Uso:
    python extrair.py sentencas.csv --dicionario dicionario_sentencas.json --id id_sentenca --modelo openai --saida extraido_openai.csv
    python extrair.py DADOS.csv --dicionario dicionario_avaliacoes.json --modelo openai --saida extraido_openai.csv
    python extrair.py DADOS.csv --dicionario dicionario_avaliacoes.json --modelo jev --saida extraido_jev.csv

Opções úteis: --limite 30 (só as primeiras linhas, para testar), --id id_relato
(coluna de identificação, padrão "id"), --paralelo 16 (requisições ao mesmo tempo).

Chaves: OPENAI_API_KEY e JEV_API_KEY num arquivo .env na pasta onde você roda
o script (nunca no código, nunca no chat).

Cada resposta é guardada em DADOS_<modelo>.cache.jsonl assim que chega: se o
script parar no meio, rode de novo e ele continua de onde parou.
"""
from __future__ import annotations

import argparse
import asyncio
import json
import os
import time
from pathlib import Path
from typing import Literal, Optional

import pandas as pd
from dotenv import load_dotenv
from pydantic import Field, create_model

MODELOS = {"openai": "gpt-5.6-luna", "jev": "jev-latest"}
INSTRUCOES = ("Você lê textos escritos por clientes. Responda a cada pergunta só com base no texto. "
              "Se o texto de uma pergunta estiver vazio, responda false ou null.")


def carregar_dicionario(caminho: Path) -> dict:
    """Lê as variáveis. Se o dicionário trouxer "_instrucoes", elas substituem as instruções padrão."""
    global INSTRUCOES
    bruto = json.loads(caminho.read_text(encoding="utf-8"))
    INSTRUCOES = bruto.get("_instrucoes", INSTRUCOES)
    return bruto["variaveis"]


def texto(v) -> str:
    return "" if pd.isna(v) else str(v).strip()


# ---------- OpenAI: saída estruturada (um esquema Pydantic gerado do dicionário)
def esquema_openai(dic: dict):
    campos = {}
    for nome, v in dic.items():
        desc = f"[{v['fonte']}] {v['pergunta']}"
        if v["tipo"] == "escolha":
            desc += " Opções: " + "; ".join(f"{k}: {d}" for k, d in v["opcoes"].items())
            campos[nome] = (Literal[tuple(v["opcoes"])], Field(description=desc))
        elif v["tipo"] == "sim_nao":
            campos[nome] = (bool, Field(description=desc))
        else:
            campos[nome] = (Optional[float], Field(description=desc))
    return create_model("Extracao", **campos)


async def chamar_openai(cli, modelo, esquema, dic, linha) -> dict:
    fontes = sorted({v["fonte"] for v in dic.values()})
    entrada = "\n\n".join(f"### {f}\n{texto(linha.get(f)) or '(vazio)'}" for f in fontes)
    r = await cli.responses.parse(model=modelo, instructions=INSTRUCOES, input=entrada, text_format=esquema)
    resp = r.output_parsed.model_dump()
    for nome, v in dic.items():  # texto vazio: a resposta fica vazia, como no Jev
        if not texto(linha.get(v["fonte"])):
            resp[nome] = None
    return {"respostas": resp,
            "tokens": [r.usage.input_tokens, r.usage.output_tokens]}


# ---------- Jev: perguntas tipadas, com probabilidade de cada opção
def perguntas_jev(dic: dict, linha) -> dict:
    q = {}
    for nome, v in dic.items():
        if v["tipo"] == "numero" or not texto(linha.get(v["fonte"])):
            continue  # o Jev não gera números; texto vazio não tem o que perguntar
        instr = f"Sobre o texto `{v['fonte']}`: {v['pergunta']}"
        if v["tipo"] == "escolha":
            q[nome] = {"type": "choice", "instructions": instr, "criteria": v["opcoes"]}
        else:
            q[nome] = {"type": "noul", "instructions": instr}
    return q


async def chamar_jev(cli, modelo, dic, linha) -> dict:
    fontes = sorted({v["fonte"] for v in dic.values()})
    estado = {f: texto(linha.get(f)) for f in fontes if texto(linha.get(f))}
    r = await cli.system_one(state=estado, questions=perguntas_jev(dic, linha), model=modelo)
    resp, conf = {}, {}
    for k, a in r.answers.items():
        if a.type == "noul":
            resp[k], conf[k] = a.noul >= 0.5, round(max(a.noul, 1 - a.noul), 3)
        else:
            resp[k], conf[k] = a.choice, round(a.probabilities[a.choice], 3)
    return {"respostas": resp, "confianca": conf, "tokens": [r.usage.input_tokens, r.usage.output_tokens]}


async def rodar(args) -> None:
    load_dotenv(args.env)
    dic = carregar_dicionario(args.dicionario)
    dados = pd.read_csv(args.dados, dtype=str)
    if args.limite:
        dados = dados.head(args.limite)
    cache = args.dados.with_name(f"{args.dados.stem}_{args.modelo}.cache.jsonl")
    feitos = {}
    if cache.exists():
        for l in cache.read_text(encoding="utf-8").splitlines():
            reg = json.loads(l)
            feitos[reg["id"]] = reg
    faltam = [r for _, r in dados.iterrows() if r[args.id] not in feitos]
    print(f"{len(dados)} linhas, {len(feitos)} já no cache, {len(faltam)} para extrair com {args.modelo}")

    modelo = MODELOS[args.modelo]
    if args.modelo == "openai":
        from openai import AsyncOpenAI
        cli, esquema = AsyncOpenAI(max_retries=5), esquema_openai(dic)
        chamar = lambda linha: chamar_openai(cli, modelo, esquema, dic, linha)
    else:
        os.environ.setdefault("TYPESAFE_API_KEY", os.environ.get("JEV_API_KEY", ""))
        from typesafe_sdk import AsyncTypeSafeClient
        cli = AsyncTypeSafeClient(model=modelo)
        chamar = lambda linha: chamar_jev(cli, modelo, dic, linha)

    sem = asyncio.Semaphore(args.paralelo)
    erros = 0
    with cache.open("a", encoding="utf-8") as arq:
        async def uma(linha):
            nonlocal erros
            async with sem:
                t0 = time.perf_counter()
                try:
                    reg = await chamar(linha)
                except Exception as e:  # registra e segue; rodar de novo tenta outra vez
                    erros += 1
                    print(f"  erro em {linha[args.id]}: {type(e).__name__}: {str(e)[:120]}")
                    return
                reg.update(id=linha[args.id], segundos=round(time.perf_counter() - t0, 2))
                arq.write(json.dumps(reg, ensure_ascii=False) + "\n")
                arq.flush()
                feitos[reg["id"]] = reg
                if len(feitos) % 200 == 0:
                    print(f"  {len(feitos)} prontas")
        await asyncio.gather(*(uma(r) for _, r in pd.DataFrame(faltam).iterrows())) if faltam else None

    linhas = []
    for i in dados[args.id]:
        if i in feitos:
            reg = feitos[i]
            linhas.append({args.id: i, **reg["respostas"],
                           **{f"conf_{k}": c for k, c in reg.get("confianca", {}).items()}})
    saida = pd.DataFrame(linhas)
    saida.to_csv(args.saida, index=False, encoding="utf-8")
    tok = [feitos[i]["tokens"] for i in dados[args.id] if i in feitos]
    seg = [feitos[i]["segundos"] for i in dados[args.id] if i in feitos]
    print(f"{len(saida)} linhas em {args.saida}; {erros} erros nesta rodada")
    if tok:
        print(f"tokens: {sum(t[0] for t in tok):,} de entrada, {sum(t[1] for t in tok):,} de saída; "
              f"tempo mediano por texto: {pd.Series(seg).median():.2f} s")


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("dados", type=Path)
    p.add_argument("--dicionario", type=Path, required=True)
    p.add_argument("--modelo", choices=list(MODELOS), default="openai")
    p.add_argument("--saida", type=Path, required=True)
    p.add_argument("--id", default="id")
    p.add_argument("--limite", type=int)
    p.add_argument("--paralelo", type=int, default=16)
    p.add_argument("--env", type=Path, default=Path(".env"), help="arquivo com as chaves (padrão: .env na pasta atual)")
    asyncio.run(rodar(p.parse_args()))


if __name__ == "__main__":
    main()
