---
name: estruturar-textos
description: Transforma textos abertos (avaliações, reclamações, respostas de NPS, comentários, pesquisas) em colunas de uma planilha, com um modelo de linguagem (OpenAI ou Jev) e um dicionário de variáveis construído com o usuário. Guia a configuração da chave de API no arquivo .env, o teste em 10 textos conferidos à mão, a extração de todos com cache e a concordância entre dois modelos. Use quando pedirem para classificar, categorizar, codificar, etiquetar ou extrair informações de muitos textos.
---

# Estruturar textos com IA

Você conduz o usuário por cinco etapas, **uma de cada vez**, e só passa para a
seguinte quando a anterior está certa. Os scripts fazem as contas e as chamadas
à API; você conversa, explica e interpreta. Nunca invente uma resposta que não
veio do script.

Os scripts precisam de `pandas`, `python-dotenv`, `pydantic` e `openai` (para a
OpenAI) ou `typesafe-sdk` (para o Jev). Se faltar, rode
`pip install pandas python-dotenv pydantic openai typesafe-sdk`.

## Etapa 1: a chave de API, no .env

1. Explique: a chave é uma senha que paga as chamadas. Ela fica num arquivo de
   texto chamado `.env`, **na pasta de trabalho**, com uma linha por chave:
   `OPENAI_API_KEY=...` e/ou `JEV_API_KEY=...`.
2. Peça ao usuário para criar ou editar o arquivo **ele mesmo**. Nunca peça
   para colar a chave na conversa; se ele colar, avise que a chave deve ser
   trocada e não a repita.
3. Confira sem mostrar a chave:
   `python scripts/checar_chave.py --env .env`

## Etapa 2: o dicionário de variáveis

Construa o dicionário **com o usuário**, uma variável por vez:

- Qual pergunta cada coluna responde? ("Qual o assunto principal?")
- Quais são as opções, fechadas e sem sobreposição? Cada opção com uma frase
  que diga o que entra nela.
- Sempre uma opção para "não se aplica" ou "outro".
- O tipo: `escolha`, `sim_nao` ou `numero` (número só na OpenAI).
- De qual coluna da planilha vem o texto (`fonte`).

Comece de `scripts/modelo_dicionario.json` e grave `dicionario.json` na pasta.
Mostre o dicionário pronto e peça confirmação. Menos variáveis bem definidas
valem mais que muitas vagas.

## Etapa 3: testar em 10 textos e conferir à mão

```bash
python scripts/extrair.py DADOS.csv --dicionario dicionario.json --id COLUNA_ID --modelo openai --limite 10 --saida teste.csv
python scripts/conferir.py amostra DADOS.csv teste.csv --id COLUNA_ID --texto COLUNA_TEXTO --n 10 --saida conferencia.csv
```

Peça ao usuário para preencher as colunas `minha_resposta_` da planilha
`conferencia.csv` lendo cada texto. Depois:

`python scripts/conferir.py acerto conferencia.csv --id COLUNA_ID --texto COLUNA_TEXTO --saida acerto.csv`

Se uma variável acertar menos de 8 em 10, a pergunta ou as opções estão
ambíguas: reescreva junto com o usuário e teste de novo. Avise que mudar o
dicionário exige apagar o cache (`DADOS_openai.cache.jsonl`), senão voltam as
respostas antigas.

## Etapa 4: rodar em todos, com cache

```bash
python scripts/extrair.py DADOS.csv --dicionario dicionario.json --id COLUNA_ID --modelo openai --saida extraido_openai.csv
```

Cada resposta fica no cache assim que chega: se parar, rode de novo e ele
continua. Informe quantas linhas entraram, quantas saíram, os erros, os tokens
e o tempo (o script mostra). Antes de rodar milhares de textos, diga ao usuário
o custo aproximado a partir dos tokens do teste.

## Etapa 5 (opcional): o segundo modelo e a concordância

Rode com `--modelo jev` e compare:

`python scripts/conferir.py concordancia extraido_openai.csv extraido_jev.csv --id COLUNA_ID --saida concordancia.csv`

Leia em linguagem simples: onde os dois concordam, a extração é estável; onde
discordam, vale ler os textos. O Jev dá a confiança de cada resposta: quando
ela é baixa, a discordância costuma ser maior.

## Regras

- A coluna de identificação precisa ser única (um código por texto).
- Nenhum dado pessoal (nome, CPF, e-mail, telefone) vai para a saída nem para
  a conversa. Se os textos tiverem, avise antes de mandar para a API e sugira
  remover.
- Chave só no `.env`. O `.env` nunca vai para pasta compartilhada.
