# Skill estruturar-textos

**O que faz:** transforma textos abertos (avaliações, reclamações, NPS,
comentários) em colunas de uma planilha, com a OpenAI ou o Jev. Conduz cinco
etapas: a chave no `.env`, o dicionário de variáveis, o teste em 10 textos
conferidos à mão, a extração de todos com cache e a concordância entre os dois
modelos.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip. Ou, numa conversa no modo Work: "crie esta habilidade a partir deste
zip".

**Como adaptar:** troque as instruções (`_instrucoes`) e as variáveis do
`scripts/modelo_dicionario.json` pelas da sua realidade: o tipo de texto, as
perguntas que importam para o seu time e as opções de cada uma.

**Pedido de exemplo:** "Tenho 3.000 respostas abertas da pesquisa de NPS em
`nps.csv`, coluna `comentario`. Quero saber o tema de cada uma e se o cliente
fala de preço. Use a habilidade estruturar-textos."
