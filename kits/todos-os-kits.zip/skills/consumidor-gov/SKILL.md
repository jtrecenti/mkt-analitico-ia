---
name: consumidor-gov
description: Baixa reclamações finalizadas do consumidor.gov.br (dados abertos oficiais) para as empresas ou o segmento de mercado escolhidos, num período em meses, e entrega um CSV único com contagens de conferência. Use quando pedirem reclamações de consumidores, dados do consumidor.gov.br, reputação ou nota de empresas no consumidor.gov, ou comparação de atendimento entre empresas brasileiras.
---

# Baixar reclamações do consumidor.gov.br

## Quando usar

- Alguém quer reclamações de uma ou mais empresas, ou de um setor inteiro.
- Alguém quer comparar notas, índice de solução ou tempo de resposta entre empresas.

Não use para obter o **texto** das reclamações: os dados abertos não trazem texto,
e a página de relatos exige login gov.br. Para texto, há a base
`dados/reclamacoes_texto_2024.csv` do curso (relatos de 2024, anonimizados).

## Como rodar

1. Se não souber o nome exato da empresa, liste as empresas de um mês:

   ```
   python scripts/baixar_reclamacoes.py --inicio 2026-09 --fim 2026-09 --listar-empresas
   ```

2. Baixe e filtre. Por empresas (nome exato da coluna "Nome Fantasia"):

   ```
   python scripts/baixar_reclamacoes.py --inicio 2026-01 --fim 2026-09 \
     --empresas "MRV Engenharia" "Direcional Engenharia" --saida reclamacoes.csv
   ```

   Ou por segmento (trecho do nome em "Segmento de Mercado"):

   ```
   python scripts/baixar_reclamacoes.py --inicio 2026-01 --fim 2026-09 \
     --segmento "Construtoras" --saida reclamacoes.csv
   ```

Dependências: `pandas`, `requests`; para alguns meses, `py7zr` e `zipfile-deflate64`
(`pip install pandas requests py7zr zipfile-deflate64`).

## Como conferir o resultado

O script imprime, para cada mês, quantas reclamações o arquivo tinha e quantas
foram selecionadas. Antes de entregar, confira:

- todos os meses pedidos aparecem (o mês mais recente sai por volta do dia 10 do mês seguinte);
- nenhuma empresa da lista ficou com zero linhas (o script avisa);
- o total do CSV é a soma das linhas selecionadas de cada mês;
- mostre ao usuário essas contagens e cinco linhas de exemplo.

## O que tem nos dados

19 colunas, uma linha por reclamação finalizada no mês: região, UF, cidade, sexo,
faixa etária, data de finalização, tempo de resposta (dias), nome fantasia,
segmento, área, assunto, grupo do problema, problema, como comprou, procurou a
empresa (S/N), respondida (S/N), situação, avaliação (Resolvida, Não Resolvida,
Não Avaliada) e nota do consumidor (1 a 5, vazia se não avaliou). O script
acrescenta `arquivo_mes`.

## Armadilhas conhecidas

- **Filtro por pedaço de nome pega empresas a mais.** "Azul" casa com "Azul
  Fidelidade" e "Cruz Azul Saúde"; "Gol" casa com "Pagol". Use nomes exatos.
- **O formato do arquivo muda.** A maioria é `.zip` com `.csv`; maio/2026 veio
  com um `.7z` dentro do `.zip`; junho/2026 veio com compressão Deflate64. O
  script olha os bytes, e não o nome, e desembrulha até achar o CSV.
- **Mais da metade das reclamações não tem nota** (o consumidor não avaliou).
  Média de nota é só das avaliadas: diga isso ao apresentar.
- **A data é a de finalização**, e não a de abertura.
- O catálogo de arquivos (`publicacoes.json`) demora uns 30 segundos para responder.
- Seja educado com o servidor: o script guarda os arquivos em cache e espera 1
  segundo entre downloads.
