"""Baixa reclamações finalizadas do consumidor.gov.br (dados abertos) e filtra empresas.

Fonte: a aba "Dados Abertos" do consumidor.gov.br publica, todo mês, um arquivo
com todas as reclamações finalizadas naquele mês (CSV com ";", UTF-8 com BOM,
19 colunas, sem o texto da reclamação). O catálogo de arquivos é um JSON
público; cada arquivo baixa por um endereço fixo a partir do seu código.

Uso:
    python baixar_reclamacoes.py --inicio 2026-01 --fim 2026-09 \
        --empresas "Azul Linhas Aéreas" "Gol Linhas Aéreas" "Latam Airlines (Tam)" \
        --saida reclamacoes.csv

Dicas:
  * Use o nome exato da coluna "Nome Fantasia" (rode com --listar-empresas para
    ver os nomes de um mês). Filtro por pedaço de nome pega empresas a mais:
    "Azul" também casa com "Azul Fidelidade" e "Cruz Azul Saúde".
  * Os arquivos baixados ficam em --cache e não são baixados de novo.
"""
from __future__ import annotations

import argparse
import io
import sys
import time
import zipfile
from pathlib import Path

import pandas as pd
import requests

BASE = "https://www.consumidor.gov.br/pages/publicacao/externo"
CABECALHOS = {"User-Agent": "Mozilla/5.0 (curso Insper)", "X-Requested-With": "XMLHttpRequest"}


def catalogo() -> list[dict]:
    """Lista os arquivos mensais publicados (a resposta demora uns 30 s)."""
    r = requests.get(f"{BASE}/publicacoes.json", params={"indicadorTipoPublicacao": 2},
                     headers=CABECALHOS, timeout=300)
    r.raise_for_status()
    r.encoding = "latin-1"
    return [p for p in r.json() if p["nomeArquivo"].startswith("finalizadas_")]


def mes_do_arquivo(pub: dict) -> str:
    # "finalizadas_2026-09.zip" -> "2026-09"
    return pub["nomeArquivo"].removeprefix("finalizadas_")[:7]


def baixar_mes(pub: dict, cache: Path) -> pd.DataFrame:
    destino = cache / pub["nomeArquivo"]
    if not destino.exists():
        r = requests.get(f"{BASE}/{pub['codigo']}/download", headers=CABECALHOS, timeout=600)
        r.raise_for_status()
        destino.write_bytes(r.content)
        time.sleep(1)  # educação com o servidor público
    return ler_csv(desembrulhar(destino.read_bytes()))


def desembrulhar(conteudo: bytes) -> bytes:
    """Tira o CSV de dentro do arquivo publicado.

    O formato não é estável: quase todo mês é um .zip com um .csv dentro, mas
    há meses com o .csv solto e pelo menos um (maio/2026) com um .7z dentro do
    .zip. Então a função olha os bytes, e não o nome do arquivo, e desembrulha
    até chegar no texto.
    """
    if conteudo[:2] == b"PK":  # zip
        try:
            import zipfile_deflate64  # noqa: F401  junho/2026 veio em Deflate64: pip install zipfile-deflate64
        except ImportError:
            pass
        with zipfile.ZipFile(io.BytesIO(conteudo)) as z:
            return desembrulhar(z.read(z.namelist()[0]))
    if conteudo[:6] == b"7z\xbc\xaf\x27\x1c":  # 7z
        import tempfile
        import py7zr  # só é preciso nesse caso: pip install py7zr
        with tempfile.TemporaryDirectory() as tmp, py7zr.SevenZipFile(io.BytesIO(conteudo)) as z:
            z.extractall(path=tmp)
            primeiro = sorted(p for p in Path(tmp).rglob("*") if p.is_file())[0]
            return desembrulhar(primeiro.read_bytes())
    return conteudo


def ler_csv(texto: bytes) -> pd.DataFrame:
    for codificacao in ("utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(io.BytesIO(texto), sep=";", encoding=codificacao, low_memory=False, dtype=str)
        except UnicodeDecodeError:
            continue
    raise ValueError("não consegui ler o CSV em UTF-8 nem em Latin-1")


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--inicio", required=True, help="primeiro mês, AAAA-MM")
    ap.add_argument("--fim", required=True, help="último mês, AAAA-MM")
    ap.add_argument("--empresas", nargs="*", default=[], help="nomes exatos em 'Nome Fantasia'")
    ap.add_argument("--segmento", default=None, help="filtra por 'Segmento de Mercado' (trecho do nome)")
    ap.add_argument("--saida", default="reclamacoes.csv")
    ap.add_argument("--cache", default="cache_consumidor")
    ap.add_argument("--listar-empresas", action="store_true", help="só mostra as empresas do último mês")
    a = ap.parse_args(argv)

    cache = Path(a.cache)
    cache.mkdir(parents=True, exist_ok=True)
    pubs = sorted((p for p in catalogo() if a.inicio <= mes_do_arquivo(p) <= a.fim), key=mes_do_arquivo)
    if not pubs:
        print("Nenhum arquivo publicado nesse período.", file=sys.stderr)
        return 1

    if a.listar_empresas:
        df = baixar_mes(pubs[-1], cache)
        print(df["Nome Fantasia"].value_counts().to_string())
        return 0

    partes = []
    for p in pubs:
        df = baixar_mes(p, cache)
        filtro = pd.Series(True, index=df.index)
        if a.empresas:
            filtro &= df["Nome Fantasia"].isin(a.empresas)
        if a.segmento:
            filtro &= df["Segmento de Mercado"].str.contains(a.segmento, case=False, na=False)
        sel = df[filtro].copy()
        sel.insert(0, "arquivo_mes", mes_do_arquivo(p))
        partes.append(sel)
        print(f"{mes_do_arquivo(p)}: {len(df):>7} reclamações no mês, {len(sel):>6} selecionadas")

    final = pd.concat(partes, ignore_index=True)
    final.to_csv(a.saida, index=False, sep=";", encoding="utf-8-sig")
    print(f"\n{len(final)} linhas gravadas em {a.saida}")
    if a.empresas:
        faltando = set(a.empresas) - set(final["Nome Fantasia"].unique())
        if faltando:
            print("Atenção, sem nenhuma linha para:", ", ".join(sorted(faltando)), file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
