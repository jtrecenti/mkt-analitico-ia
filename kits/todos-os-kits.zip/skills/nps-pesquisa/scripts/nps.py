"""Calcula o NPS de uma pesquisa, no total e por segmento, com intervalo de confiança.

Uso:
    python nps.py respostas.csv
    python nps.py respostas.csv --nota nota_recomendacao --segmento regiao --segmento canal --comentario comentario
    python nps.py --exemplo respostas_exemplo.csv    (gera uma pesquisa fictícia para testar)

Regras:
- nota de 0 a 10: promotores 9 e 10, neutros 7 e 8, detratores 0 a 6;
- NPS = % de promotores menos % de detratores, de -100 a +100;
- intervalo de 95%: NPS ± 1,96 × erro padrão, com o erro padrão calculado a
  partir das proporções de promotores e detratores;
- segmento com menos de 30 respostas recebe o alerta "amostra pequena";
- respostas sem nota ou com nota fora de 0 a 10 ficam de fora, e o script diz
  quantas.

Os comentários abertos saem separados por grupo (promotor, neutro, detrator) e
por segmento num CSV à parte, para leitura. Colunas com nome, e-mail ou
telefone não são copiadas.
"""
from __future__ import annotations

import argparse
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd

PESSOAIS = ("nome", "email", "e-mail", "telefone", "celular", "cpf", "whatsapp")


def grupo(n: float) -> str:
    return "promotor" if n >= 9 else ("neutro" if n >= 7 else "detrator")


def nps(notas: pd.Series) -> dict:
    n = len(notas)
    if n == 0:
        return {"respostas": 0}
    pp, pd_ = (notas >= 9).mean(), (notas <= 6).mean()
    v = 100 * (pp - pd_)
    ep = 100 * math.sqrt(max(pp + pd_ - (pp - pd_) ** 2, 0) / n)
    return {"respostas": n, "promotores_%": round(100 * pp, 1), "neutros_%": round(100 * (1 - pp - pd_), 1),
            "detratores_%": round(100 * pd_, 1), "NPS": round(v, 1),
            "IC95_min": round(max(v - 1.96 * ep, -100), 1), "IC95_max": round(min(v + 1.96 * ep, 100), 1),
            "alerta": "amostra pequena" if n < 30 else ""}


def exemplo(destino: Path) -> None:
    rng = np.random.default_rng(7)
    regioes = {"Sudeste": 0.6, "Sul": 0.2, "Nordeste": 0.15, "Norte": 0.05}
    canais = ["loja", "app", "site"]
    frases = {"promotor": ["Entrega rápida e produto bom", "Atendimento excelente", "Recomendo, preço justo"],
              "neutro": ["Bom, mas demorou", "Produto ok, embalagem fraca", "Nada de especial"],
              "detrator": ["Atraso na entrega", "Cobrança indevida", "Atendimento não resolveu"]}
    linhas = []
    for _ in range(600):
        r = rng.choice(list(regioes), p=list(regioes.values()))
        c = rng.choice(canais)
        base = {"Sudeste": 7.6, "Sul": 8.1, "Nordeste": 7.0, "Norte": 6.6}[r] + (0.5 if c == "app" else 0)
        nota = int(np.clip(round(rng.normal(base, 2.0)), 0, 10))
        com = rng.choice(frases[grupo(nota)]) if rng.random() < 0.5 else ""
        linhas.append({"id_resposta": len(linhas) + 1, "regiao": r, "canal": c, "nota": nota, "comentario": com})
    linhas += [{"id_resposta": 601, "regiao": "Sul", "canal": "loja", "nota": None, "comentario": ""},
               {"id_resposta": 602, "regiao": "Sul", "canal": "app", "nota": 11, "comentario": ""}]
    pd.DataFrame(linhas).to_csv(destino, index=False)
    print(f"pesquisa fictícia com {len(linhas)} respostas em {destino}")


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("arquivo", nargs="?", type=Path)
    p.add_argument("--nota", default=None, help="coluna da nota de 0 a 10 (padrão: a que se chama nota, nps ou recomendacao)")
    p.add_argument("--segmento", action="append", default=[], help="coluna de segmento; pode repetir")
    p.add_argument("--comentario", default=None)
    p.add_argument("--saida", type=Path, default=Path("nps_resultado.csv"))
    p.add_argument("--exemplo", type=Path)
    a = p.parse_args()
    if a.exemplo:
        exemplo(a.exemplo)
        return
    if not a.arquivo:
        p.error("informe o arquivo das respostas")
    d = pd.read_excel(a.arquivo) if a.arquivo.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(a.arquivo, sep=None, engine="python")
    col = a.nota or next((c for c in d.columns if c.lower() in ("nota", "nps", "recomendacao", "nota_recomendacao", "score")), None)
    if not col:
        raise SystemExit(f"não achei a coluna da nota; use --nota. Colunas: {list(d.columns)}")
    com = a.comentario or next((c for c in d.columns if c.lower() in ("comentario", "comentário", "comentarios", "motivo", "texto")), None)
    entrou = len(d)
    d["_nota"] = pd.to_numeric(d[col], errors="coerce")
    validas = d["_nota"].between(0, 10)
    print(f"{entrou} respostas lidas; {int((~validas).sum())} sem nota ou fora de 0 a 10 ficaram de fora; "
          f"{int(validas.sum())} entram no cálculo")
    d = d[validas].copy()
    d["grupo"] = d["_nota"].map(grupo)
    linhas = [{"segmento": "total", "valor": "todas", **nps(d["_nota"])}]
    for s in a.segmento:
        for v, g in d.groupby(s):
            linhas.append({"segmento": s, "valor": v, **nps(g["_nota"])})
    res = pd.DataFrame(linhas)
    print()
    print(res.to_string(index=False))
    res.to_csv(a.saida, index=False, encoding="utf-8-sig")
    if com:
        manter = [c for c in [com, "grupo", *a.segmento, "_nota"] if c in d.columns and not any(x in c.lower() for x in PESSOAIS)]
        c = d[d[com].fillna("").astype(str).str.strip() != ""][manter].rename(columns={"_nota": "nota"})
        arq = a.saida.with_name(a.saida.stem + "_comentarios.csv")
        c.sort_values(["grupo", *a.segmento]).to_csv(arq, index=False, encoding="utf-8-sig")
        print(f"\n{len(c)} comentários separados por grupo em {arq}: "
              + ", ".join(f"{k}: {v}" for k, v in c["grupo"].value_counts().items()))
    print(f"resultado em {a.saida}")


if __name__ == "__main__":
    main()
