---
name: nps-pesquisa
description: Calcula o NPS de uma pesquisa de satisfação (promotores, neutros e detratores), no total e por segmento, com intervalo de confiança e alerta de amostra pequena, e separa os comentários abertos por grupo para leitura. Use quando enviarem respostas de uma pesquisa NPS ou de recomendação de 0 a 10 e pedirem o NPS, a comparação entre regiões, lojas, canais ou períodos, ou a leitura dos comentários.
---

# NPS de uma pesquisa

**O script calcula; você interpreta.** Nunca calcule o NPS de cabeça, nem
compare segmentos sem olhar o intervalo de confiança.

## Passo 1: as colunas

Diga ao usuário quantas respostas o arquivo tem e quais colunas parecem ser a
nota (0 a 10), os segmentos (região, loja, canal, mês) e o comentário aberto.
Combine antes de rodar. Não mostre linhas com dados de quem respondeu.

## Passo 2: rodar

```bash
python scripts/nps.py RESPOSTAS.csv --nota nota --segmento regiao --segmento canal --comentario comentario --saida nps.csv
```

Para testar sem dados reais: `python scripts/nps.py --exemplo exemplo.csv`.

## Passo 3: explicar

1. Quantas respostas entraram e quantas ficaram de fora (sem nota ou fora de 0 a 10).
2. O NPS total e o de cada segmento, **com o intervalo**. Dois segmentos só são
   diferentes se os intervalos não se sobrepõem; diga isso em linguagem simples.
3. Os segmentos com "amostra pequena": não tire conclusão deles.
4. Leia o arquivo de comentários e resuma, separado por grupo, os temas que
   aparecem nos detratores e nos promotores, com dois exemplos curtos de cada.
   Contagem de temas, se pedida, vem de um script (por exemplo, a habilidade
   contar-termos), e não da leitura.

## Regras

- Promotores 9 e 10, neutros 7 e 8, detratores 0 a 6. Não mude a régua sem o
  usuário pedir.
- Colunas com nome, e-mail, telefone ou CPF não vão para o arquivo de
  comentários e não aparecem no chat.
