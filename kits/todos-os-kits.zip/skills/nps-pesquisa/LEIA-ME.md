# Skill nps-pesquisa

**O que faz:** calcula o NPS (promotores menos detratores) no total e por
segmento, com intervalo de confiança de 95% e alerta para segmentos com menos
de 30 respostas, e separa os comentários abertos por grupo num CSV para leitura.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip (ou a pasta `nps-pesquisa`).

**Pedido de exemplo:**

> Use a habilidade nps-pesquisa nas respostas de outubro. Compare o NPS por
> região e por canal, diga quais diferenças são de verdade e quais podem ser
> acaso, e resuma o que os detratores reclamam.

**Como adaptar:**

- Outra régua (por exemplo, CSAT de 1 a 5): mude a função `grupo` no script.
- Comparar meses: use a coluna do mês como `--segmento`.
- Teste sem dado real: `python scripts/nps.py --exemplo exemplo.csv` (600
  respostas fictícias; NPS total 5,3, de -1,0 a 11,7).
