---
name: consolidar-midia
description: Junta exportações de mídia de plataformas diferentes (Meta, Google Ads, TikTok, LinkedIn e outras, em CSV ou Excel, com colunas, datas e formatos de número diferentes) numa tabela padrão por dia, canal e campanha, e soma os leads de um CRM por campanha. Use quando pedirem para consolidar, juntar ou cruzar relatórios de mídia, investimento de campanhas, exportações de plataformas de anúncio ou leads por campanha.
---

# Consolidar exportações de mídia

Cada plataforma exporta do seu jeito. **O script padroniza e conta; você lê e
explica.** Nunca some investimento de cabeça nem copie números de uma planilha
para outra à mão.

## Passo 1: olhar os arquivos

Para cada arquivo, diga ao usuário de que plataforma ele parece ser e quais
colunas tem (só os nomes). O nome do arquivo costuma dizer o canal (`meta`,
`google`, `tiktok`); se não disser, combine e use `--canal arquivo=Canal`.

## Passo 2: rodar

```bash
python scripts/consolidar_midia.py ARQ1 ARQ2 ARQ3 --saida midia_consolidada.csv
python scripts/consolidar_midia.py ARQ1 ARQ2 --leads LEADS.csv --saida midia_consolidada.csv
```

Se o script disser que faltam colunas, acrescente o nome que a plataforma usa
em `scripts/de_para_colunas.csv` (coluna_original,coluna_padrao) e rode de novo.
Mostre ao usuário a linha que acrescentou.

## Passo 3: explicar

Com os números do script, sem mudar nenhum:

1. Para cada arquivo: quantas linhas entraram, quantas eram de "Total", quantas
   estavam repetidas e o formato de data que o script usou.
2. O investimento, as impressões, os cliques e os leads por canal.
3. Os leads sem campanha correspondente, se houver (nome de campanha diferente
   no CRM e na plataforma).
4. Depois, a leitura: custo por clique, custo por lead e o que chama a atenção.

## Regras

- A linha de "Total" do Google Ads nunca entra na soma: ela dobraria o
  investimento.
- Exportação repetida conta uma vez: o script diz quantas linhas saíram.
- Datas ambíguas (todas com dia até 12): o script assume DD/MM/AAAA. Diga isso
  e pergunte se a plataforma exporta no formato americano.
- Os arquivos originais não são alterados.
