# Skill consolidar-midia

**O que faz:** junta exportações de Meta, Google Ads, TikTok e outras
plataformas numa tabela padrão (data, canal, campanha, investimento,
impressões, cliques) e soma os leads do CRM por campanha. Resolve linha de
título, linha de "Total", data americana, "R$ 1.234,56" e exportação repetida,
e diz na tela quantas linhas cada correção mexeu.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip (ou a pasta `consolidar-midia`).

**Pedido de exemplo:**

> Use a habilidade consolidar-midia com estes três arquivos de outubro (Meta,
> Google Ads e os leads do RD Station). Quanto investimos por canal, quantos
> leads vieram e qual foi o custo por lead? Diga o que o script precisou
> corrigir em cada arquivo.

**Como adaptar:**

- Plataforma nova: acrescente os nomes de coluna dela em
  `scripts/de_para_colunas.csv`. Não precisa mexer no código.
- Outra métrica (conversões, visualizações de vídeo): acrescente a coluna em
  `PADRAO` e no de/para.
- Canal pelo nome do arquivo: a lista `CANAIS`, no começo do script.

**Testado com** as exportações fictícias da Bora Bebidas de outubro de 2026
(Meta R$ 26.122,48, Google R$ 29.834,48, 730 leads).
