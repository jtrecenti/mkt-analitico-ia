"""Junta exportações de mídia de plataformas diferentes numa tabela padrão.

Uso:
    python consolidar_midia.py meta.csv "Google Ads - Outubro.xlsx" tiktok.csv --saida consolidado.csv
    python consolidar_midia.py *.csv *.xlsx --leads rdstation_leads.csv --saida consolidado.csv
    python consolidar_midia.py meta.csv --canal meta.csv=Meta --de-para minhas_colunas.csv

A tabela padrão tem uma linha por dia, canal e campanha:
    data, canal, campanha, investimento, impressoes, cliques   (e leads, se houver)

O que o script resolve sozinho, e conta na tela:
- nomes de coluna diferentes em cada plataforma (tabela de/para em
  de_para_colunas.csv, que você pode editar);
- linhas de título antes do cabeçalho e a linha de "Total" no fim (Google Ads);
- datas no formato americano (MM/DD/AAAA) ou brasileiro (DD/MM/AAAA): decide
  pelo arquivo inteiro, olhando qual parte passa de 12;
- valores como texto ("R$ 1.234,56") e com ponto decimal ("1234.56");
- linhas repetidas (exportação feita duas vezes);
- leads de um CRM, um por linha, somados por dia e campanha (nome da campanha
  comparado sem maiúsculas, acentos e símbolos).
"""
from __future__ import annotations

import argparse
import re
import sys
import unicodedata
from pathlib import Path

import pandas as pd

PADRAO = ["data", "canal", "campanha", "investimento", "impressoes", "cliques"]
AQUI = Path(__file__).resolve().parent
CANAIS = {"meta": "Meta", "facebook": "Meta", "instagram": "Meta", "fb": "Meta", "google": "Google",
          "adwords": "Google", "tiktok": "TikTok", "linkedin": "LinkedIn", "email": "E-mail", "rdstation": None}


def chave(txt) -> str:
    t = unicodedata.normalize("NFKD", str(txt)).encode("ascii", "ignore").decode().lower()
    return re.sub(r"[^a-z0-9]+", "_", t).strip("_")


def carregar_de_para(arq: Path | None) -> dict[str, str]:
    d = pd.read_csv(AQUI / "de_para_colunas.csv")
    if arq:
        d = pd.concat([d, pd.read_csv(arq)])
    return {chave(a): b for a, b in zip(d["coluna_original"], d["coluna_padrao"])}


def ler_bruto(arq: Path) -> pd.DataFrame:
    if arq.suffix.lower() in (".xlsx", ".xls"):
        return pd.read_excel(arq, header=None, dtype=str)
    for enc in ("utf-8-sig", "latin-1"):
        try:
            return pd.read_csv(arq, header=None, dtype=str, sep=None, engine="python", encoding=enc)
        except UnicodeDecodeError:
            continue
    raise SystemExit(f"não consegui ler {arq}")


def achar_cabecalho(bruto: pd.DataFrame, de_para: dict) -> pd.DataFrame:
    for i in range(min(15, len(bruto))):
        conhecidas = sum(chave(c) in de_para for c in bruto.iloc[i].fillna(""))
        if conhecidas >= 2:
            d = bruto.iloc[i + 1:].copy()
            d.columns = [str(c) for c in bruto.iloc[i]]
            return d.reset_index(drop=True), i
    raise SystemExit("não achei o cabeçalho: acrescente os nomes das colunas em de_para_colunas.csv")


def numero(x):
    if pd.isna(x):
        return float("nan")
    s = re.sub(r"[^\d,.\-]", "", str(x))
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".") if s.rfind(",") > s.rfind(".") else s.replace(",", "")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s)
    except ValueError:
        return float("nan")


def datas(col: pd.Series) -> tuple[pd.Series, str]:
    s = col.astype(str).str.strip().str[:10]
    if s.str.match(r"\d{4}-\d{2}-\d{2}").mean() > 0.8:
        return pd.to_datetime(s, errors="coerce"), "AAAA-MM-DD"
    partes = s.str.extract(r"(\d{1,2})/(\d{1,2})/(\d{4})").astype(float)
    if (partes[1] > 12).any() and not (partes[0] > 12).any():
        return pd.to_datetime(s, format="%m/%d/%Y", errors="coerce"), "MM/DD/AAAA (americano)"
    return pd.to_datetime(s, format="%d/%m/%Y", errors="coerce"), "DD/MM/AAAA"


def canal_do_arquivo(arq: Path, forcados: dict) -> str | None:
    if str(arq) in forcados or arq.name in forcados:
        return forcados.get(str(arq), forcados.get(arq.name))
    nome = chave(arq.stem)
    return next((v for k, v in CANAIS.items() if k in nome), "")


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("arquivos", nargs="+", type=Path)
    p.add_argument("--leads", type=Path, help="arquivo de leads do CRM, um lead por linha")
    p.add_argument("--canal", action="append", default=[], help="arquivo=Canal, quando o nome do arquivo não diz")
    p.add_argument("--de-para", type=Path, help="CSV extra com coluna_original,coluna_padrao")
    p.add_argument("--saida", type=Path, default=Path("midia_consolidada.csv"))
    a = p.parse_args()
    de_para = carregar_de_para(a.de_para)
    forcados = dict(x.split("=", 1) for x in a.canal)
    partes = []
    for arq in a.arquivos:
        bruto = ler_bruto(arq)
        d, linha_cab = achar_cabecalho(bruto, de_para)
        d = d.rename(columns={c: de_para[chave(c)] for c in d.columns if chave(c) in de_para})
        entrou = len(d)
        faltam = [c for c in ["data", "campanha", "investimento"] if c not in d.columns]
        if faltam:
            print(f"{arq.name}: faltam as colunas {faltam}; acrescente em de_para_colunas.csv. Arquivo ignorado.")
            continue
        total = d["data"].astype(str).str.strip().str.lower().str.startswith("total") | d["campanha"].astype(str).str.strip().str.lower().eq("total")
        d = d[~total]
        d["data"], formato = datas(d["data"])
        sem_data = int(d["data"].isna().sum())
        d = d[d["data"].notna()]
        d["canal"] = d["canal"] if "canal" in d.columns else canal_do_arquivo(arq, forcados)
        for c in ["investimento", "impressoes", "cliques"]:
            d[c] = d[c].map(numero) if c in d.columns else float("nan")
        antes = len(d)
        d = d[PADRAO].drop_duplicates()
        print(f"{arq.name}: {entrou} linhas depois do cabeçalho (linha {linha_cab + 1}); "
              f"{int(total.sum())} de total, {sem_data} sem data, {antes - len(d)} repetidas removidas; "
              f"datas {formato}; {len(d)} linhas ficaram")
        if not d["canal"].astype(bool).all():
            print(f"   atenção: não sei o canal de {arq.name}; use --canal {arq.name}=Canal")
        partes.append(d)
    if not partes:
        raise SystemExit("nenhum arquivo de mídia lido")
    m = pd.concat(partes)
    m["data"] = m["data"].dt.date
    m = m.groupby(["data", "canal", "campanha"], as_index=False)[["investimento", "impressoes", "cliques"]].sum(min_count=1)

    if a.leads:
        bruto = ler_bruto(a.leads)
        l, _ = achar_cabecalho(bruto, de_para)
        l = l.rename(columns={c: de_para[chave(c)] for c in l.columns if chave(c) in de_para})
        l["data"], _ = datas(l["data"])
        l["k"] = l["campanha"].map(chave)
        n_leads = len(l)
        l = l.groupby([l["data"].dt.date, "k"]).size().rename("leads").reset_index()
        m["k"] = m["campanha"].map(chave)
        m = m.merge(l, on=["data", "k"], how="left")
        ligados = int(m["leads"].sum())
        m["leads"] = m["leads"].fillna(0).astype(int)
        sem_par = sorted(set(l["k"]) - set(m["k"]))
        print(f"{a.leads.name}: {n_leads} leads; {ligados} ligados a uma campanha de mídia; "
              f"{n_leads - ligados} sem campanha correspondente" + (f" ({', '.join(sem_par[:5])})" if sem_par else ""))
        m = m.drop(columns="k")

    m.sort_values(["data", "canal", "campanha"]).to_csv(a.saida, index=False, encoding="utf-8-sig")
    print(f"\n{len(m)} linhas (dia x canal x campanha) em {a.saida}")
    resumo = m.groupby("canal")[[c for c in ["investimento", "impressoes", "cliques", "leads"] if c in m.columns]].sum()
    print(resumo.round(2).to_string())


if __name__ == "__main__":
    main()
