# Skill regressao-explicativa

**O que faz:** explica uma métrica (nota, venda, NPS, conversão) a partir de
outras colunas com uma regressão linear, e recusa as colunas que nascem depois
do desfecho (o vazamento do estúdio 3). Diz quantas linhas saíram por vazio,
dá coeficientes com unidade e intervalo, padronizados para comparar, R² e
validação no tempo, com uma leitura em linguagem simples.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip. Ou, numa conversa no modo Work: "crie esta habilidade a partir deste
zip".

**Como adaptar:** monte o `momentos.csv` da sua base uma vez (quando cada
coluna passa a existir em relação ao desfecho) e guarde junto com os dados:
toda análise nova parte dele.

**Pedido de exemplo:** "Em `lojas.csv`, quero saber o que mais pesa nas vendas
semanais de cada loja: preço, promoção, clima e fluxo de pessoas. Use a
habilidade regressao-explicativa."
