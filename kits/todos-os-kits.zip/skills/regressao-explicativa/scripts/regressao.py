"""Regressão linear explicativa, com as checagens que evitam as armadilhas mais comuns.

Uso:
    python regressao.py DADOS.csv --y nota_media --x atraso_chegada_min conexoes_perdidas_pct empresa \
        --momento atraso_chegada_min=durante conexoes_perdidas_pct=durante empresa=antes \
        [--momentos momentos.csv] [--data data --corte 2026-07-31] [--filtro "empresa == 'TAP'"] [--saida regressao]

Checagens:
  - toda variável explicativa precisa ter um momento (antes, durante, junto ou
    depois do desfecho); as de "junto" e "depois" são recusadas, porque são
    consequência do desfecho, e não causa (o vazamento do estúdio 3);
  - linhas com vazio em y ou em algum x são descartadas, e o script diz quantas;
  - categóricas viram colunas 0/1, com a categoria de referência dita na tela.
Saída: SAIDA.md (leitura em linguagem simples) e SAIDA_coeficientes.csv, com
coeficiente na unidade da coluna, intervalo de 95%, p-valor e coeficiente
padronizado (o efeito de um desvio padrão, para comparar colunas de escalas
diferentes). Com --data, valida no tempo: ajusta até --corte (ou até 70% do
período) e mede o R² nos meses seguintes.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import pandas as pd
import statsmodels.api as sm

ACEITOS, RECUSADOS = {"antes", "durante"}, {"junto", "depois"}


def br(x, casas=2):
    return f"{x:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def matriz(d: pd.DataFrame, xs: list[str]):
    cats = [c for c in xs if not pd.api.types.is_numeric_dtype(d[c])]
    refs = {c: sorted(d[c].dropna().astype(str).unique())[0] for c in cats}
    X = pd.get_dummies(d[xs].astype({c: str for c in cats}), columns=cats, drop_first=True, dtype=float)
    return sm.add_constant(X, has_constant="add"), refs


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("dados", type=Path)
    p.add_argument("--y", required=True)
    p.add_argument("--x", nargs="+", required=True)
    p.add_argument("--momento", nargs="*", default=[], help="coluna=antes|durante|junto|depois")
    p.add_argument("--momentos", type=Path, help="CSV com colunas coluna,momento")
    p.add_argument("--data")
    p.add_argument("--corte")
    p.add_argument("--filtro", help='expressão do pandas, ex.: "empresa == \'TAP\'"')
    p.add_argument("--saida", default="regressao")
    a = p.parse_args()

    mom = {}
    if a.momentos:
        m = pd.read_csv(a.momentos)
        mom.update(dict(zip(m["coluna"], m["momento"].str.strip().str.lower())))
    mom.update({k: v.lower() for k, v in (s.split("=", 1) for s in a.momento)})
    sem = [c for c in a.x if c not in mom]
    if sem:
        raise SystemExit(f"PAROU: estas colunas não têm momento: {', '.join(sem)}. Pergunte ao usuário quando cada uma "
                         "passa a existir em relação ao desfecho (antes, durante, junto ou depois) e rode de novo.")
    ruins = [c for c in a.x if mom[c] in RECUSADOS]
    if ruins:
        raise SystemExit(f"PAROU: {', '.join(f'{c} ({mom[c]})' for c in ruins)} nascem junto ou depois de {a.y}: "
                         "são consequência do desfecho e não podem explicá-lo. Tire do modelo.")
    estranhos = [c for c in a.x if mom[c] not in ACEITOS]
    if estranhos:
        raise SystemExit(f"PAROU: momento desconhecido em {', '.join(estranhos)}. Use antes, durante, junto ou depois.")

    d = pd.read_csv(a.dados, low_memory=False)
    n0 = len(d)
    if a.filtro:
        d = d.query(a.filtro)
        print(f"{n0} linhas lidas; {len(d)} depois do filtro {a.filtro}")
        n0 = len(d)
    cols = [a.y] + a.x + ([a.data] if a.data else [])
    vazias = d[cols].isna().any(axis=1)
    d = d[~vazias].copy()
    print(f"{n0} linhas; {int(vazias.sum())} descartadas por vazio em {a.y} ou nas explicativas; {len(d)} no modelo")

    X, refs = matriz(d, a.x)
    for c, r in refs.items():
        print(f"{c}: categoria de referência = {r} (os coeficientes comparam cada categoria com ela)")
    y = d[a.y].astype(float)
    mod = sm.OLS(y, X).fit()
    ic = mod.conf_int()
    sdy = y.std()
    linhas = []
    for c in X.columns.drop("const"):
        pad = mod.params[c] * X[c].std() / sdy
        linhas.append({"variavel": c, "coeficiente": mod.params[c], "ic95_inf": ic.loc[c, 0], "ic95_sup": ic.loc[c, 1],
                       "p_valor": mod.pvalues[c], "padronizado": pad})
    co = pd.DataFrame(linhas).sort_values("padronizado", key=abs, ascending=False)
    co.round(4).to_csv(f"{a.saida}_coeficientes.csv", index=False)

    md = [f"# Regressão de {a.y}", "",
          f"- {len(d)} linhas no modelo ({int(vazias.sum())} descartadas por vazio).",
          f"- R² = {br(mod.rsquared)}: o modelo explica {mod.rsquared:.0%} da variação de {a.y}.",
          f"- Variáveis (todas existem antes ou durante o desfecho): {', '.join(a.x)}.", ""]
    if refs:
        md += [f"- Categorias de referência: " + "; ".join(f"{c} = {r}" for c, r in refs.items()), ""]
    md += ["## O que cada variável faz, comparando casos parecidos nas outras", "",
           "| variável | coeficiente | intervalo de 95% | padronizado |", "|---|---|---|---|"]
    md += [f"| {r.variavel} | {br(r.coeficiente, 3)} | {br(r.ic95_inf, 3)} a {br(r.ic95_sup, 3)} | {br(r.padronizado)} |"
           for r in co.itertuples()]
    md += ["", "## Leitura em linguagem simples", ""]
    for r in co.head(3).itertuples():
        sinal = "a mais" if r.coeficiente > 0 else "a menos"
        incerto = " (o intervalo cruza o zero: não dá para afirmar o sinal)" if r.ic95_inf < 0 < r.ic95_sup else ""
        md.append(f"- Cada unidade a mais de **{r.variavel}** vem com {br(abs(r.coeficiente), 3)} de {a.y} {sinal}, "
                  f"comparando casos parecidos nas outras colunas{incerto}.")
    md += ["- O padronizado compara colunas de escalas diferentes: quanto maior em módulo, mais a variável pesa.",
           "- Coeficiente é associação controlada, e não prova de causa: o que não está no modelo pode explicar parte."]

    if a.data:
        dt = pd.to_datetime(d[a.data])
        corte = pd.Timestamp(a.corte) if a.corte else dt.quantile(0.7)
        tr, te = dt <= corte, dt > corte
        if te.sum() > 10 and tr.sum() > 10:
            m2 = sm.OLS(y[tr], X[tr]).fit()
            prev = m2.predict(X[te])
            r2t = 1 - ((y[te] - prev) ** 2).sum() / ((y[te] - y[te].mean()) ** 2).sum()
            md += ["", "## Validação no tempo", "",
                   f"- Ajustado com {int(tr.sum())} linhas até {corte:%d/%m/%Y}; testado em {int(te.sum())} linhas depois.",
                   f"- R² no período de teste: {br(r2t)} (no ajuste: {br(m2.rsquared)}). Se cair muito, o modelo não se sustenta."]
            print(f"validação no tempo: R² {br(m2.rsquared)} no treino, {br(r2t)} no teste (depois de {corte:%d/%m/%Y})")
    Path(f"{a.saida}.md").write_text("\n".join(md), encoding="utf-8")
    print(f"R² {br(mod.rsquared)}")
    print(co.round(3).to_string(index=False))
    print(f"gravado: {a.saida}.md e {a.saida}_coeficientes.csv")


if __name__ == "__main__":
    main()
