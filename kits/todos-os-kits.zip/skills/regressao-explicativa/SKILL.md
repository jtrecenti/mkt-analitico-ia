---
name: regressao-explicativa
description: Roda uma regressão linear para explicar uma métrica (nota, venda, NPS, conversão, cancelamento) a partir de outras colunas, com checagens que evitam as armadilhas comuns: pergunta quando cada variável passa a existir e recusa as que nascem depois do desfecho, diz quantas linhas saíram por vazio, compara cada categoria com uma referência, dá coeficientes com unidade e intervalo, padronizados para comparar, R² e validação no tempo. Use quando pedirem "o que mais pesa", "o que explica", fatores, drivers ou regressão.
---

# Regressão explicativa

**O script ajusta e checa; você explica.** Coeficientes, intervalos e R² saem
do script. Você conduz as perguntas de antes e traduz a leitura para o negócio.

Precisa de `pandas`, `numpy` e `statsmodels` (`pip install pandas statsmodels`).

## Passo 1: o desfecho e o momento de cada variável

1. Qual é o desfecho (a coluna que se quer explicar)? Em que momento ele é
   medido?
2. Para **cada** coluna candidata, pergunte ao usuário quando ela passa a
   existir em relação ao desfecho: **antes**, **durante**, **junto** ou
   **depois**. Confira com as datas da base, e não só com o nome da coluna.
3. Explique por que importa: uma coluna que nasce depois do desfecho é
   consequência dele (as reclamações dos 7 dias seguintes a uma nota baixa,
   por exemplo). Com ela, o R² sobe e a recomendação fica circular. O script
   recusa essas colunas.

Grave as respostas num `momentos.csv` (colunas `coluna,momento`) para reusar.

## Passo 2: rodar

```bash
python scripts/regressao.py DADOS.csv --y DESFECHO --x COL1 COL2 COL3 --momentos momentos.csv \
    [--filtro "empresa == 'TAP'"] [--data COLUNA_DATA --corte 2026-07-31] --saida regressao
```

- Grupos muito diferentes (uma companhia internacional entre domésticas, uma
  loja de outro país): rode um modelo por grupo com `--filtro`.
- Com `--data`, o script valida no tempo: ajusta com o passado e mede o R² no
  período seguinte.

## Passo 3: ler para o usuário

1. Quantas linhas entraram e quantas saíram por vazio.
2. O R² em linguagem simples ("explica 74% da variação da nota").
3. As três variáveis que mais pesam (pelo padronizado), cada uma com o
   coeficiente na unidade dela ("cada ponto percentual a mais de conexões
   perdidas vem com 0,05 ponto a menos de nota, comparando voos parecidos").
4. Variáveis com intervalo que cruza o zero: não dá para afirmar o sinal.
5. Se houver validação no tempo, compare o R² do teste com o do ajuste.
6. O cuidado: coeficiente é associação controlada pelas colunas do modelo, e
   não prova de causa.

## Regras

- Nunca tire uma coluna de "depois" da lista de recusadas para o R² subir.
- Duas colunas que andam juntas (correlação acima de 0,7): explique que o
  modelo separa o efeito de cada uma só nos casos em que elas não andam juntas.
- Nenhum dado pessoal nos arquivos de saída.
