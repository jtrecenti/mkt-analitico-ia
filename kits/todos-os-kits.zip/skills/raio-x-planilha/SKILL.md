---
name: raio-x-planilha
description: Faz o raio-x de planilhas CSV ou Excel antes de qualquer análise. Conta linhas, colunas, vazios, duplicatas e linhas de total, sugere o tipo de cada variável e aponta problemas como número guardado como texto e data no formato americano. Use quando o usuário enviar uma planilha e pedir para "olhar", "entender", "conferir", "limpar" ou "analisar" os dados, ou antes de somar, cruzar ou fazer gráficos.
---

# Raio-x da planilha

Antes de somar, cruzar ou desenhar qualquer coisa, descubra o que a planilha
realmente tem. Esta habilidade divide o trabalho em duas partes: **o script
conta, você interpreta**.

## Passo 1: rodar o script

Rode, com todos os arquivos que o usuário enviou:

```bash
python scripts/raio_x.py ARQUIVO1 ARQUIVO2 ... --saida raio_x.md
```

O script precisa só de `pandas` e `openpyxl`. Se faltar algum, instale com
`pip install pandas openpyxl` e rode de novo. Não reescreva a contagem à mão:
os números do relatório vêm do script.

## Passo 2: interpretar

Com o relatório na mão, responda ao usuário em português, em linguagem simples:

1. **Uma frase por arquivo**: o que é cada linha (um dia? uma campanha? um lead?).
2. **Tipo de cada variável**, usando estas quatro categorias:
   - categórica **nominal**: categorias sem ordem (canal, campanha, estado);
   - categórica **ordinal**: categorias com ordem (estágio do funil, faixa etária, nota de 1 a 5);
   - numérica **discreta**: contagem (cliques, leads, dias);
   - numérica **contínua**: medida que admite frações (custo, valor, taxa).
   O script não sabe se uma categoria tem ordem. Decida você e diga qual é a ordem.
3. **Problemas que mudam o resultado**, do mais grave para o menos grave:
   linha de total (soma em dobro), duplicatas, número como texto, datas no
   formato americano, colunas com muitos vazios. Para cada um, diga o que
   acontece se ninguém corrigir (por exemplo: "o investimento total sai em dobro").
4. **O que dá para cruzar**: quais colunas ligam um arquivo ao outro (nome de
   campanha, data) e se os nomes batem ou precisam de uma tabela de/para.

## Regras

- Não corrija nada sem avisar. Primeiro mostre o problema; corrija só se o
  usuário pedir, gerando um arquivo novo (nunca sobrescreva o original).
- Ao final, entregue o arquivo `raio_x.md` gerado pelo script.
