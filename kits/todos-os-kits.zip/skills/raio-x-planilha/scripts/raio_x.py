"""Raio-x de uma planilha (CSV ou Excel): o que tem dentro, antes de qualquer análise.

Uso:
    python raio_x.py ARQUIVO [ARQUIVO ...] [--saida raio_x.md]

Para cada arquivo, o script descobre sozinho o separador, a codificação e a
linha do cabeçalho, e relata:
- quantas linhas e colunas, linhas duplicadas e linhas que parecem total;
- para cada coluna: tipo sugerido, vazios, valores distintos, exemplos e,
  se for número, mínimo, mediana e máximo;
- problemas típicos: número guardado como texto ("R$ 1.234,56"), datas em
  texto, colunas vazias.

O script só conta. Decidir se uma categoria tem ordem (ordinal) ou não
(nominal), e se um problema importa, é trabalho de quem lê o relatório.
"""
from __future__ import annotations

import argparse
import csv
import io
import re
import sys
from pathlib import Path

import pandas as pd

TEXTO_NUMERO = re.compile(r"^\s*-?\s*(R\$)?\s*-?[\d.]+(,\d+)?\s*%?\s*$")
PALAVRAS_TOTAL = re.compile(r"^\s*(total|subtotal|soma|geral)\b", re.I)


def ler_texto(caminho: Path) -> tuple[str, str]:
    bruto = caminho.read_bytes()
    for cod in ("utf-8-sig", "latin-1"):
        try:
            return bruto.decode(cod), cod
        except UnicodeDecodeError:
            continue
    return bruto.decode("utf-8", errors="replace"), "utf-8 (com erros)"


def ler_csv(caminho: Path) -> tuple[pd.DataFrame, list[str]]:
    texto, cod = ler_texto(caminho)
    try:
        sep = csv.Sniffer().sniff(texto[:5000], delimiters=",;\t|").delimiter
    except csv.Error:
        sep = ","
    nomes = {",": "vírgula", ";": "ponto e vírgula", "\t": "tabulação", "|": "barra vertical"}
    df = pd.read_csv(io.StringIO(texto), sep=sep, dtype=str, keep_default_na=False)
    return df, [f"codificação {cod}", f"separador {nomes.get(sep, sep)}"]


def ler_excel(caminho: Path) -> tuple[pd.DataFrame, list[str]]:
    bruto = pd.read_excel(caminho, header=None, dtype=str).fillna("")
    # cabeçalho = primeira linha em que pelo menos metade das colunas está preenchida
    cheias = (bruto != "").sum(axis=1)
    linha = int((cheias >= max(2, bruto.shape[1] // 2)).idxmax())
    df = bruto.iloc[linha + 1:].reset_index(drop=True)
    df.columns = [str(c).strip() or f"coluna_{i + 1}" for i, c in enumerate(bruto.iloc[linha])]
    obs = [f"aba lida: a primeira ({pd.ExcelFile(caminho).sheet_names[0]})"]
    if linha > 0:
        obs.append(f"as {linha} primeiras linhas eram título, não dados: o cabeçalho está na linha {linha + 1}")
    return df, obs


def para_numero(s: pd.Series) -> pd.Series:
    limpo = (s.str.replace("R$", "", regex=False).str.replace("%", "", regex=False)
             .str.replace(r"\s", "", regex=True))
    # padrão brasileiro (1.234,56) quando há vírgula decimal
    br = limpo.str.contains(",", regex=False)
    limpo = limpo.where(~br, limpo.str.replace(".", "", regex=False).str.replace(",", ".", regex=False))
    return pd.to_numeric(limpo, errors="coerce")


def descrever_coluna(nome: str, s: pd.Series) -> dict:
    s = s.astype(str).str.strip()
    vazio = s.isin(["", "nan", "NaN", "None", "-"])
    v = s[~vazio]
    info = {"coluna": nome, "vazios": int(vazio.sum()), "distintos": int(v.nunique()), "alertas": []}
    if v.empty:
        info.update(tipo="vazia", exemplos="")
        return info
    info["exemplos"] = ", ".join(v.value_counts().index[:4].tolist())
    num = para_numero(v)
    # dd/mm/aaaa ou mm/dd/aaaa? Se o segundo número passa de 12, é mês/dia (americano)
    barra = v.str.match(r"^\d{1,2}/\d{1,2}/\d{4}").all()
    americana = barra and (pd.to_numeric(v.str.split("/").str[1], errors="coerce") > 12).any()
    datas = pd.to_datetime(v, errors="coerce", dayfirst=not americana, format="mixed")
    if americana and datas.notna().mean() > 0.95:
        info["alertas"].append("datas no formato americano (mês/dia/ano): 10/02 é 2 de outubro, não 10 de fevereiro")
    if num.notna().mean() > 0.95:
        if v.str.contains(r"R\$|,\d", regex=True).any():
            info["alertas"].append("número guardado como texto (R$ ou vírgula decimal): converter antes de somar")
        inteiro = (num.dropna() % 1 == 0).all()
        if info["distintos"] <= 12 and inteiro:
            info["tipo"] = "numérica discreta (poucos valores: pode ser categoria codificada)"
        else:
            info["tipo"] = "numérica discreta" if inteiro else "numérica contínua"
        info.update(minimo=num.min(), mediana=num.median(), maximo=num.max())
    elif datas.notna().mean() > 0.95:
        info["tipo"] = "data"
        info.update(minimo=datas.min().date(), maximo=datas.max().date())
    elif info["distintos"] == 2:
        info["tipo"] = "categórica binária (dois valores, como sim/não)"
    elif info["distintos"] == len(v) and len(v) > 20:
        info["tipo"] = "identificador (um valor por linha)"
    elif v.str.len().median() > 60:
        info["tipo"] = "texto livre"
    else:
        info["tipo"] = "categórica (nominal ou ordinal: decida pela ordem das categorias)"
    if info["vazios"] / len(s) > 0.3:
        info["alertas"].append(f"{info['vazios'] / len(s):.0%} vazia")
    return info


def raio_x(caminho: Path) -> str:
    leitor = ler_excel if caminho.suffix.lower() in {".xlsx", ".xls"} else ler_csv
    df, obs = leitor(caminho)
    linhas = [f"## {caminho.name}", ""]
    total = df.apply(lambda r: any(PALAVRAS_TOTAL.match(str(x)) for x in r), axis=1)
    dup = df.duplicated()
    linhas += [f"- {len(df)} linhas e {df.shape[1]} colunas", *[f"- {o}" for o in obs]]
    if dup.any():
        linhas.append(f"- **{int(dup.sum())} linhas duplicadas** (idênticas a uma linha anterior): linhas "
                      + ", ".join(str(i + 2) for i in df.index[dup][:10]))
    if total.any():
        linhas.append(f"- **{int(total.sum())} linha(s) parecem total ou subtotal**: somar a coluna conta duas vezes")
    linhas += ["", "| coluna | tipo sugerido | vazios | distintos | exemplos | mín. | mediana | máx. |",
               "|---|---|---|---|---|---|---|---|"]
    alertas = []
    for c in df.columns:
        i = descrever_coluna(c, df[c])
        fmt = lambda x: "" if x is None else (f"{x:.2f}".rstrip("0").rstrip(".") if isinstance(x, float) else str(x))
        linhas.append(f"| {c} | {i['tipo']} | {i['vazios']} | {i['distintos']} | {i['exemplos'][:60].replace("|", "/")} | "
                      f"{fmt(i.get('minimo'))} | {fmt(i.get('mediana'))} | {fmt(i.get('maximo'))} |")
        alertas += [f"- `{c}`: {a}" for a in i["alertas"]]
    if alertas:
        linhas += ["", "**Alertas**", "", *alertas]
    return "\n".join(linhas) + "\n"


def main() -> None:
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("arquivos", nargs="+", type=Path)
    p.add_argument("--saida", type=Path, default=Path("raio_x.md"))
    a = p.parse_args()
    partes = ["# Raio-x das planilhas", ""]
    for arq in a.arquivos:
        try:
            partes.append(raio_x(arq))
        except Exception as e:  # um arquivo ruim não derruba os outros
            partes.append(f"## {arq.name}\n\nNão consegui ler: {e}\n")
    texto = "\n".join(partes)
    a.saida.write_text(texto, encoding="utf-8")
    sys.stdout.reconfigure(encoding="utf-8")
    print(texto)
    print(f"(relatório salvo em {a.saida})")


if __name__ == "__main__":
    main()
