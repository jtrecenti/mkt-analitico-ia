---
name: avaliacoes-app
description: Baixa as avaliações mais recentes de um aplicativo na App Store do Brasil (nota, título, texto, data e versão; sem o nome de quem avaliou) e monta um CSV. Use quando pedirem avaliações, reviews ou comentários de usuários de um aplicativo de iPhone.
---

# Baixar avaliações da App Store

## Como usar

1. Descubra o número do aplicativo: é o que vem depois de `id` no endereço da
   página na App Store (`apps.apple.com/br/app/tap-air-portugal/id440497198`).
   Já estão no script: LATAM, GOL, Azul e TAP.
2. Baixe:

   ```bash
   python scripts/baixar_avaliacoes.py TAP --saida avaliacoes_tap.csv
   python scripts/baixar_avaliacoes.py --id 440497198 --saida outro_app.csv
   ```

3. Responda com o que o script imprimiu: quantas avaliações, de que data a que
   data, a nota média.

## O que saber

- O feed público da Apple devolve no máximo 10 páginas de 50 avaliações, as
  mais recentes primeiro: até 500 por aplicativo e país. Não é uma amostra
  aleatória: são as últimas. Num aplicativo com poucas avaliações, 500 podem
  cobrir anos; num muito avaliado, poucas semanas.
- Quem escreve na App Store está falando, antes de tudo, do aplicativo. Para
  saber do voo, a fonte é outra (sentenças, SAC, pesquisa pós-voo).
- O feed traz o apelido de quem avaliou, às vezes um e-mail. O script não
  guarda: não mude isso.

## Regras

- Uma página por vez, com pausa de 1 segundo.
- Não publique o texto das avaliações com apelidos ou e-mails.
