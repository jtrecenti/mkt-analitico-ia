"""Baixa as avaliações mais recentes de um aplicativo na App Store do Brasil.

Uso:
    python baixar_avaliacoes.py TAP --saida avaliacoes_tap.csv
    python baixar_avaliacoes.py LATAM GOL Azul TAP --saida avaliacoes.csv
    python baixar_avaliacoes.py --id 1497908631 --saida latam.csv

Usa o feed público de avaliações da Apple (RSS em JSON). Ele devolve até 10
páginas de 50 avaliações, as mais recentes primeiro: no máximo 500 por
aplicativo. Cada avaliação vem com nota (1 a 5), título, texto, data e versão
do aplicativo. As páginas baixadas ficam em brutos_app/ (elas trazem o apelido
de quem avaliou: não publique essa pasta). O CSV não guarda o apelido.
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

import pandas as pd
import requests

APPS = {"LATAM": 1497908631, "GOL": 337961662, "Azul": 690105616, "TAP": 440497198}
FEED = "https://itunes.apple.com/br/rss/customerreviews/page={p}/id={app}/sortby=mostrecent/json"


def baixar(nome: str, app: int, pasta: Path) -> list[dict]:
    linhas = []
    pasta.mkdir(parents=True, exist_ok=True)
    for p in range(1, 11):
        bruto = pasta / f"{nome}_pagina_{p:02d}.json"  # o bruto fica em disco: dá para ler de novo sem baixar
        if bruto.exists():
            texto = bruto.read_text(encoding="utf-8")
        else:
            r = requests.get(FEED.format(p=p, app=app), timeout=30)
            if not r.ok:
                print(f"{nome} página {p}: erro {r.status_code}; parei. Rode de novo para retomar.")
                break
            texto = r.text
            bruto.write_text(texto, encoding="utf-8")
            time.sleep(1)
        entradas = [e for e in json.loads(texto).get("feed", {}).get("entry", []) if "im:rating" in e]
        if not entradas:
            break
        for e in entradas:
            linhas.append({"empresa": nome, "id_avaliacao": e["id"]["label"], "data": e["updated"]["label"][:10],
                           "nota": int(e["im:rating"]["label"]), "versao_app": e.get("im:version", {}).get("label"),
                           "titulo": e["title"]["label"], "texto": e["content"]["label"]})
    print(f"{nome}: {len(linhas)} avaliações, de {min(l['data'] for l in linhas)} a {max(l['data'] for l in linhas)}")
    return linhas


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("empresas", nargs="*", default=list(APPS))
    p.add_argument("--id", type=int, help="id de outro aplicativo na App Store")
    p.add_argument("--saida", type=Path, default=Path("avaliacoes.csv"))
    p.add_argument("--pasta", type=Path, default=Path("brutos_app"), help="onde guardar as páginas baixadas")
    a = p.parse_args()
    alvos = {f"app_{a.id}": a.id} if a.id else {e: APPS[e] for e in a.empresas}
    d = pd.DataFrame([l for n, app in alvos.items() for l in baixar(n, app, a.pasta)])
    d = d.drop_duplicates("id_avaliacao")
    d.to_csv(a.saida, index=False, encoding="utf-8-sig")
    print(f"\n{len(d)} avaliações em {a.saida}")
    print(d.groupby("empresa")["nota"].agg(["count", "mean"]).round(2).to_string())


if __name__ == "__main__":
    main()
