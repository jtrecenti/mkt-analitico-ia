# Skill segmentacao-clusters

**O que faz:** divide uma base em segmentos de linhas parecidas (k-means), com
o número de grupos escolhido pela silhueta e pelo cotovelo, e descreve cada
segmento: tamanho, médias, o que o distingue e um nome sugerido. Sai um CSV com
a coluna "segmento", o perfil, um relatório e o gráfico da escolha do k.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip. Ou, numa conversa no modo Work: "crie esta habilidade a partir deste
zip".

**Como adaptar:** troque as colunas pelo que importa para a sua decisão
(frequência de compra, ticket médio, tempo de casa, canal) e fixe o `--k` no
número de segmentos que o time consegue atender.

**Pedido de exemplo:** "Com `clientes.csv`, quero segmentar por frequência de
compra, ticket médio e dias desde a última compra, para planejar a régua de
e-mails. Use a habilidade segmentacao-clusters."
