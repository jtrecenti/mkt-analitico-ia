---
name: segmentacao-clusters
description: Segmenta clientes, produtos, lojas, campanhas ou qualquer linha de uma planilha em grupos parecidos com k-means, escolhendo o número de grupos pela silhueta e pelo cotovelo, e descreve o perfil de cada segmento (tamanho, médias e o que o distingue da base), com nomes sugeridos. Use quando pedirem segmentação, clusters, agrupamento, personas a partir de dados ou "tipos de cliente".
---

# Segmentação com clusters

**O script agrupa e mede; você nomeia e explica.** Os números do perfil saem
do script. Os nomes dos segmentos são sugestões suas, a partir do perfil, e o
usuário confirma.

Precisa de `pandas`, `scikit-learn` e `matplotlib`
(`pip install pandas scikit-learn matplotlib`).

## Passo 1: escolher as colunas com o usuário

Pergunte **para que** é a segmentação (comunicação, oferta, prioridade de
visita) e escolha 3 a 8 colunas que fazem sentido para essa decisão. Cuidados:

- Não use identificadores (código do cliente, CPF, CEP) nem colunas de texto.
- Colunas muito parecidas entre si (preço e distância, por exemplo) contam o
  mesmo duas vezes: escolha uma.
- Uma coluna categórica (região, companhia) vira colunas 0/1 e costuma dominar:
  os segmentos viram as próprias categorias. Prefira segmentar dentro de cada
  categoria ou deixá-la de fora e cruzar depois.

## Passo 2: rodar

```bash
python scripts/segmentar.py DADOS.csv --colunas COL1 COL2 COL3 --kmin 2 --kmax 8 --saida segmentos
```

O script tira linhas com vazio (e diz quantas), padroniza as colunas, testa os
k e usa o de maior silhueta. Para forçar um k (por exemplo, o time só consegue
trabalhar com 4 segmentos), use `--k 4`.

## Passo 3: apresentar

1. Quantas linhas entraram e quantos segmentos, com a silhueta em linguagem
   simples (acima de 0,25: alguma separação; acima de 0,5: grupos bem claros).
2. Para cada segmento: tamanho, o que o distingue (do relatório) e um nome
   curto sugerido ("viajantes de longa distância, mais caros e menos
   satisfeitos").
3. Uma ação possível por segmento, ligada à decisão do Passo 1.
4. O cuidado: segmento descreve quem se parece com quem. Ele **não é causa**:
   não diz por que o grupo é assim nem o que acontece se algo mudar.

## Regras

- Semente fixa: rodar de novo com as mesmas colunas e o mesmo k dá o mesmo
  resultado. Registre as colunas e o k usados.
- Nenhum dado pessoal no relatório. O CSV de saída mantém as colunas da base:
  se houver nome ou e-mail, avise antes de compartilhar.
