"""Segmentação com k-means: grupos de linhas parecidas nas colunas escolhidas.

Uso:
    python segmentar.py DADOS.csv --colunas col1 col2 col3 [--k 4] [--kmin 2 --kmax 8] [--id coluna_id] [--saida segmentos]

Passos: lê só as colunas escolhidas (numéricas; categóricas viram 0/1), tira
as linhas com vazio (e diz quantas), padroniza (cada coluna com média 0 e
desvio 1, para nenhuma pesar mais só pela escala), testa k de kmin a kmax
(silhueta e cotovelo) e, sem --k, usa o k com a melhor silhueta. Grava:
  SAIDA.csv            a base original com a coluna "segmento"
  SAIDA_perfil.csv     média de cada coluna por segmento e tamanho
  SAIDA_relatorio.md   escolha do k, perfil e diferenças de cada segmento
  SAIDA_k.png          silhueta e cotovelo por k
A semente é fixa: rodar de novo dá os mesmos segmentos.
"""
from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
from sklearn.preprocessing import StandardScaler


def br(x, casas=2):
    return f"{x:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("dados", type=Path)
    p.add_argument("--colunas", nargs="+", required=True)
    p.add_argument("--k", type=int)
    p.add_argument("--kmin", type=int, default=2)
    p.add_argument("--kmax", type=int, default=8)
    p.add_argument("--id")
    p.add_argument("--saida", default="segmentos")
    p.add_argument("--amostra-silhueta", type=int, default=5000)
    a = p.parse_args()

    d = pd.read_csv(a.dados, low_memory=False)
    n0 = len(d)
    x = d[a.colunas].copy()
    cats = [c for c in a.colunas if not pd.api.types.is_numeric_dtype(x[c])]
    x = pd.get_dummies(x, columns=cats, dtype=float)
    ok = x.notna().all(axis=1)
    print(f"{n0} linhas lidas; {int((~ok).sum())} com vazio nas colunas escolhidas ficaram de fora; {int(ok.sum())} entram")
    if cats:
        print(f"categóricas transformadas em colunas 0/1: {', '.join(cats)}")
    xz = StandardScaler().fit_transform(x[ok])

    rng = np.random.default_rng(1)
    idx = rng.choice(len(xz), min(a.amostra_silhueta, len(xz)), replace=False)
    testes = []
    for k in range(a.kmin, a.kmax + 1):
        km = KMeans(n_clusters=k, n_init=10, random_state=1).fit(xz)
        testes.append({"k": k, "silhueta": silhouette_score(xz[idx], km.labels_[idx]), "inercia": km.inertia_})
    t = pd.DataFrame(testes)
    k = a.k or int(t.loc[t["silhueta"].idxmax(), "k"])
    print("k testados (silhueta: quanto maior, mais separados os grupos):")
    print(t.round(3).to_string(index=False))
    print(f"k escolhido: {k}" + (" (informado)" if a.k else " (maior silhueta)"))

    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    ax[0].plot(t["k"], t["silhueta"], marker="o", color="#c8102e"); ax[0].set_title("Silhueta (maior é melhor)", loc="left")
    ax[1].plot(t["k"], t["inercia"], marker="o", color="#5b5b5b"); ax[1].set_title("Cotovelo (onde a queda desacelera)", loc="left")
    for e in ax:
        e.axvline(k, color="#c8102e", linestyle=":"); e.spines[["top", "right"]].set_visible(False)
    fig.savefig(f"{a.saida}_k.png", dpi=100, bbox_inches="tight"); plt.close(fig)

    km = KMeans(n_clusters=k, n_init=10, random_state=1).fit(xz)
    # segmentos numerados do maior para o menor
    ordem = pd.Series(km.labels_).value_counts().index
    rotulo = {c: i + 1 for i, c in enumerate(ordem)}
    seg = pd.Series(np.nan, index=d.index)
    seg[ok] = [rotulo[c] for c in km.labels_]
    d["segmento"] = seg.astype("Int64")
    d.to_csv(f"{a.saida}.csv", index=False)

    base = x[ok].assign(segmento=d.loc[ok, "segmento"].values)
    perfil = base.groupby("segmento").mean()
    perfil.insert(0, "tamanho", base.groupby("segmento").size())
    perfil.insert(1, "parcela", (perfil["tamanho"] / perfil["tamanho"].sum()).round(3))
    perfil.round(3).to_csv(f"{a.saida}_perfil.csv")
    geral, dp = x[ok].mean(), x[ok].std()

    md = [f"# Segmentação de {a.dados.name}", "",
          f"- {int(ok.sum())} linhas segmentadas de {n0} ({n0 - int(ok.sum())} fora por vazio).",
          f"- Colunas usadas: {', '.join(a.colunas)} (padronizadas).",
          f"- k = {k}; silhueta {br(t.set_index('k').loc[k, 'silhueta'])} (de -1 a 1; acima de 0,25 já há alguma separação).", "",
          "## Perfil de cada segmento", ""]
    for s, r in perfil.iterrows():
        z = ((r.drop(["tamanho", "parcela"]) - geral) / dp).sort_values()
        alto = [f"{c} mais alto ({br(r[c])} contra {br(geral[c])} na base)" for c in z.index[::-1][:3] if z[c] > 0.3]
        baixo = [f"{c} mais baixo ({br(r[c])} contra {br(geral[c])} na base)" for c in z.index[:3] if z[c] < -0.3]
        md += [f"### Segmento {s}: {int(r['tamanho'])} linhas ({r['parcela']:.0%})", "",
               "- O que o distingue: " + ("; ".join(alto + baixo) or "fica perto da média em tudo"), ""]
    md += ["## Leitura", "",
           "- Os nomes dos segmentos são uma sugestão a partir do perfil acima: confira com quem conhece o negócio.",
           "- Segmento descreve quem se parece com quem. Ele **não diz por que** os grupos são diferentes nem o que",
           "  acontece se você mudar uma coluna: para isso, compare casos parecidos (regressão) ou teste.",
           "- Mudar as colunas, a escala ou o k muda os segmentos. Registre a escolha para refazer igual."]
    Path(f"{a.saida}_relatorio.md").write_text("\n".join(md), encoding="utf-8")
    print(perfil.round(2).to_string())
    print(f"gravado: {a.saida}.csv, {a.saida}_perfil.csv, {a.saida}_relatorio.md, {a.saida}_k.png")


if __name__ == "__main__":
    main()
