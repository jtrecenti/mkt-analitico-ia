"""Gráficos para apresentação executiva, com as boas práticas embutidas.

Uso (linha de comando):
    python graficos.py DADOS.csv --x empresa --y nota_media --agregar media --destaque Gol \
        --titulo "A Gol tem a menor nota média" --fonte "Pesquisa pós-voo, jan a out de 2026" --saida nota_por_empresa
    python graficos.py DADOS.csv --x data --y nota_media --agregar media --tempo mes --saida nota_por_mes
    python graficos.py DADOS.csv --x atraso_chegada_min --y nota_media --saida atraso_nota

--tipo auto (padrão) escolhe pelo tipo das variáveis:
    categórica + numérica (ou só categórica)  -> barras ordenadas (ou boxplot com --tipo boxplot)
    data + numérica                           -> linha no tempo
    numérica + numérica                       -> dispersão
Saída: SAIDA.png (1920x1080) e SAIDA.svg. Sem título, o script sugere um que
conclui a partir dos dados (maior e menor), e mostra na tela.

As funções barras_ordenadas, linha_tempo, boxplot_grupos e dispersao também
podem ser importadas: from graficos import barras_ordenadas
"""
from __future__ import annotations

import argparse
import textwrap
import warnings
from datetime import date
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

DESTAQUE, CINZA, TEXTO, GRADE = "#c8102e", "#b9bcc2", "#1d1d1f", "#e6e7ea"


def _fig():
    plt.rcParams.update({"font.size": 22, "font.family": "DejaVu Sans", "axes.edgecolor": GRADE,
                         "axes.labelcolor": TEXTO, "xtick.color": TEXTO, "ytick.color": TEXTO})
    fig, ax = plt.subplots(figsize=(19.2, 10.8), dpi=100)
    for lado in ("top", "right", "left"):
        ax.spines[lado].set_visible(False)
    fig.subplots_adjust(left=0.08, right=0.95, top=0.77, bottom=0.14)
    return fig, ax


def _fechar(fig, titulo, subtitulo, fonte, saida):
    linhas = textwrap.wrap(titulo, 56)
    tam = 36 if len(linhas) == 1 else 32
    fig.text(0.08, 0.965, "\n".join(linhas[:2]), fontsize=tam, fontweight="bold", color=TEXTO, va="top",
             linespacing=1.15)
    if subtitulo:
        fig.text(0.08, 0.89 if len(linhas) == 1 else 0.835, subtitulo, fontsize=24, color="#555", va="top")
    rodape = f"Fonte: {fonte}" if fonte else "Fonte: informe a fonte com --fonte"
    fig.text(0.08, 0.035, f"{rodape} · gerado em {date.today():%d/%m/%Y}", fontsize=18, color="#777")
    saida = Path(saida)
    fig.savefig(saida.with_suffix(".png"), dpi=100)
    fig.savefig(saida.with_suffix(".svg"))
    plt.close(fig)
    print(f"gravado: {saida.with_suffix('.png')} e {saida.with_suffix('.svg')}")


def num(x, casas=1):
    return f"{x:,.{casas}f}".replace(",", "X").replace(".", ",").replace("X", ".")


def barras_ordenadas(valores: pd.Series, titulo, subtitulo="", fonte="", saida="grafico", destaque=None, casas=1):
    """Barras horizontais, da maior para a menor, com rótulo direto e uma cor de destaque."""
    v = valores.sort_values()
    fig, ax = _fig()
    alvo = destaque if destaque is not None else v.index[-1]
    cores = [DESTAQUE if str(i) == str(alvo) else CINZA for i in v.index]
    ax.barh([str(i) for i in v.index], v.values, color=cores, height=0.62)
    for i, x in enumerate(v.values):
        ax.text(x, i, "  " + num(x, casas), va="center", fontsize=24,
                fontweight="bold" if str(v.index[i]) == str(alvo) else "normal")
    ax.xaxis.set_visible(False)
    ax.tick_params(axis="y", length=0, labelsize=26)
    ax.set_xlim(0, v.max() * 1.15)
    _fechar(fig, titulo, subtitulo, fonte, saida)


def linha_tempo(serie: pd.Series, titulo, subtitulo="", fonte="", saida="grafico", destaque=None, casas=1):
    """Uma linha no tempo, com o ponto de destaque (por padrão, o último) rotulado."""
    s = serie.sort_index()
    fig, ax = _fig()
    ax.plot(range(len(s)), s.values, color=DESTAQUE, linewidth=4, marker="o", markersize=10)
    ax.set_xticks(range(len(s)), [str(i) for i in s.index], fontsize=20)
    k = len(s) - 1 if destaque is None else [str(i) for i in s.index].index(str(destaque))
    ax.annotate(num(s.values[k], casas), (k, s.values[k]), textcoords="offset points", xytext=(0, 18),
                ha="center", fontsize=26, fontweight="bold", color=DESTAQUE)
    ax.yaxis.grid(True, color=GRADE)
    ax.tick_params(length=0)
    _fechar(fig, titulo, subtitulo, fonte, saida)


def boxplot_grupos(df, grupo, valor, titulo, subtitulo="", fonte="", saida="grafico", destaque=None):
    """Uma caixa por grupo, ordenadas pela mediana, a do destaque em cor."""
    ordem = df.groupby(grupo)[valor].median().sort_values().index
    fig, ax = _fig()
    dados = [df.loc[df[grupo] == g, valor].dropna().values for g in ordem]
    b = ax.boxplot(dados, vert=False, patch_artist=True, widths=0.55, showfliers=False)
    alvo = destaque if destaque is not None else ordem[-1]
    for caixa, g in zip(b["boxes"], ordem):
        caixa.set(facecolor=DESTAQUE if str(g) == str(alvo) else CINZA, edgecolor="white")
    for m in b["medians"]:
        m.set(color=TEXTO, linewidth=3)
    ax.set_yticks(range(1, len(ordem) + 1), [str(g) for g in ordem], fontsize=26)
    ax.set_xlabel(valor)
    ax.xaxis.grid(True, color=GRADE)
    ax.tick_params(length=0)
    _fechar(fig, titulo, subtitulo, fonte, saida)


def dispersao(df, x, y, titulo, subtitulo="", fonte="", saida="grafico", reta=True):
    """Pontos discretos e, se reta=True, a reta da regressão simples com a inclinação escrita."""
    d = df[[x, y]].dropna()
    fig, ax = _fig()
    ax.scatter(d[x], d[y], s=18, color=CINZA, alpha=0.6, edgecolors="none")
    if reta and len(d) > 2:
        b, a = np.polyfit(d[x], d[y], 1)
        xs = np.linspace(d[x].min(), d[x].max(), 50)
        ax.plot(xs, a + b * xs, color=DESTAQUE, linewidth=4)
        xm = xs[int(len(xs) * 0.35)]
        ax.annotate(f"inclinação: {num(b, 3)} por unidade", (xm, a + b * xm), textcoords="offset points",
                    xytext=(10, 25), color=DESTAQUE, fontsize=22, fontweight="bold")
    ax.set_xlabel(x)
    ax.set_ylabel(y)
    ax.grid(True, color=GRADE)
    ax.tick_params(length=0)
    _fechar(fig, titulo, subtitulo, fonte, saida)


def _tipo(s: pd.Series) -> str:
    if pd.api.types.is_numeric_dtype(s):
        return "numerica" if s.nunique() > 12 else "categorica"
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        eh_data = pd.to_datetime(s, errors="coerce").notna().mean() > 0.9
    if eh_data:
        return "data"
    return "categorica"


def main():
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("dados", type=Path)
    p.add_argument("--x", required=True)
    p.add_argument("--y")
    p.add_argument("--tipo", default="auto", choices=["auto", "barras", "linha", "boxplot", "dispersao"])
    p.add_argument("--agregar", default="media", choices=["media", "soma", "contagem", "mediana"])
    p.add_argument("--tempo", default="mes", choices=["dia", "semana", "mes"], help="agrupamento da data")
    p.add_argument("--titulo")
    p.add_argument("--subtitulo", default="")
    p.add_argument("--fonte", default="")
    p.add_argument("--destaque")
    p.add_argument("--casas", type=int, default=1)
    p.add_argument("--saida", default="grafico")
    a = p.parse_args()
    df = pd.read_csv(a.dados)
    n0 = len(df)
    cols = [a.x] + ([a.y] if a.y else [])
    df = df.dropna(subset=cols)
    print(f"{n0} linhas lidas; {n0 - len(df)} sem valor em {', '.join(cols)} ficaram de fora; {len(df)} no gráfico")
    tx, ty = _tipo(df[a.x]), (_tipo(df[a.y]) if a.y else None)
    tipo = a.tipo
    if tipo == "auto":
        tipo = {"data": "linha", "numerica": "dispersao" if ty == "numerica" else "barras"}.get(tx, "barras")
    print(f"tipos: {a.x} = {tx}" + (f", {a.y} = {ty}" if a.y else "") + f"; gráfico: {tipo}")
    func = {"media": "mean", "soma": "sum", "contagem": "size", "mediana": "median"}[a.agregar]
    if tipo in ("barras", "linha"):
        chave = df[a.x]
        if tipo == "linha":
            dt = pd.to_datetime(chave)
            chave = dt.dt.to_period({"dia": "D", "semana": "W", "mes": "M"}[a.tempo]).astype(str)
        g = df.groupby(chave)
        v = g.size() if (a.agregar == "contagem" or not a.y) else getattr(g[a.y], func)()
        nome = {"media": "média", "soma": "soma", "mediana": "mediana", "contagem": "contagem"}[a.agregar]
        rot = "quantidade" if (a.agregar == "contagem" or not a.y) else f"{nome} de {a.y}"
        if tipo == "barras":
            titulo = a.titulo or f"{v.idxmax()} tem a maior {rot} ({num(v.max(), a.casas)}); {v.idxmin()}, a menor ({num(v.min(), a.casas)})"
            barras_ordenadas(v, titulo, a.subtitulo or rot, a.fonte, a.saida, a.destaque, a.casas)
        else:
            titulo = a.titulo or f"{rot.capitalize()} foi de {num(v.iloc[0], a.casas)} para {num(v.iloc[-1], a.casas)} no período"
            linha_tempo(v, titulo, a.subtitulo or rot, a.fonte, a.saida, a.destaque, a.casas)
    elif tipo == "boxplot":
        med = df.groupby(a.x)[a.y].median()
        titulo = a.titulo or f"{med.idxmax()} tem a maior mediana de {a.y}; {med.idxmin()}, a menor"
        boxplot_grupos(df, a.x, a.y, titulo, a.subtitulo, a.fonte, a.saida, a.destaque)
    else:
        r = df[[a.x, a.y]].corr().iloc[0, 1]
        titulo = a.titulo or f"Quanto maior {a.x}, {'maior' if r > 0 else 'menor'} {a.y} (correlação {num(r, 2)})"
        dispersao(df, a.x, a.y, titulo, a.subtitulo, a.fonte, a.saida)
    if not a.titulo:
        print(f"título sugerido (confira se é verdade e reescreva com a conclusão do negócio): {titulo}")


if __name__ == "__main__":
    main()
