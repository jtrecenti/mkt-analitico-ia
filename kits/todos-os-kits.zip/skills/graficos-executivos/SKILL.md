---
name: graficos-executivos
description: Faz gráficos prontos para apresentação executiva (PNG 1920x1080 e SVG) a partir de uma planilha, escolhendo o tipo certo pelo tipo das variáveis e aplicando boas práticas: título que conclui, barras ordenadas, uma cor de destaque e cinza no resto, rótulo direto em vez de legenda, fonte grande, fonte e data no rodapé, nada de pizza ou 3D. Use quando pedirem um gráfico para slide, relatório para a diretoria, apresentação ou e-mail executivo.
---

# Gráficos executivos

**O script desenha; você escolhe a mensagem.** Todo número do gráfico sai do
script. Você decide a pergunta, a conclusão do título e o que destacar.

Precisa de `pandas` e `matplotlib` (`pip install pandas matplotlib`).

## Passo 1: a pergunta e o tipo das variáveis

Antes de desenhar, diga em uma frase qual pergunta o gráfico responde. Depois
classifique as variáveis:

- categórica nominal (companhia, canal) ou ordinal (faixa, nota de 1 a 5);
- numérica discreta (contagem) ou contínua (valor, taxa);
- data.

A combinação decide o gráfico:

| variáveis | gráfico |
|---|---|
| uma categórica, contando | barras ordenadas |
| categórica + numérica (média ou soma) | barras ordenadas |
| categórica + numérica (distribuição) | boxplot por grupo |
| data + numérica | linha no tempo |
| numérica + numérica | dispersão, com a reta |

Ordinal mantém a ordem natural das categorias, e não a do tamanho.

## Passo 2: rodar

```bash
python scripts/graficos.py DADOS.csv --x COLUNA_X --y COLUNA_Y --agregar media \
    --titulo "A conclusão em uma frase" --fonte "de onde vieram os dados, período" \
    --destaque CATEGORIA --saida nome_do_arquivo
```

- `--tipo auto` (padrão) escolhe pela tabela acima; force com `barras`,
  `boxplot`, `linha` ou `dispersao`.
- `--agregar media | soma | mediana | contagem`; `--tempo dia | semana | mes`.
- Sem `--titulo`, o script sugere um a partir dos dados. Leia, confira se é
  verdade e reescreva com a conclusão para o negócio.
- O script diz quantas linhas ficaram de fora por falta de valor.

## Passo 3: conferir antes de entregar

1. O título é uma conclusão ("A Gol tem a menor nota"), e não um rótulo
   ("Nota por companhia")?
2. Uma cor de destaque só, no que o título fala?
3. Fonte e data no rodapé?
4. Um número do gráfico conferido contra a planilha.
5. Nenhum dado pessoal (nome, e-mail, telefone) em rótulos.

## Regras

- Nada de pizza, 3D, dois eixos y ou legenda quando dá para rotular direto.
- Barras sempre começam no zero. Linha pode começar perto dos dados.
- Se o usuário pedir pizza, explique em uma frase por que barras ordenadas
  leem melhor e ofereça as duas.
