# Skill graficos-executivos

**O que faz:** gráficos para slide e relatório executivo, em PNG 1920x1080 e
SVG, com o tipo escolhido pelas variáveis (barras ordenadas, boxplot, linha no
tempo, dispersão) e as boas práticas embutidas: título que conclui, uma cor de
destaque, rótulo direto, fonte e data no rodapé.

**Como instalar:** no ChatGPT, Personalizar → Habilidades → Adicionar, e envie
este zip. Ou, numa conversa no modo Work: "crie esta habilidade a partir deste
zip".

**Como adaptar:** troque as cores no começo de `scripts/graficos.py`
(`DESTAQUE`, `CINZA`) pelas da sua marca, e a fonte (`font.family`) pela da
empresa, se estiver instalada.

**Pedido de exemplo:** "Com a planilha `vendas_regiao.csv`, faça o gráfico da
receita média por região para o slide da diretoria, destacando o Nordeste. Use
a habilidade graficos-executivos."
