---
name: audiencia-wikipedia
description: Baixa as visualizações diárias de páginas da Wikipédia (API pública da Wikimedia) para marcas, produtos, concorrentes ou temas, e compara o interesse entre eles ao longo do tempo, com picos e variação semanal. Use quando pedirem um termômetro de interesse, atenção ou buzz por uma marca ou tema, para comparar concorrentes ou para achar a data de um pico de atenção.
---

# Audiência na Wikipédia

**O script baixa e conta; você interpreta.** Visualização da Wikipédia mede
curiosidade, e não venda nem satisfação. Diga isso sempre que comparar marcas.

## Passo 1: os termos

Combine com o usuário os termos (o nome da página na Wikipédia, de preferência
o título exato), o idioma (`pt` por padrão) e o período. Termos de idiomas
diferentes não se comparam.

## Passo 2: rodar

```bash
python scripts/wikipedia.py "Termo 1" "Termo 2" "Termo 3" --inicio 2026-08-01 --fim 2026-10-31 --saida audiencia.csv
python scripts/wikipedia.py "Termo 1" "Termo 2" --semanal --saida audiencia_semanal.csv
```

## Passo 3: explicar

1. Para cada termo: a página que o script usou (ele segue redirecionamentos),
   o total, a média por dia e o pico. Termo sem página: diga e peça o nome certo.
2. A variação dos últimos 7 dias contra os 7 anteriores, se o script mostrar.
3. Os picos: não explique um pico de memória. Sugira procurar a notícia da data
   (por exemplo, com o plugin noticias-rss) e diga que é uma hipótese.
4. Se pedirem gráfico, use a linha (uma por termo) com a média de 7 dias.

## Regras

- O script conta só acessos de pessoas, e não de robôs.
- O User-Agent identifica o curso; não troque por um que finja ser navegador.
- Uma consulta por termo, com pausa. Se a API falhar, diga que falhou.
