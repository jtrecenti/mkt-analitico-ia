# Plugin audiencia-wikipedia

**O que faz:** baixa as visualizações diárias de páginas da Wikipédia para
marcas, concorrentes ou temas e compara o interesse entre eles: total, média,
pico e variação semanal. API pública da Wikimedia, sem chave.

**Como criar o plugin:** no ChatGPT, Personalizar → Plugins → Adicionar →
Criar plugin. Anexe este zip e peça:

> Crie um plugin chamado audiencia-wikipedia com a habilidade do SKILL.md e o
> script scripts/wikipedia.py deste zip. Teste comparando LATAM, Gol e Azul nos
> últimos 90 dias.

Depois, instale o plugin (Personalizar → Plugins → Pessoal) e rode no
aplicativo de desktop, no modo Work.

**Pedido de exemplo:**

> Use o plugin audiencia-wikipedia para comparar o interesse por Natura,
> Boticário e Avon em 2026. Em que semanas houve picos? Faça um gráfico de
> linhas com a média de 7 dias.

**Como adaptar:**

- Outro idioma: `--idioma en` (ou `es`, `fr`).
- Mais termos: basta acrescentar na chamada. Para um painel fixo, guarde a lista
  num arquivo e peça ao agente para ler dali.
- Testado em 5/11/2026: de agosto a outubro, LATAM com 17.598 visualizações e
  TAP com 8.809 na Wikipédia em português.

**Cuidado:** mede curiosidade, e não venda. Um pico costuma ser notícia.
