"""Visualizações diárias de páginas da Wikipédia, como termômetro de interesse por marcas e temas.

Uso:
    python wikipedia.py "LATAM Airlines Brasil" "Gol Linhas Aéreas" "Azul Linhas Aéreas" --inicio 2026-08-01 --fim 2026-10-31
    python wikipedia.py "Coca-Cola" "Pepsi" --idioma en --semanal --saida refrigerantes.csv

Fonte: a API pública de pageviews da Wikimedia (wikimedia.org/api/rest_v1),
sem chave. Conta só acessos de pessoas (agent=user), em todas as plataformas.
O nome de cada página é conferido antes na própria Wikipédia: redirecionamentos
são seguidos (por exemplo, "Gol Linhas Aéreas" vira "Gol Linhas Aéreas
Inteligentes") e página que não existe é avisada, e não adivinhada.

Visualização da Wikipédia mede curiosidade, e não venda nem satisfação: um pico
costuma ser notícia (um acidente, um lançamento, um escândalo). Compare termos
do mesmo idioma e no mesmo período.
"""
from __future__ import annotations

import argparse
import sys
import time
from datetime import date, timedelta
from pathlib import Path
from urllib.parse import quote

import pandas as pd
import requests

H = {"User-Agent": "mkt-analitico-ia/1.0 (curso Insper; https://jtrecenti.github.io/mkt-analitico-ia)"}
PV = "https://wikimedia.org/api/rest_v1/metrics/pageviews/per-article/{p}.wikipedia/all-access/user/{t}/daily/{i}/{f}"


def titulo_real(termo: str, idioma: str) -> str | None:
    r = requests.get(f"https://{idioma}.wikipedia.org/w/api.php", headers=H, timeout=60,
                     params={"action": "query", "titles": termo, "redirects": 1, "format": "json"})
    r.raise_for_status()
    pags = r.json()["query"]["pages"]
    pag = next(iter(pags.values()))
    return None if "missing" in pag or "invalid" in pag else pag["title"]


def visualizacoes(titulo: str, idioma: str, ini: date, fim: date) -> pd.Series:
    u = PV.format(p=idioma, t=quote(titulo.replace(" ", "_"), safe=""), i=ini.strftime("%Y%m%d"), f=fim.strftime("%Y%m%d"))
    r = requests.get(u, headers=H, timeout=60)
    if r.status_code == 404:
        return pd.Series(dtype=float)
    r.raise_for_status()
    itens = r.json().get("items", [])
    return pd.Series({pd.Timestamp(x["timestamp"][:8]): x["views"] for x in itens}, dtype=float)


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("termos", nargs="+")
    p.add_argument("--idioma", default="pt")
    p.add_argument("--inicio", default=(date.today() - timedelta(days=91)).isoformat())
    p.add_argument("--fim", default=(date.today() - timedelta(days=1)).isoformat())
    p.add_argument("--semanal", action="store_true", help="soma por semana")
    p.add_argument("--saida", type=Path, default=Path("audiencia_wikipedia.csv"))
    a = p.parse_args()
    ini, fim = date.fromisoformat(a.inicio), date.fromisoformat(a.fim)
    cols = {}
    print(f"{len(a.termos)} termos pedidos, {a.idioma}.wikipedia, de {ini} a {fim}")
    for termo in a.termos:
        t = titulo_real(termo, a.idioma)
        time.sleep(0.5)
        if not t:
            print(f"  {termo}: página não encontrada; confira o nome exato na Wikipédia")
            continue
        s = visualizacoes(t, a.idioma, ini, fim)
        time.sleep(0.5)
        if s.empty:
            print(f"  {termo}: página {t} sem visualizações no período")
            continue
        nome = t if t == termo else f"{termo} ({t})"
        cols[t] = s
        pico = s.idxmax()
        print(f"  {nome}: {int(s.sum()):,} visualizações em {len(s)} dias; média {s.mean():,.0f}/dia; "
              f"pico de {int(s.max()):,} em {pico.date()}".replace(",", "."))
    if not cols:
        raise SystemExit("nenhum termo com dados")
    d = pd.DataFrame(cols).sort_index()
    d.index.name = "data"
    if a.semanal:
        d = d.resample("W-MON", label="left", closed="left").sum()
        d.index.name = "semana_que_comeca_em"
    d.to_csv(a.saida, encoding="utf-8-sig")
    if len(d) >= 14 and not a.semanal:
        ult, ant = d.iloc[-7:].sum(), d.iloc[-14:-7].sum()
        print("\núltimos 7 dias contra os 7 anteriores: "
              + "; ".join(f"{c} {((ult[c] / ant[c]) - 1) * 100:+.0f}%" for c in d.columns if ant[c]))
    print(f"\n{len(d)} linhas em {a.saida}")


if __name__ == "__main__":
    main()
