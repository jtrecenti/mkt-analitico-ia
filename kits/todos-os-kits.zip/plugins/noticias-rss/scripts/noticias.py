"""Lê feeds RSS de notícias e monta uma tabela de manchetes por termo e por dia.

Uso:
    python noticias.py --termo "Gol" --termo "LATAM" --termo "Azul" --saida manchetes.csv
    python noticias.py --termo "Natura" --feeds meus_feeds.txt --dias 14
    python noticias.py --termo "LATAM Airlines" --google --saida manchetes.csv
    python noticias.py --listar                 (mostra os feeds padrão)

Guarda só o que o feed publica: título, link, data, fonte e o resumo curto do
próprio feed. Não baixa o texto completo das matérias.

- Feeds padrão: portais brasileiros de economia e marketing (lista FEEDS, que
  você pode trocar por um arquivo com um endereço por linha, em --feeds).
- --google acrescenta a busca do Google Notícias para cada termo. O próprio
  feed avisa que é para leitor pessoal e uso não comercial: use para estudo,
  e não num produto da empresa.
- O termo é procurado no título e no resumo, sem diferenciar acento e
  maiúscula, como palavra inteira ("Gol" não pega "golpe").
"""
from __future__ import annotations

import argparse
import re
import sys
import time
import unicodedata
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone
from email.utils import parsedate_to_datetime
from pathlib import Path
from urllib.parse import quote_plus

import pandas as pd
import requests

H = {"User-Agent": "mkt-analitico-ia/1.0 (curso Insper; https://jtrecenti.github.io/mkt-analitico-ia)"}
FEEDS = [
    "https://g1.globo.com/rss/g1/economia/",
    "https://agenciabrasil.ebc.com.br/rss/economia/feed.xml",
    "https://agenciabrasil.ebc.com.br/rss/ultimasnoticias/feed.xml",
    "https://www.infomoney.com.br/feed/",
    "https://exame.com/feed/",
    "https://www.meioemensagem.com.br/feed",
]
GOOGLE = "https://news.google.com/rss/search?q={q}&hl=pt-BR&gl=BR&ceid=BR:pt-419"


def norm(t: str) -> str:
    return unicodedata.normalize("NFKD", t or "").encode("ascii", "ignore").decode().lower()


def limpar(t: str) -> str:
    return re.sub(r"\s+", " ", re.sub(r"<[^>]+>", " ", t or "")).strip()


def ler_feed(url: str) -> tuple[list[dict], str]:
    r = requests.get(url, headers=H, timeout=30)
    r.raise_for_status()
    raiz = ET.fromstring(r.content)
    fonte = limpar(raiz.findtext("channel/title") or url)
    itens = []
    for it in raiz.iter("item"):
        data = it.findtext("pubDate") or ""
        try:
            dt = parsedate_to_datetime(data).astimezone(timezone.utc)
        except (TypeError, ValueError):
            dt = None
        src = it.find("source")
        itens.append({"data": dt, "titulo": limpar(it.findtext("title")), "resumo": limpar(it.findtext("description"))[:300],
                      "link": (it.findtext("link") or "").strip(),
                      "fonte": limpar(src.text) if src is not None and src.text else fonte})
    return itens, fonte


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("--termo", action="append", default=[])
    p.add_argument("--feeds", type=Path, help="arquivo com um endereço de feed por linha")
    p.add_argument("--google", action="store_true", help="acrescenta a busca do Google Notícias (uso pessoal)")
    p.add_argument("--dias", type=int, default=7, help="só manchetes dos últimos N dias")
    p.add_argument("--saida", type=Path, default=Path("manchetes.csv"))
    p.add_argument("--listar", action="store_true")
    a = p.parse_args()
    feeds = [l.strip() for l in a.feeds.read_text(encoding="utf-8").splitlines() if l.strip() and not l.startswith("#")] if a.feeds else FEEDS
    if a.listar:
        print("\n".join(feeds))
        return
    if not a.termo:
        p.error("informe ao menos um --termo")
    urls = list(feeds) + ([GOOGLE.format(q=quote_plus(f'"{t}"')) for t in a.termo] if a.google else [])
    todos, falhas = [], []
    for u in urls:
        try:
            itens, fonte = ler_feed(u)
            todos += itens
            print(f"  {fonte[:50]}: {len(itens)} itens")
        except Exception as e:  # noqa: BLE001
            falhas.append(u)
            print(f"  falhou: {u} ({type(e).__name__})")
        time.sleep(0.7)
    d = pd.DataFrame(todos)
    if d.empty:
        raise SystemExit("nenhum feed respondeu")
    entrou = len(d)
    d = d.drop_duplicates(["link"]).drop_duplicates(["titulo"])
    limite = datetime.now(timezone.utc) - timedelta(days=a.dias)
    d = d[d["data"].notna() & (d["data"] >= limite)]
    linhas = []
    for t in a.termo:
        pad = re.compile(r"\b" + re.escape(norm(t)) + r"\b")
        m = d[(d["titulo"].map(norm) + " " + d["resumo"].map(norm)).str.contains(pad)]
        linhas.append(m.assign(termo=t))
    r = pd.concat(linhas) if linhas else pd.DataFrame()
    print(f"\n{entrou} itens lidos de {len(urls) - len(falhas)} feeds ({len(falhas)} falharam); "
          f"{len(d)} únicos nos últimos {a.dias} dias; {len(r)} manchetes com algum termo")
    if r.empty:
        print("nenhuma manchete com os termos; tente --google ou mais dias")
        return
    r["dia"] = r["data"].dt.tz_convert("America/Sao_Paulo").dt.date
    print(r.groupby(["termo", "dia"]).size().unstack(0, fill_value=0).to_string())
    r[["termo", "dia", "fonte", "titulo", "link", "resumo"]].sort_values(["termo", "dia"]).to_csv(a.saida, index=False, encoding="utf-8-sig")
    print(f"\n{len(r)} linhas em {a.saida}")


if __name__ == "__main__":
    main()
