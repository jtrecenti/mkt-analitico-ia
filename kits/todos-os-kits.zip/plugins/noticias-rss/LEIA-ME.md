# Plugin noticias-rss

**O que faz:** lê feeds RSS de portais (g1 Economia, Agência Brasil, InfoMoney,
Exame e Meio & Mensagem, por padrão) e monta uma tabela de manchetes por termo
e por dia, com fonte e link. Não baixa o texto das matérias.

**Como criar o plugin:** no ChatGPT, Personalizar → Plugins → Adicionar →
Criar plugin. Anexe este zip e peça:

> Crie um plugin chamado noticias-rss com a habilidade do SKILL.md e o script
> scripts/noticias.py deste zip. Teste com os termos dólar e LATAM nos últimos
> 7 dias.

Depois, instale o plugin (Personalizar → Plugins → Pessoal) e rode no
aplicativo de desktop, no modo Work.

**Pedido de exemplo:**

> Use o plugin noticias-rss para montar o clipping da semana sobre a nossa
> marca e os dois concorrentes. Agrupe por tema e diga qual marca apareceu mais.

**Como adaptar:**

- Outras fontes: um arquivo `meus_feeds.txt` com um endereço por linha (muitos
  sites têm `/feed` ou `/rss` no fim do endereço), e `--feeds meus_feeds.txt`.
- Um clipping diário: junte com uma tarefa agendada do ChatGPT.
- A busca do Google Notícias (`--google`) traz muito mais manchetes, mas o feed
  é para uso pessoal e não comercial.
- Testado em 5/11/2026: 185 itens de 6 feeds; 92 manchetes com "LATAM" na
  busca do Google Notícias nos últimos 7 dias.
