---
name: noticias-rss
description: Lê feeds RSS de portais de notícias (lista configurável, e opcionalmente a busca do Google Notícias) e monta uma tabela de manchetes por termo e por dia, com fonte e link, sem baixar o texto das matérias. Use quando pedirem um clipping, o que saiu na imprensa sobre uma marca, um concorrente ou um tema, ou a notícia por trás de um pico de interesse.
---

# Manchetes de notícias por termo

**O script coleta e conta; você lê e resume.** Nunca cite uma notícia que não
está na tabela do script, nem invente a data ou a fonte.

## Passo 1: termos e fontes

Combine com o usuário os termos (marcas, concorrentes, temas), o período em
dias e as fontes. Os feeds padrão são portais de economia e marketing
(`python scripts/noticias.py --listar`). Para outras fontes, crie um arquivo
com um endereço de feed por linha e use `--feeds`.

## Passo 2: rodar

```bash
python scripts/noticias.py --termo "Marca A" --termo "Marca B" --dias 7 --saida manchetes.csv
python scripts/noticias.py --termo "Marca A" --feeds meus_feeds.txt --dias 30
python scripts/noticias.py --termo "Marca A" --google --dias 7
```

`--google` acrescenta a busca do Google Notícias. O próprio feed diz que é para
leitor pessoal e uso não comercial: avise o usuário antes de usar.

## Passo 3: explicar

1. Quantos feeds responderam e quantos falharam; quantas manchetes únicas no
   período e quantas com cada termo (a tabela por dia que o script imprime).
2. Resuma as manchetes de cada termo **a partir dos títulos e resumos da
   tabela**, com a fonte e o link. Diga que o resumo vem só da manchete.
3. Se o usuário quiser o texto de uma matéria, mande o link: o script não
   baixa matérias.

## Regras

- O termo é procurado como palavra inteira ("Gol" não pega "golpe"). Termos
  ambíguos (Azul, Gol) trazem falsos positivos: aponte os que achar.
- Não reproduza matérias inteiras: título, resumo curto do feed e link.
- O User-Agent identifica o curso; não finja ser um navegador.
