# Plugin dados-ibge

**O que faz:** acrescenta a uma planilha de lojas, clientes ou regiões o
código IBGE, a região, a população (estimativa mais recente e Censo 2022), o
PIB municipal e o PIB per capita, pela API pública do IBGE (sem chave).

**Como criar o plugin:** no ChatGPT, Personalizar → Plugins → Adicionar →
Criar plugin. Anexe este zip e peça:

> Crie um plugin chamado dados-ibge com a habilidade do SKILL.md e o script
> scripts/ibge.py deste zip. Teste com Ribeirão Preto, SP.

Depois, instale o plugin (Personalizar → Plugins → Pessoal). Rode no
aplicativo de desktop, no modo Work: a API do IBGE pode recusar o computador
da nuvem.

**Pedido de exemplo:**

> Use o plugin dados-ibge na planilha lojas.xlsx (colunas cidade e uf). Quantas
> lojas temos por 100 mil habitantes em cada região? Quais cidades com mais de
> 500 mil habitantes não têm loja?

**Como adaptar:**

- Outro indicador do SIDRA: acrescente a tabela e a variável em `TABELAS`, no
  script (procure em sidra.ibge.gov.br; por exemplo, rendimento ou domicílios).
- Testado em 5/11/2026: Ribeirão Preto (SP) com 734.538 habitantes estimados em
  2026 e PIB per capita de R$ 74.869.
