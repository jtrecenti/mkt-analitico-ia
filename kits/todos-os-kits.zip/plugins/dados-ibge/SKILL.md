---
name: dados-ibge
description: Busca na API pública do IBGE a população (estimativa mais recente e Censo 2022), o PIB municipal e a região de municípios brasileiros, por nome e UF ou por código IBGE, e acrescenta essas colunas a uma planilha de lojas, clientes, pontos de venda ou regiões. Use quando pedirem população, tamanho de mercado, PIB ou PIB per capita de cidades, ou para enriquecer uma planilha com dados do IBGE.
---

# Dados do IBGE para uma planilha

**O script consulta e conta; você explica.** Nunca escreva população ou PIB de
memória: os números vêm da API do IBGE, com o ano de cada um.

## Passo 1: as colunas

Diga quantas linhas a planilha tem e qual coluna parece ser o município, a UF
ou o código IBGE. Sem a UF, nomes repetidos (há cinco "Bom Jesus") ficam
marcados como ambíguos: recomende informar a UF.

## Passo 2: rodar

```bash
python scripts/ibge.py planilha ARQUIVO --municipio cidade --uf uf --saida ARQUIVO_ibge.csv
python scripts/ibge.py planilha ARQUIVO --codigo codigo_ibge --saida ARQUIVO_ibge.csv
python scripts/ibge.py municipio "Ribeirão Preto" --uf SP
python scripts/ibge.py uf
```

## Passo 3: explicar

1. Quantas linhas entraram, quantas tiveram o município identificado e quantas
   não (nome não encontrado ou ambíguo), com o motivo.
2. As colunas novas e o ano de cada uma (o script imprime): população estimada,
   população do Censo 2022, PIB em mil reais e PIB per capita.
3. Depois, a leitura que o usuário pediu (por exemplo, lojas por 100 mil
   habitantes, cidades grandes sem loja).

## Regras

- Não adivinhe o município de um nome que não bateu: mostre e pergunte.
- Uma consulta por lote de 100 municípios, com pausa. Se a API falhar, diga
  que falhou e rode de novo mais tarde; não invente o dado.
- O PIB per capita usa a população do Censo 2022: diga isso se o usuário
  comparar com outra fonte.
