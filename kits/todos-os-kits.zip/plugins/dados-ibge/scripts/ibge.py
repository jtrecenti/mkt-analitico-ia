"""Busca população e PIB de municípios na API de dados do IBGE, para enriquecer planilhas.

Uso:
    python ibge.py municipio "Ribeirão Preto" --uf SP
    python ibge.py planilha lojas.csv --municipio cidade --uf uf --saida lojas_ibge.csv
    python ibge.py planilha lojas.csv --codigo codigo_ibge --saida lojas_ibge.csv
    python ibge.py uf                       (população estimada de cada UF)

Fontes (servicodados.ibge.gov.br, API pública, sem chave):
- localidades: a lista dos 5.570 municípios, com UF, região e região imediata;
- agregados (SIDRA): tabela 6579 (população estimada, ano mais recente),
  tabela 4709 (população do Censo 2022) e tabela 5938 (PIB municipal a preços
  correntes, em mil reais, ano mais recente).

O nome do município é comparado sem acento e sem maiúsculas. Nome que não bate
(ou que existe em mais de uma UF sem a UF informada) fica marcado, e não
adivinhado. Consultas em lotes de 100 municípios, com pausa entre elas.
"""
from __future__ import annotations

import argparse
import sys
import time
import unicodedata
from pathlib import Path

import pandas as pd
import requests

H = {"User-Agent": "mkt-analitico-ia/1.0 (curso Insper; https://jtrecenti.github.io/mkt-analitico-ia)"}
BASE = "https://servicodados.ibge.gov.br/api"
TABELAS = {"populacao_estimada": (6579, 9324), "populacao_censo_2022": (4709, 93), "pib_mil_reais": (5938, 37)}


def norm(t) -> str:
    return unicodedata.normalize("NFKD", str(t)).encode("ascii", "ignore").decode().lower().strip()


def municipios() -> pd.DataFrame:
    r = requests.get(f"{BASE}/v1/localidades/municipios?view=nivelado", headers=H, timeout=60)
    r.raise_for_status()
    d = pd.DataFrame(r.json()).rename(columns={"municipio-id": "codigo_ibge", "municipio-nome": "municipio_ibge",
                                               "UF-sigla": "uf_ibge", "regiao-nome": "regiao",
                                               "regiao-imediata-nome": "regiao_imediata"})
    d["chave"] = d["municipio_ibge"].map(norm)
    return d[["codigo_ibge", "municipio_ibge", "uf_ibge", "regiao", "regiao_imediata", "chave"]]


def agregado(tabela: int, variavel: int, codigos: list[int], nivel: str = "N6") -> dict[int, tuple[str, float]]:
    saida = {}
    for i in range(0, len(codigos), 100):
        lote = ",".join(str(c) for c in codigos[i:i + 100])
        u = f"{BASE}/v3/agregados/{tabela}/periodos/-1/variaveis/{variavel}?localidades={nivel}[{lote}]"
        r = requests.get(u, headers=H, timeout=90)
        r.raise_for_status()
        for s in r.json()[0]["resultados"][0]["series"]:
            ano, val = next(iter(s["serie"].items()))
            saida[int(s["localidade"]["id"])] = (ano, pd.to_numeric(val, errors="coerce"))
        time.sleep(1)
    return saida


def enriquecer(d: pd.DataFrame) -> pd.DataFrame:
    cods = sorted(d["codigo_ibge"].dropna().astype(int).unique().tolist())
    for nome, (t, v) in TABELAS.items():
        res = agregado(t, v, cods)
        anos = sorted({a for a, _ in res.values()})
        d[nome] = d["codigo_ibge"].map(lambda c: res.get(int(c), (None, None))[1] if pd.notna(c) else None)
        print(f"  {nome}: tabela {t}, ano {', '.join(anos)}; {sum(1 for c in cods if c in res)} de {len(cods)} municípios com dado")
    d["pib_per_capita_reais"] = (1000 * d["pib_mil_reais"] / d["populacao_censo_2022"]).round(0)
    return d


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = p.add_subparsers(dest="modo", required=True)
    m = sub.add_parser("municipio"); m.add_argument("nome"); m.add_argument("--uf")
    pl = sub.add_parser("planilha"); pl.add_argument("arquivo", type=Path)
    pl.add_argument("--municipio"); pl.add_argument("--uf"); pl.add_argument("--codigo")
    pl.add_argument("--saida", type=Path)
    sub.add_parser("uf")
    a = p.parse_args()

    if a.modo == "uf":
        r = requests.get(f"{BASE}/v1/localidades/estados", headers=H, timeout=60).json()
        ufs = {e["id"]: e["sigla"] for e in r}
        res = agregado(6579, 9324, list(ufs), "N3")
        d = pd.DataFrame([{"uf": ufs[c], "ano": a_, "populacao_estimada": v} for c, (a_, v) in res.items()])
        print(d.sort_values("populacao_estimada", ascending=False).to_string(index=False))
        return

    mun = municipios()
    if a.modo == "municipio":
        achados = mun[(mun["chave"] == norm(a.nome)) & ((mun["uf_ibge"] == a.uf.upper()) if a.uf else True)]
        if achados.empty:
            raise SystemExit(f"não achei {a.nome}" + (f"/{a.uf}" if a.uf else ""))
        print(enriquecer(achados.drop(columns="chave").copy()).to_string(index=False))
        return

    d = pd.read_excel(a.arquivo, dtype=str) if a.arquivo.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(a.arquivo, dtype=str, sep=None, engine="python", encoding="utf-8-sig")
    entrou = len(d)
    if a.codigo:
        d["codigo_ibge"] = pd.to_numeric(d[a.codigo], errors="coerce")
        d = d.merge(mun.drop(columns="chave"), on="codigo_ibge", how="left")
        d["status_ibge"] = d["municipio_ibge"].notna().map({True: "ok", False: "código não encontrado"})
    else:
        if not a.municipio:
            raise SystemExit("informe --municipio (e de preferência --uf) ou --codigo")
        d["_k"] = d[a.municipio].map(norm)
        d["_uf"] = d[a.uf].fillna("").str.upper().str.strip() if a.uf else None
        cont = mun.groupby("chave").size()
        status, cods = [], []
        for k, u in zip(d["_k"], d["_uf"] if a.uf else [None] * len(d)):
            c = mun[(mun["chave"] == k) & ((mun["uf_ibge"] == u) if u else True)]
            if len(c) == 1:
                status.append("ok"); cods.append(int(c["codigo_ibge"].iloc[0]))
            else:
                status.append("nome não encontrado" if c.empty else f"ambíguo: {cont.get(k, 0)} municípios com esse nome; informe a UF")
                cods.append(None)
        d["codigo_ibge"], d["status_ibge"] = cods, status
        d = d.drop(columns=["_k", "_uf"]).merge(mun.drop(columns="chave"), on="codigo_ibge", how="left")
    ok = int((d["status_ibge"] == "ok").sum())
    print(f"{entrou} linhas lidas; {ok} com município identificado; {entrou - ok} sem: "
          + ", ".join(f"{k}: {v}" for k, v in d.loc[d["status_ibge"] != "ok", "status_ibge"].value_counts().items()))
    d = enriquecer(d)
    saida = a.saida or a.arquivo.with_name(a.arquivo.stem + "_ibge.csv")
    d.to_csv(saida, index=False, encoding="utf-8-sig")
    print(f"{len(d)} linhas gravadas em {saida}")


if __name__ == "__main__":
    main()
