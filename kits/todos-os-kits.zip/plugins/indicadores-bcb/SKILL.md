---
name: indicadores-bcb
description: Baixa séries oficiais do Banco Central (SGS) num período, como IPCA, Selic, dólar, euro, IBC-Br e inadimplência, e corrige valores em reais pela inflação. Use quando pedirem inflação, juros, câmbio ou atividade econômica de um período, para cruzar com vendas ou preços, ou para comparar valores em reais de anos diferentes.
---

# Indicadores do Banco Central

**O script baixa e calcula; você interpreta.** Nunca escreva uma taxa, uma
cotação ou um índice de memória: o número vem da série oficial, com a data.

## Passo 1: escolher as séries

Mostre os códigos úteis com `python scripts/bcb.py codigos` e combine com o
usuário quais séries e qual período. Para cruzar com dados mensais (vendas,
campanhas), use `--mensal`.

## Passo 2: rodar

```bash
python scripts/bcb.py serie ipca dolar selic_meta --inicio 2025-01-01 --fim 2026-10-31 --mensal --saida indicadores.csv
python scripts/bcb.py serie 433 21619 --inicio 2026-01-01 --saida indicadores.csv
python scripts/bcb.py corrigir vendas.csv --data mes --valor receita --saida vendas_reais.csv
```

## Passo 3: explicar

1. Para cada série: quantos valores vieram, de que data a que data, e o último.
2. Se uma série veio vazia, diga isso: pode não ter dado no período, ou o
   código estar errado.
3. Na correção pela inflação: para que mês os valores foram corrigidos e quantas
   linhas ficaram sem fator (meses com IPCA ainda não divulgado).
4. Depois, a leitura: por exemplo, a receita cresceu acima ou abaixo da
   inflação; o câmbio acompanhou o custo dos importados.

## Regras

- Diga sempre a fonte (SGS do Banco Central) e o código de cada série.
- Média mensal de taxa diária é uma simplificação: diga isso quando usar `--mensal`.
- Se a API falhar, diga que falhou e tente de novo mais tarde; não invente o dado.
