# Plugin indicadores-bcb

**O que faz:** baixa séries do SGS do Banco Central (IPCA, IPCA em 12 meses,
Selic, dólar, euro, IBC-Br, inadimplência ou qualquer outro código) num período
e corrige valores em reais pela inflação. API pública, sem chave.

**Como criar o plugin:** no ChatGPT, Personalizar → Plugins → Adicionar →
Criar plugin. Anexe este zip e peça:

> Crie um plugin chamado indicadores-bcb com a habilidade do SKILL.md e o
> script scripts/bcb.py deste zip. Teste baixando o IPCA e o dólar de 2026.

Depois, instale o plugin (Personalizar → Plugins → Pessoal) e rode no
aplicativo de desktop, no modo Work.

**Pedido de exemplo:**

> Use o plugin indicadores-bcb para corrigir pela inflação a receita mensal da
> planilha vendas_2024_2026.csv. A receita cresceu de verdade, ou foi só a
> inflação?

**Como adaptar:**

- Série nova: procure o código em www3.bcb.gov.br/sgspub e acrescente em
  `CODIGOS`, no script, com um nome curto.
- Testado em 5/11/2026: IPCA em 12 meses de 4,58% (setembro de 2026) e dólar
  médio de R$ 5,49 em novembro.
