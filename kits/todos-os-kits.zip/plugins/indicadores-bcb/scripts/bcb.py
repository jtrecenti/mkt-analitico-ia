"""Baixa séries do Banco Central (SGS) num período: inflação, juros, câmbio e atividade.

Uso:
    python bcb.py codigos                                  (lista os códigos úteis)
    python bcb.py serie ipca dolar --inicio 2025-01-01 --fim 2026-10-31 --saida indicadores.csv
    python bcb.py serie 433 1 --inicio 2026-01-01 --mensal --saida indicadores.csv
    python bcb.py corrigir valores.csv --data data --valor valor --saida valores_reais.csv

Fonte: SGS, Sistema Gerenciador de Séries Temporais do Banco Central
(api.bcb.gov.br/dados/serie/bcdata.sgs.CODIGO/dados), pública e sem chave.
Séries diárias são baixadas em janelas de até 5 anos (limite da API).

- serie: uma coluna por série, uma linha por data; --mensal junta as diárias
  pela média do mês (taxas e câmbio) para cruzar com dados mensais.
- corrigir: corrige valores em reais pela inflação (IPCA), para a data mais
  recente da série, e diz o fator usado em cada mês.
"""
from __future__ import annotations

import argparse
import sys
import time
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import requests

H = {"User-Agent": "mkt-analitico-ia/1.0 (curso Insper; https://jtrecenti.github.io/mkt-analitico-ia)"}
URL = "https://api.bcb.gov.br/dados/serie/bcdata.sgs.{c}/dados?formato=json&dataInicial={i}&dataFinal={f}"
CODIGOS = {
    "ipca": (433, "IPCA, variação no mês (%)", "mensal"),
    "ipca_12m": (13522, "IPCA acumulado em 12 meses (%)", "mensal"),
    "selic_meta": (432, "Meta da Selic definida pelo Copom (% ao ano)", "diária"),
    "selic": (11, "Selic diária efetiva (% ao dia)", "diária"),
    "dolar": (1, "Dólar comercial, venda, PTAX (R$)", "diária"),
    "euro": (21619, "Euro, venda, PTAX (R$)", "diária"),
    "ibc_br": (24363, "IBC-Br, prévia do PIB (índice, sem ajuste)", "mensal"),
    "inadimplencia_pf": (21082, "Inadimplência das pessoas físicas no crédito do sistema financeiro (%)", "mensal"),
}


def resolver(x: str) -> tuple[int, str]:
    if x.lower() in CODIGOS:
        c, nome, _ = CODIGOS[x.lower()]
        return c, x.lower()
    return int(x), f"sgs_{x}"


def baixar(codigo: int, inicio: date, fim: date) -> pd.Series:
    partes = []
    a = inicio
    while a <= fim:
        b = min(date(a.year + 5, a.month, 1), fim)
        r = requests.get(URL.format(c=codigo, i=a.strftime("%d/%m/%Y"), f=b.strftime("%d/%m/%Y")), headers=H, timeout=60)
        if r.status_code == 404 or r.text.strip() in ("", "[]"):
            pass
        else:
            r.raise_for_status()
            partes += r.json()
        a = b + timedelta(days=1)
        time.sleep(0.5)
    if not partes:
        return pd.Series(dtype=float)
    d = pd.DataFrame(partes).drop_duplicates("data")
    return pd.Series(pd.to_numeric(d["valor"], errors="coerce").values,
                     index=pd.to_datetime(d["data"], format="%d/%m/%Y"))


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    sub = p.add_subparsers(dest="modo", required=True)
    sub.add_parser("codigos")
    s = sub.add_parser("serie"); s.add_argument("series", nargs="+")
    s.add_argument("--inicio", default="2025-01-01"); s.add_argument("--fim", default=date.today().isoformat())
    s.add_argument("--mensal", action="store_true"); s.add_argument("--saida", type=Path, default=Path("indicadores_bcb.csv"))
    c = sub.add_parser("corrigir"); c.add_argument("arquivo", type=Path)
    c.add_argument("--data", required=True); c.add_argument("--valor", required=True); c.add_argument("--saida", type=Path)
    a = p.parse_args()

    if a.modo == "codigos":
        for k, (cod, nome, freq) in CODIGOS.items():
            print(f"{k:18s} {cod:>6d}  {freq:7s} {nome}")
        print("\nOutros códigos: busque em www3.bcb.gov.br/sgspub e use o número.")
        return

    if a.modo == "serie":
        ini, fim = date.fromisoformat(a.inicio), date.fromisoformat(a.fim)
        cols = {}
        for x in a.series:
            cod, nome = resolver(x)
            s_ = baixar(cod, ini, fim)
            if s_.empty:
                print(f"{nome} (código {cod}): nenhum dado no período")
                continue
            if a.mensal:
                s_ = s_.groupby(s_.index.to_period("M")).mean()
                s_.index = s_.index.to_timestamp()
            cols[nome] = s_
            print(f"{nome} (código {cod}): {len(s_)} valores, de {s_.index.min().date()} a {s_.index.max().date()}; "
                  f"último: {s_.iloc[-1]:.4g}")
        d = pd.DataFrame(cols)
        d.index.name = "data"
        d.to_csv(a.saida, encoding="utf-8-sig")
        print(f"\n{len(d)} linhas em {a.saida}")
        return

    # corrigir pela inflação
    v = pd.read_excel(a.arquivo) if a.arquivo.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(a.arquivo, sep=None, engine="python", encoding="utf-8-sig")
    v["_mes"] = pd.to_datetime(v[a.data], errors="coerce", dayfirst=True).dt.to_period("M")
    sem = int(v["_mes"].isna().sum())
    ipca = baixar(433, v["_mes"].min().to_timestamp().date(), date.today())
    ipca.index = ipca.index.to_period("M")
    indice = (1 + ipca / 100).cumprod()
    ultimo = indice.index.max()
    fator = indice.loc[ultimo] / indice
    # o valor de um mês é corrigido do fim daquele mês até o último mês com IPCA
    v["fator_ipca"] = v["_mes"].map(fator)
    v[f"{a.valor}_em_reais_de_{ultimo}"] = (pd.to_numeric(v[a.valor], errors="coerce") * v["fator_ipca"]).round(2)
    print(f"{len(v)} linhas; {sem} sem data reconhecida; {int(v['fator_ipca'].isna().sum())} sem fator (mês sem IPCA ainda); "
          f"valores corrigidos para reais de {ultimo} pelo IPCA (código 433)")
    saida = a.saida or a.arquivo.with_name(a.arquivo.stem + "_corrigido.csv")
    v.drop(columns="_mes").to_csv(saida, index=False, encoding="utf-8-sig")
    print(f"gravado em {saida}")


if __name__ == "__main__":
    main()
