---
name: brasilapi
description: Consulta a BrasilAPI (dados públicos da Receita e dos Correios) para CNPJ, CEP, DDD e feriados nacionais, e enriquece uma planilha de parceiros ou clientes com situação cadastral, atividade, porte, abertura e cidade, com alertas de cadastro inconsistente. Use quando pedirem para conferir CNPJs, completar endereços por CEP, descobrir o estado de um DDD ou listar feriados de um ano.
---

# BrasilAPI: CNPJ, CEP, DDD e feriados

**O script consulta e confere; você explica.** Nunca afirme a situação de um
CNPJ ou a cidade de um CEP sem a resposta da API.

## Como usar

Consultas avulsas:

```bash
python scripts/brasilapi.py cnpj 10.760.260/0001-19
python scripts/brasilapi.py cep 09090-401
python scripts/brasilapi.py ddd 31
python scripts/brasilapi.py feriados 2027
```

Planilha de agências (colunas `cnpj`, `cep_cadastro`, `telefone_cadastro`):

```bash
python scripts/brasilapi.py agencias PLANILHA.csv --ano 2027 --saida PLANILHA_enriquecida.csv
```

Para outra planilha, mostre ao usuário as colunas, combine qual é o CNPJ, o
CEP e o telefone, e renomeie numa cópia antes de rodar (nunca no original).

## Ao responder

1. Quantas linhas entraram, quantas voltaram com dado da Receita e quantas
   falharam, e por quê (CNPJ inválido, não encontrado, API fora do ar).
2. Os alertas: empresa baixada, atividade que não bate, aberta há pouco tempo,
   cidade ou DDD diferente do cadastro, linhas repetidas, grupos com o mesmo
   telefone ou endereço.
3. Depois, a recomendação que o usuário pediu.

## Regras

- O script devolve os zeros à esquerda que o Excel come antes de validar.
- Não guarda nem mostra o quadro de sócios (dados pessoais).
- Uma consulta por vez, com pausa; a mesma consulta nunca duas vezes.
- Rode no aplicativo de desktop (modo Work): a BrasilAPI recusa o computador
  da nuvem.
