"""Consulta a BrasilAPI (https://brasilapi.com.br): CNPJ, CEP, DDD e feriados.

Uso:
    python brasilapi.py cnpj 10.760.260/0001-19
    python brasilapi.py cep 09090-401
    python brasilapi.py ddd 31
    python brasilapi.py feriados 2027
    python brasilapi.py agencias agencias_parceiras.csv --ano 2027 --saida agencias_enriquecidas.csv

O modo agencias lê uma planilha de agências de viagem com cnpj, cep_cadastro e
telefone_cadastro, e devolve:
- cada linha enriquecida com a Receita (situação, atividade, porte, abertura,
  cidade, telefone), com a cidade do CEP e com o estado do DDD;
- alertas: CNPJ inválido, empresa baixada, atividade que não é agência de
  viagens, aberta há menos de dois anos, cadastro com cidade ou DDD diferente
  da Receita, linha repetida;
- os grupos: agências diferentes com o mesmo telefone ou o mesmo endereço na
  Receita;
- os feriados nacionais do ano, marcando os que emendam com o fim de semana.

Limpa a pontuação, devolve os zeros à esquerda que o Excel come e marca o que
não deu certo em vez de parar. Uma consulta por vez, com pausa, e nunca a
mesma consulta duas vezes. Não guarda o quadro de sócios (dados pessoais).

Só usa endpoints que respondiam bem em 3/11/2026. A FIPE e o clima nos
aeroportos estavam fora do ar.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from datetime import date
from functools import lru_cache
from pathlib import Path

import pandas as pd
import requests

BRASILAPI = "https://brasilapi.com.br/api"
PAUSA = 0.4
AGENCIA = "7911200"  # CNAE de agências de viagens
CAMPOS_CNPJ = {
    "razao_social": "razao_social",
    "nome_fantasia": "nome_fantasia",
    "situacao": "descricao_situacao_cadastral",
    "data_situacao": "data_situacao_cadastral",
    "cnae": "cnae_fiscal",
    "atividade": "cnae_fiscal_descricao",
    "porte": "porte",
    "abertura": "data_inicio_atividade",
    "municipio_receita": "municipio",
    "uf_receita": "uf",
    "cep_receita": "cep",
    "telefone_receita": "ddd_telefone_1",
}


# ------------------------------------------------------------------ limpeza
def sem_pontuacao(x) -> str:
    """Tira pontuação. Desde julho de 2026 o CNPJ pode ter letras: elas ficam."""
    return re.sub(r"[^0-9A-Za-z]", "", "" if pd.isna(x) else str(x)).upper()


def limpar_cnpj(x) -> str:
    c = sem_pontuacao(x)
    return c.zfill(14) if c.isdigit() else c  # zeros que o Excel comeu


def cnpj_valido(c: str) -> bool:
    if len(c) != 14 or not c[12:].isdigit() or c == c[0] * 14:
        return False

    def dv(base: str, pesos: list[int]) -> str:
        # regra da Receita: cada caractere vale seu código ASCII menos 48 (0-9; A=17, B=18...)
        r = sum((ord(d) - 48) * p for d, p in zip(base, pesos)) % 11
        return "0" if r < 2 else str(11 - r)

    p1 = [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
    return c[12] == dv(c[:12], p1) and c[13] == dv(c[:13], [6] + p1)


def limpar_cep(x) -> str:
    c = sem_pontuacao(x)
    return c.zfill(8) if c.isdigit() and 5 <= len(c) <= 8 else c


def ddd_de(telefone) -> str:
    d = sem_pontuacao(telefone)
    return d[:2] if len(d) >= 10 else ""


# ---------------------------------------------------------------- consultas
def get(caminho: str) -> requests.Response:
    time.sleep(PAUSA)
    r = requests.get(f"{BRASILAPI}/{caminho}", timeout=30)
    if r.status_code == 403:
        raise RuntimeError("a BrasilAPI recusou o acesso (403). Rode no aplicativo de desktop, na sua máquina.")
    return r


@lru_cache(maxsize=None)
def cnpj(c: str) -> dict:
    if not cnpj_valido(c):
        return {"status_cnpj": "CNPJ inválido (dígito verificador)"}
    r = get(f"cnpj/v1/{c}")
    if r.status_code == 404:
        return {"status_cnpj": "não encontrado na Receita"}
    if not r.ok:
        return {"status_cnpj": f"BrasilAPI indisponível ({r.status_code})"}
    j = r.json()  # não guarda o quadro de sócios (qsa): são dados pessoais
    return {"status_cnpj": "ok", **{k: j.get(v) for k, v in CAMPOS_CNPJ.items()}}


@lru_cache(maxsize=None)
def cep(c: str) -> dict:
    if len(c) != 8 or not c.isdigit():
        return {"status_cep": "CEP com formato errado"}
    r = get(f"cep/v2/{c}")
    if r.status_code == 404:
        return {"status_cep": "CEP não encontrado"}
    if not r.ok:
        return {"status_cep": f"BrasilAPI indisponível ({r.status_code})"}
    j = r.json()
    return {"status_cep": "ok", "cidade_cep": j.get("city"), "uf_cep": j.get("state")}


@lru_cache(maxsize=None)
def ddd(d: str) -> dict:
    if not d:
        return {"uf_ddd": None}
    r = get(f"ddd/v1/{d}")
    return {"uf_ddd": r.json().get("state") if r.ok else None}


@lru_cache(maxsize=None)
def feriados(ano: int) -> pd.DataFrame:
    r = get(f"feriados/v1/{ano}")
    r.raise_for_status()
    f = pd.DataFrame(r.json())
    dia = pd.to_datetime(f["date"]).dt.dayofweek  # 0 = segunda
    f["emenda"] = dia.map({0: "segunda: fim de semana de 3 dias", 4: "sexta: fim de semana de 3 dias",
                           1: "terça: dá para emendar a segunda", 3: "quinta: dá para emendar a sexta"}).fillna("")
    return f[["date", "name", "weekday", "emenda"]]


# ------------------------------------------------------------------ alertas
def sem_acento(t) -> str:
    import unicodedata
    t = unicodedata.normalize("NFKD", str(t or "").upper())
    return "".join(c for c in t if not unicodedata.combining(c))


def alertas(l: dict, hoje: date) -> list[str]:
    a = []
    if l["status_cnpj"] != "ok":
        return [l["status_cnpj"]]
    if l["situacao"] != "ATIVA":
        a.append(f"empresa {l['situacao'].lower()} desde {l['data_situacao']}")
    if str(l["cnae"]) != AGENCIA:
        a.append(f"atividade principal não é agência de viagens: {l['atividade']}")
    if "RECUPERACAO JUDICIAL" in sem_acento(l["razao_social"]):
        a.append("em recuperação judicial")
    if l["abertura"] and (hoje - date.fromisoformat(l["abertura"])).days < 2 * 365:
        a.append(f"aberta há menos de dois anos ({l['abertura']})")
    if l.get("status_cep") == "ok" and sem_acento(l["cidade_cep"]) != sem_acento(l["municipio_receita"]):
        a.append(f"CEP do cadastro é de {l['cidade_cep']}; na Receita, {l['municipio_receita'].title()}")
    if l.get("uf_ddd") and l["uf_ddd"] != l["uf_receita"]:
        a.append(f"telefone do cadastro com DDD de {l['uf_ddd']}; empresa em {l['uf_receita']}")
    return a


# ------------------------------------------------------------------ agências
def agencias(arquivo: Path, ano: int, saida: Path) -> None:
    df = pd.read_csv(arquivo, dtype=str)
    hoje = date.today()
    linhas = []
    for i, r in df.iterrows():
        c, e, d = limpar_cnpj(r["cnpj"]), limpar_cep(r["cep_cadastro"]), ddd_de(r["telefone_cadastro"])
        l = {"cnpj_limpo": c, "cep_limpo": e, "ddd_cadastro": d, **cnpj(c), **cep(e), **ddd(d)}
        l["alertas"] = "; ".join(alertas(l, hoje))
        linhas.append(l)
        print(f"{i + 1}/{len(df)} {r['nome_no_crm']}: {l['alertas'] or 'ok'}")
    out = pd.concat([df.reset_index(drop=True), pd.DataFrame(linhas)], axis=1)
    out["linha_repetida"] = out.duplicated("cnpj_limpo", keep="first")
    out.loc[out["linha_repetida"], "alertas"] = (out["alertas"] + "; linha repetida (mesmo CNPJ)").str.strip("; ")

    # grupos: CNPJs diferentes com o mesmo telefone ou o mesmo CEP na Receita
    #        (quem divide telefone com A e endereço com B fica no mesmo grupo de A e B)
    ok = out[(out["status_cnpj"] == "ok") & ~out["linha_repetida"]]
    pai = {c: c for c in ok["cnpj_limpo"]}

    def raiz(c):
        while pai[c] != c:
            c = pai[c]
        return c

    for col in ["telefone_receita", "cep_receita"]:
        for _, g in ok.groupby(col):
            cs = list(g["cnpj_limpo"])
            for c in cs[1:]:
                pai[raiz(c)] = raiz(cs[0])
    nomes = ok.set_index("cnpj_limpo")["nome_no_crm"]
    membros = {}
    for c in pai:
        membros.setdefault(raiz(c), []).append(nomes[c])
    rotulo = {c: " + ".join(sorted(membros[raiz(c)])) for c in pai if len(membros[raiz(c)]) > 1}
    grupo = {c: {r} for c, r in rotulo.items()}
    out["grupo"] = out["cnpj_limpo"].map(lambda c: rotulo.get(c, ""))
    out.to_csv(saida, index=False, encoding="utf-8-sig")

    fer = feriados(ano)
    fer_arq = saida.with_name(f"feriados_{ano}.csv")
    fer.to_csv(fer_arq, index=False, encoding="utf-8-sig")

    vendas = pd.to_numeric(out["vendas_2026_rs"], errors="coerce")
    limpas = out[(out["alertas"] == "") & ~out["linha_repetida"]]
    print(f"\n{len(out)} linhas em {saida.name}; feriados em {fer_arq.name}")
    print(f"sem nenhum alerta: {len(limpas)} agências, R$ {vendas[limpas.index].sum():,.0f} em vendas")
    print("\nalertas:")
    for _, l in out[out["alertas"] != ""].iterrows():
        print(f"  {l['id_agencia']} {l['nome_no_crm']}: {l['alertas']}")
    print("\ngrupos (mesmo telefone ou endereço na Receita):")
    for g in sorted({x for s in grupo.values() for x in s}):
        print("  " + g)
    print(f"\nferiados nacionais de {ano} que emendam:")
    print(fer[fer["emenda"] != ""].to_string(index=False))


def main() -> None:
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    p.add_argument("modo", choices=["cnpj", "cep", "ddd", "feriados", "agencias"])
    p.add_argument("valor")
    p.add_argument("--ano", type=int, default=2027)
    p.add_argument("--saida", type=Path, default=Path("agencias_enriquecidas.csv"))
    a = p.parse_args()
    if a.modo == "agencias":
        agencias(Path(a.valor), a.ano, a.saida)
    elif a.modo == "feriados":
        print(feriados(int(a.valor)).to_string(index=False))
    else:
        f = {"cnpj": lambda v: cnpj(limpar_cnpj(v)), "cep": lambda v: cep(limpar_cep(v)), "ddd": lambda v: ddd(v)}[a.modo]
        print(json.dumps(f(a.valor), ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
