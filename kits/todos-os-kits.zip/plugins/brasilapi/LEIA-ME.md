# Plugin brasilapi

**O que faz:** o plugin do exercício 2. Consulta CNPJ, CEP, DDD e feriados na
BrasilAPI e enriquece uma planilha de parceiros com situação na Receita,
atividade, porte, abertura e cidade, marcando cadastros inconsistentes e grupos
de agências com o mesmo telefone ou endereço.

**Como criar o plugin:** no ChatGPT, Personalizar → Plugins → Adicionar →
Criar plugin. Anexe este zip e peça:

> Crie um plugin chamado brasilapi com a habilidade do SKILL.md e o script
> scripts/brasilapi.py deste zip. Teste com o CEP 01310-100.

Depois, instale (Personalizar → Plugins → Pessoal). Rode no aplicativo de
desktop, no modo Work: a BrasilAPI recusa o computador da nuvem.

**Pedido de exemplo:**

> Use o plugin brasilapi na planilha exemplo_agencias.csv. Quais agências
> deveriam ficar fora do programa de incentivo, e por quê?

**Como adaptar:**

- Outra planilha: renomeie as colunas para `cnpj`, `cep_cadastro` e
  `telefone_cadastro` numa cópia, ou peça ao agente para ajustar o modo
  `agencias` do script às suas colunas.
- Outras regras de alerta (por exemplo, atividade esperada diferente de
  agência de viagens): a lista de CNAEs no script.
- Testado em 5/11/2026: CEP 01310-100 em São Paulo (SP); feriados de 2027 com
  as emendas marcadas.
